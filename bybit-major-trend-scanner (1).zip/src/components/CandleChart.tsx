import React, { useEffect, useRef } from 'react';
import {
  createChart,
  ColorType,
  CandlestickSeries,
  LineSeries,
  LineStyle,
  createSeriesMarkers,
  IChartApi,
} from 'lightweight-charts';
import { KlineCandle, MajorBreakoutSignal } from '../types/scanner';

interface CandleChartProps {
  candles: KlineCandle[];
  signal: MajorBreakoutSignal;
  height?: number;
}

export const CandleChart: React.FC<CandleChartProps> = ({ candles, signal, height = 480 }) => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartInstanceRef = useRef<IChartApi | null>(null);

  useEffect(() => {
    if (!chartContainerRef.current || !candles || candles.length === 0) return;

    if (chartInstanceRef.current) {
      chartInstanceRef.current.remove();
      chartInstanceRef.current = null;
    }

    const container = chartContainerRef.current;
    const chart = createChart(container, {
      width: container.clientWidth,
      height: height,
      layout: {
        background: { type: ColorType.Solid, color: '#0B0F19' },
        textColor: '#94A3B8',
        fontSize: 12,
      },
      grid: {
        vertLines: { color: 'rgba(30, 41, 59, 0.6)' },
        horzLines: { color: 'rgba(30, 41, 59, 0.6)' },
      },
      crosshair: {
        vertLine: {
          color: '#64748B',
          width: 1,
          style: LineStyle.Dashed,
        },
        horzLine: {
          color: '#64748B',
          width: 1,
          style: LineStyle.Dashed,
        },
      },
      rightPriceScale: {
        borderColor: '#1E293B',
        scaleMargins: {
          top: 0.12,
          bottom: 0.15,
        },
      },
      timeScale: {
        borderColor: '#1E293B',
        timeVisible: true,
        secondsVisible: false,
      },
    });

    chartInstanceRef.current = chart;

    // 1. Candlestick Series
    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#10B981',
      downColor: '#EF4444',
      borderVisible: false,
      wickUpColor: '#10B981',
      wickDownColor: '#EF4444',
    });

    const formattedCandles = candles
      .map((c) => ({
        time: c.time as any,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }))
      .filter((c, idx, arr) => idx === 0 || c.time > arr[idx - 1].time);

    candleSeries.setData(formattedCandles);

    // 2. Major Descending Trendline Series
    const trendlineSeries = chart.addSeries(LineSeries, {
      color: '#F59E0B',
      lineWidth: 2,
      lineStyle: LineStyle.Solid,
      title: `${signal.majorTouchCount} Temaslı Majör Düşen Trend (${signal.trendAgeDays} Gün)`,
      priceLineVisible: true,
    });

    const trendData: Array<{ time: any; value: number }> = [];
    const startIndex = Math.max(0, candles.length - 1 - signal.trendAgeBars);

    for (let i = startIndex; i < candles.length; i++) {
      const c = candles[i];
      const lineY = signal.lineFormula(i);
      if (lineY > 0) {
        trendData.push({
          time: c.time as any,
          value: Number(lineY.toFixed(6)),
        });
      }
    }

    // Extrapolate a few future bars
    if (candles.length > 0 && trendData.length > 0) {
      const lastCandle = candles[candles.length - 1];
      const avgIntervalSec =
        candles.length > 1
          ? (candles[candles.length - 1].time - candles[0].time) / (candles.length - 1)
          : 86400;

      for (let step = 1; step <= 6; step++) {
        const futureTime = lastCandle.time + step * avgIntervalSec;
        const futureLineY = signal.lineFormula(candles.length - 1 + step);
        if (futureLineY > 0) {
          trendData.push({
            time: Math.floor(futureTime) as any,
            value: Number(futureLineY.toFixed(6)),
          });
        }
      }
    }

    const uniqueTrendData = trendData.filter(
      (p, idx, arr) => idx === 0 || p.time > arr[idx - 1].time
    );

    trendlineSeries.setData(uniqueTrendData);

    // 3. Markers: Tepe Temasları + KIRILIM Marker
    const markers: any[] = signal.touches.map((touch, idx) => ({
      time: touch.time as any,
      position: 'aboveBar' as const,
      color: '#F59E0B',
      shape: 'arrowDown' as const,
      text: `Tepe ${idx + 1}: ${touch.candleHigh.toFixed(4)}`,
    }));

    // Add BREAKOUT marker on the breakout candle!
    markers.push({
      time: signal.breakoutTime as any,
      position: 'belowBar' as const,
      color: '#10B981',
      shape: 'arrowUp' as const,
      text: `🔥 KIRILIM: $${signal.breakoutPrice.toFixed(4)}`,
    });

    createSeriesMarkers(candleSeries, markers);

    // 4. Kırılım Seviyesi (Horizontal Price Line)
    candleSeries.createPriceLine({
      price: signal.breakoutPrice,
      color: '#10B981',
      lineWidth: 2,
      lineStyle: LineStyle.Dashed,
      axisLabelVisible: true,
      title: `KIRILIM SEVİYESİ ($${signal.breakoutPrice.toFixed(4)})`,
    });

    // 5. TP2 Seviyesi
    if (signal.tp2 && signal.tp2 > 0) {
      candleSeries.createPriceLine({
        price: signal.tp2,
        color: '#06B6D4',
        lineWidth: 2,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: true,
        title: `TP2 ($${signal.tp2.toFixed(4)}) R/R: ${signal.tp2Ratio}`,
      });
    }

    // 6. TP1 Seviyesi
    if (signal.tp1 && signal.tp1 > 0) {
      candleSeries.createPriceLine({
        price: signal.tp1,
        color: '#34D399',
        lineWidth: 2,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: true,
        title: `TP1 ($${signal.tp1.toFixed(4)}) R/R: ${signal.tp1Ratio}`,
      });
    }

    // 7. ANLIK FİYAT
    if (signal.currentPrice && signal.currentPrice > 0) {
      candleSeries.createPriceLine({
        price: signal.currentPrice,
        color: '#F59E0B',
        lineWidth: 2,
        lineStyle: LineStyle.Dotted,
        axisLabelVisible: true,
        title: `ANLIK: $${signal.currentPrice.toFixed(4)}`,
      });
    }

    // 8. STOP LOSS (SL)
    if (signal.sl && signal.sl > 0) {
      candleSeries.createPriceLine({
        price: signal.sl,
        color: '#F43F5E',
        lineWidth: 2,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: true,
        title: `SL ($${signal.sl.toFixed(4)})`,
      });
    }

    chart.timeScale().fitContent();

    const handleResize = () => {
      if (chartContainerRef.current && chartInstanceRef.current) {
        chartInstanceRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth,
        });
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (chartInstanceRef.current) {
        chartInstanceRef.current.remove();
        chartInstanceRef.current = null;
      }
    };
  }, [candles, signal, height]);

  return (
    <div className="w-full relative rounded-xl overflow-hidden border border-slate-800 bg-[#0B0F19]">
      <div className="absolute top-3 left-4 z-10 flex flex-wrap items-center gap-3 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-emerald-500/40 text-xs">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
          <span className="text-emerald-400 font-bold">🔥 MAJÖR DÜŞEN TREND KIRILDI</span>
        </div>
        <div className="text-slate-400">
          Yaş: <b className="text-white font-mono">{signal.trendAgeDays} Gün</b>
        </div>
        <div className="text-slate-400">
          Temas: <b className="text-amber-400 font-mono">{signal.majorTouchCount} Tepe</b>
        </div>
        <div className="text-slate-400">
          Kırılım: <b className="text-emerald-400 font-mono">${signal.breakoutPrice.toFixed(4)}</b>
        </div>
      </div>

      <div ref={chartContainerRef} className="w-full" style={{ height: `${height}px` }} />
    </div>
  );
};
