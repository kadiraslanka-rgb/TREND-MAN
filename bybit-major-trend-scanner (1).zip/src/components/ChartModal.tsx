import React from 'react';
import { ExternalLink, X, Flame, Calendar, Award, Clock } from 'lucide-react';
import { MajorBreakoutSignal } from '../types/scanner';
import { CandleChart } from './CandleChart';

interface ChartModalProps {
  signal: MajorBreakoutSignal | null;
  onClose: () => void;
}

export const ChartModal: React.FC<ChartModalProps> = ({ signal, onClose }) => {
  if (!signal) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-6xl max-h-[92vh] flex flex-col bg-slate-900 border-2 border-emerald-500/40 rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-black text-lg">
              {signal.symbol.slice(0, 3)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-white tracking-wide">{signal.symbol}</h2>
                <span className="px-2.5 py-0.5 rounded-lg text-xs font-black bg-amber-500 text-slate-950 font-mono">
                  {signal.timeframe}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5 fill-emerald-400" />
                  <span>{signal.signalName}</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Kırılım Zamanı: <b className="text-slate-200 font-mono">{signal.breakoutTimeStr}</b> • Kırılım Fiyatı: <b className="text-emerald-400 font-mono">${signal.breakoutPrice.toFixed(4)}</b>
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5">
            <a
              href={`https://www.bybit.com/trade/usdt/${signal.symbol}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition-colors"
            >
              <span>Bybit'te İşlem Yap</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          <CandleChart candles={signal.klines} signal={signal} height={480} />

          {/* Key Metrics Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                <span>TREND YAŞI</span>
              </span>
              <span className="text-lg font-black text-white font-mono mt-1 block">
                {signal.trendAgeDays} Gün
              </span>
            </div>

            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
                <Award className="w-3.5 h-3.5 text-amber-400" />
                <span>MAJÖR TEMAS</span>
              </span>
              <span className="text-lg font-black text-amber-400 font-mono mt-1 block">
                {signal.majorTouchCount} Tepe
              </span>
            </div>

            <div className="bg-slate-950/80 border border-emerald-500/20 bg-emerald-500/5 p-3.5 rounded-xl">
              <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-semibold">
                <Flame className="w-3.5 h-3.5 text-emerald-400" />
                <span>KIRILIM FİYATI</span>
              </span>
              <span className="text-lg font-black text-emerald-400 font-mono mt-1 block">
                ${signal.breakoutPrice.toFixed(4)}
              </span>
            </div>

            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>KIRILIM ZAMANI</span>
              </span>
              <span className="text-xs font-bold text-slate-200 font-mono mt-1.5 block">
                {signal.breakoutTimeStr}
              </span>
            </div>
          </div>

          {/* Trade Targets & Structure Row (TP1, TP2, SL, ANLIK) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-950/80 border border-amber-500/20 bg-amber-500/5 p-3.5 rounded-xl">
              <span className="text-[11px] text-amber-400 font-bold block">
                ANLIK FİYAT
              </span>
              <span className="text-lg font-black text-amber-300 font-mono mt-1 block">
                ${signal.currentPrice.toFixed(4)}
              </span>
            </div>

            <div className="bg-slate-950/80 border border-emerald-500/30 bg-emerald-500/5 p-3.5 rounded-xl">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-emerald-400 font-bold">TP1 (FIB+HTF)</span>
                <span className="text-[10px] font-mono text-emerald-300 font-bold bg-slate-900 px-1.5 py-0.5 rounded">
                  R/R: {signal.tp1Ratio}
                </span>
              </div>
              <span className="text-lg font-black text-emerald-400 font-mono mt-1 block">
                ${signal.tp1.toFixed(4)}
              </span>
            </div>

            <div className="bg-slate-950/80 border border-cyan-500/30 bg-cyan-500/5 p-3.5 rounded-xl">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-cyan-400 font-bold">TP2 (MAJÖR)</span>
                <span className="text-[10px] font-mono text-cyan-300 font-bold bg-slate-900 px-1.5 py-0.5 rounded">
                  R/R: {signal.tp2Ratio}
                </span>
              </div>
              <span className="text-lg font-black text-cyan-400 font-mono mt-1 block">
                ${signal.tp2.toFixed(4)}
              </span>
            </div>

            <div className="bg-slate-950/80 border border-rose-500/30 bg-rose-500/5 p-3.5 rounded-xl">
              <span className="text-[11px] text-rose-400 font-bold block">
                STOP LOSS (SL)
              </span>
              <span className="text-lg font-black text-rose-400 font-mono mt-1 block">
                ${signal.sl.toFixed(4)}
              </span>
            </div>
          </div>

          {/* Touches List */}
          <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-xl">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2.5">
              Majör Tepe Temas Noktaları ({signal.touches.length})
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              {signal.touches.map((t, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2.5 bg-slate-900 rounded-lg border border-slate-800"
                >
                  <span className="font-bold text-amber-400 font-mono">Tepe {idx + 1}</span>
                  <span className="text-slate-300">{t.dateStr}</span>
                  <span className="font-mono text-slate-100 font-semibold">
                    ${t.candleHigh.toFixed(4)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
