package com.trendscanner.bybit;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import javax.net.ssl.HttpsURLConnection;

/**
 * MarketTransport
 * Robust HTTP/HTTPS network client that handles:
 * - Standard SSL/TLS certificate verification (never disables SSL checks)
 * - Automatic gzip/deflate decompression
 * - Header spoofing (realistic desktop/mobile browser User-Agent)
 * - Mirror failover for regional ISP blocks and "Connection reset" prevention
 */
public class MarketTransport {

    public static class Response {
        public int statusCode;
        public String body;
        public boolean isSuccessful;
        public String error;
        public String usedUrl;

        public Response(int statusCode, String body, boolean isSuccessful, String error, String usedUrl) {
            this.statusCode = statusCode;
            this.body = body != null ? body : "";
            this.isSuccessful = isSuccessful;
            this.error = error != null ? error : "";
            this.usedUrl = usedUrl != null ? usedUrl : "";
        }
    }

    /**
     * Executes GET request with automatic mirror failover and gzip support.
     */
    public static Response get(String requestedUrl, Map<String, String> customHeaders, int timeoutMs) {
        return executeWithFailover(requestedUrl, "GET", null, customHeaders, timeoutMs);
    }

    /**
     * Executes POST request with automatic mirror failover.
     */
    public static Response post(String requestedUrl, String postBody, Map<String, String> customHeaders, int timeoutMs) {
        return executeWithFailover(requestedUrl, "POST", postBody, customHeaders, timeoutMs);
    }

    /**
     * Executes request against candidate URLs until one succeeds or all fail.
     */
    public static Response executeWithFailover(
            String requestedUrl,
            String method,
            String postBody,
            Map<String, String> customHeaders,
            int timeoutMs) {

        List<String> candidates = MarketConnectionPolicy.getUrlCandidates(requestedUrl);
        if (candidates.isEmpty()) {
            return new Response(0, "", false, "Invalid URL: " + requestedUrl, requestedUrl);
        }

        int connectTimeout = timeoutMs > 0 ? timeoutMs : MarketConnectionPolicy.CONNECT_TIMEOUT_MS;
        int readTimeout = timeoutMs > 0 ? timeoutMs : MarketConnectionPolicy.READ_TIMEOUT_MS;

        Exception lastException = null;
        Response lastResponse = null;

        for (String targetUrl : candidates) {
            try {
                Response resp = executeSingleRequest(targetUrl, method, postBody, customHeaders, connectTimeout, readTimeout);
                if (resp.isSuccessful) {
                    return resp;
                }
                lastResponse = resp;
                // If it's a 4xx client error (e.g. 404), trying another mirror won't help unless it's 403 or 429
                if (resp.statusCode >= 400 && resp.statusCode < 500 && resp.statusCode != 403 && resp.statusCode != 429) {
                    return resp;
                }
            } catch (Exception e) {
                lastException = e;
                if (!MarketConnectionPolicy.isRetriableNetworkError(e)) {
                    // Non-retriable error
                    return new Response(0, "", false, e.getMessage(), targetUrl);
                }
                // Retriable network error (e.g. Connection reset): proceed to next mirror
            }
        }

        if (lastResponse != null) {
            return lastResponse;
        }

        String errMessage = lastException != null ? lastException.getMessage() : "All connection attempts failed";
        return new Response(0, "", false, errMessage, requestedUrl);
    }

    /**
     * Performs a single HTTP/HTTPS request with automatic retry for stale pooled connections.
     */
    private static Response executeSingleRequest(
            String urlStr,
            String method,
            String postBody,
            Map<String, String> customHeaders,
            int connectTimeout,
            int readTimeout) throws Exception {

        try {
            return doHttpExchange(urlStr, method, postBody, customHeaders, connectTimeout, readTimeout, false);
        } catch (Exception e) {
            if (MarketConnectionPolicy.isRetriableNetworkError(e)) {
                // Connection was reset or interrupted (common with pooled sockets closed by exchange)
                // Retry once immediately with a fresh, unpooled connection (Connection: close)
                return doHttpExchange(urlStr, method, postBody, customHeaders, connectTimeout, readTimeout, true);
            }
            throw e;
        }
    }

    private static Response doHttpExchange(
            String urlStr,
            String method,
            String postBody,
            Map<String, String> customHeaders,
            int connectTimeout,
            int readTimeout,
            boolean forceClose) throws Exception {

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        try {
            conn.setRequestMethod(method);
            conn.setConnectTimeout(connectTimeout);
            conn.setReadTimeout(readTimeout);
            conn.setInstanceFollowRedirects(true);
            conn.setUseCaches(false);

            if (forceClose) {
                conn.setRequestProperty("Connection", "close");
            }

            // Apply standard policy headers (User-Agent, Accept, etc.)
            Map<String, String> stdHeaders = MarketConnectionPolicy.getStandardHeaders();
            for (Map.Entry<String, String> entry : stdHeaders.entrySet()) {
                conn.setRequestProperty(entry.getKey(), entry.getValue());
            }

            // Apply any custom headers
            if (customHeaders != null) {
                for (Map.Entry<String, String> entry : customHeaders.entrySet()) {
                    conn.setRequestProperty(entry.getKey(), entry.getValue());
                }
            }

            // Write POST body if applicable
            if ("POST".equalsIgnoreCase(method) && postBody != null) {
                conn.setDoOutput(true);
                byte[] bytes = postBody.getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(bytes);
                    os.flush();
                }
            }

            int statusCode = conn.getResponseCode();
            String contentType = conn.getContentType();
            boolean isHtml = contentType != null && (contentType.toLowerCase().contains("text/html") || contentType.toLowerCase().contains("application/xhtml"));
            boolean isSuccess = (statusCode >= 200 && statusCode < 300) && !isHtml;

            InputStream is = isSuccess ? conn.getInputStream() : conn.getErrorStream();
            String responseBody = "";

            if (is != null) {
                String encoding = conn.getHeaderField("Content-Encoding");
                if (encoding != null && encoding.toLowerCase().contains("gzip")) {
                    try {
                        is = new GZIPInputStream(is);
                    } catch (Exception ignored) {
                        // Stream may already be decoded by Android network layer
                    }
                }

                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                byte[] data = new byte[8192];
                int nRead;
                while ((nRead = is.read(data, 0, data.length)) != -1) {
                    buffer.write(data, 0, nRead);
                }
                buffer.flush();
                responseBody = buffer.toString("UTF-8");
            }

            String errorMsg = null;
            if (!isSuccess) {
                if (isHtml) {
                    errorMsg = "API returned unexpected HTML (redirect or block): " + urlStr;
                } else {
                    errorMsg = "HTTP " + statusCode;
                }
            }

            return new Response(statusCode, responseBody, isSuccess, errorMsg, urlStr);
        } finally {
            conn.disconnect();
        }
    }
}
