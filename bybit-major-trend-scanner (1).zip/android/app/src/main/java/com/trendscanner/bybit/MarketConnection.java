package com.trendscanner.bybit;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MarketConnection Plugin
 * Capacitor native bridge for crypto exchange network requests.
 * Bypasses WebView CORS limitations, applies browser User-Agent headers,
 * and routes through official fallback mirror endpoints to prevent "Connection reset".
 */
@CapacitorPlugin(name = "MarketConnection")
public class MarketConnection extends Plugin {

    private final ExecutorService executor = Executors.newFixedThreadPool(8);

    @PluginMethod
    public void request(PluginCall call) {
        handleFetch(call);
    }

    @PluginMethod
    public void fetch(PluginCall call) {
        handleFetch(call);
    }

    private void handleFetch(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.trim().isEmpty()) {
            call.reject("URL parameter is required");
            return;
        }

        String method = call.getString("method", "GET").toUpperCase();
        String body = call.getString("body", null);
        Integer timeout = call.getInt("timeout", 15000);

        Map<String, String> customHeaders = new HashMap<>();
        JSObject headersObj = call.getObject("headers");
        if (headersObj != null) {
            Iterator<String> keys = headersObj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                customHeaders.put(key, headersObj.getString(key));
            }
        }

        executor.execute(() -> {
            try {
                MarketTransport.Response response;
                if ("POST".equalsIgnoreCase(method)) {
                    response = MarketTransport.post(url, body, customHeaders, timeout);
                } else {
                    response = MarketTransport.get(url, customHeaders, timeout);
                }

                JSObject ret = new JSObject();
                ret.put("status", response.statusCode);
                ret.put("data", response.body);
                ret.put("ok", response.isSuccessful);
                ret.put("usedUrl", response.usedUrl);
                if (!response.isSuccessful) {
                    ret.put("error", response.error);
                }
                call.resolve(ret);
            } catch (Exception e) {
                JSObject ret = new JSObject();
                ret.put("status", 0);
                ret.put("data", "");
                ret.put("ok", false);
                ret.put("error", e.getMessage() != null ? e.getMessage() : "Unknown native network error");
                ret.put("usedUrl", url);
                call.resolve(ret);
            }
        });
    }

    @PluginMethod
    public void checkConnection(PluginCall call) {
        executor.execute(() -> {
            MarketTransport.Response bybitResp = MarketTransport.get("https://api.bybit.com/v5/market/time", null, 8000);
            MarketTransport.Response binanceResp = MarketTransport.get("https://fapi.binance.com/fapi/v1/time", null, 8000);
            MarketTransport.Response okxResp = MarketTransport.get("https://www.okx.com/api/v5/public/time", null, 8000);

            JSObject ret = new JSObject();
            ret.put("bybitOk", bybitResp.isSuccessful);
            ret.put("bybitUrl", bybitResp.usedUrl);
            ret.put("bybitError", bybitResp.error);

            ret.put("binanceOk", binanceResp.isSuccessful);
            ret.put("binanceUrl", binanceResp.usedUrl);
            ret.put("binanceError", binanceResp.error);

            ret.put("okxOk", okxResp.isSuccessful);
            ret.put("okxUrl", okxResp.usedUrl);
            ret.put("okxError", okxResp.error);

            call.resolve(ret);
        });
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("pluginLoaded", true);
        ret.put("trialUnlocked", TrialPolicy.isFeatureUnlocked());
        ret.put("statusDescription", TrialPolicy.getStatusDescription());
        call.resolve(ret);
    }
}
