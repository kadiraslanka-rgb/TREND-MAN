from pathlib import Path
import shutil
r=Path(__file__).resolve().parent.parent
d=r/'android/app/src/main/assets/public'
shutil.rmtree(d,ignore_errors=True)
shutil.copytree(r/'public',d)
