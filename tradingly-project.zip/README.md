# TRADINGLY 1.4.5 connection repair

The public folder is the frozen, compiled 1.4.5 UI and scanner plus the additional Binance/OKX market adapter. Original TypeScript UI source for 1.4.5 was not recovered. Do not replace it with the newer 1.5.x UI. Native Android source is included.

## Build
Install Node, Python 3, JDK 21 and Android SDK 36. Run `npm ci`, create `android/local.properties` with your SDK path, then `npm run android:release`. Use the original private signing key via ANDROID_KEYSTORE_PATH, ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS, ANDROID_KEY_PASSWORD to produce an installable update. Signing material is deliberately excluded. Default versionCode 43; application ID com.trendscanner.bybit.

## Problem observed
On the user's Android phone all three exchanges returned Connection reset on mobile and Wi-Fi. This evidence does not establish whether the reset originates in the client, device networking or upstream service. Prior browser bridge fixtures did not exercise real native networking.

## Change
Original compiled scanner and CSS/images retained. The market bridge now calls MarketConnection using OkHttp instead of CapacitorHttp/HttpsURLConnection. Default platform TLS certificate and hostname verification retained. IPv4 is attempted first and IPv6 retained; alternative routes are supported. Bounded GET retry after I/O interruption; maximum 10 seconds per attempt, two explicit attempts; redirects disabled, response bound 5 MB. One failing exchange cannot abort the other source lists.

## Verification
Five JVM native transport tests passed: forced disconnect retry, stale closed socket recovery, HTTP 403 no retry, IPv4 ordering without dropping IPv6, default verifier configuration. Repeated manual start in the shipped browser bundle issued 75 candle requests through simulated Android callbacks. APK signature verified and original chart worker/CSS/images byte-compared. No physical handset execution was available; live handset success remains unverified.

## Latest handset result
The user reports the OkHttp-based APK ALSO FAILS. The connection problem remains unresolved. This branch is for reproducible diagnosis, not a verified fix. Do not publish or mark repaired based on mocked bridge/JVM tests alone.
