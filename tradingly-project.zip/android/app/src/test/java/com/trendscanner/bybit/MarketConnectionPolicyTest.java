package com.trendscanner.bybit;
import org.junit.Test;
import static org.junit.Assert.*;
public class MarketConnectionPolicyTest {
 @Test public void onlyOfficialHttpsMarketHosts() {
  assertTrue(MarketConnectionPlugin.allowed("https://api.bybit.com/v5/market/tickers?category=linear"));
  assertTrue(MarketConnectionPlugin.allowed("https://fapi.binance.com/fapi/v1/exchangeInfo"));
  assertTrue(MarketConnectionPlugin.allowed("https://www.okx.com/api/v5/public/instruments?instType=SWAP"));
  for(String url:new String[]{"http://api.bybit.com/x","https://api.bybit.com.evil.test/x","https://user:pass@api.bybit.com/x","https://api.bybit.com:8443/x","https://evil.test/x","https://api.bybit.com/x#fragment","//api.bybit.com/x"})assertFalse(url,MarketConnectionPlugin.allowed(url));
 }
}
