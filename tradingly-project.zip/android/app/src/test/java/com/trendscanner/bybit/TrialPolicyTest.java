package com.trendscanner.bybit;
import org.junit.Test;
import static org.junit.Assert.*;
public class TrialPolicyTest {
 @Test public void expiration(){long start=1000000;assertEquals(TrialPolicy.DURATION,TrialPolicy.remaining(start,start));assertEquals(1,TrialPolicy.remaining(start,start+TrialPolicy.DURATION-1));assertEquals(0,TrialPolicy.remaining(start,start+TrialPolicy.DURATION));assertEquals(0,TrialPolicy.remaining(start,start+TrialPolicy.DURATION+1));}
 @Test public void invalidTime(){assertEquals(0,TrialPolicy.remaining(0,1));assertEquals(0,TrialPolicy.remaining(100,99));}
 @Test public void clockRollback(){assertEquals(1200,TrialPolicy.safeNow(800,1000,200));assertEquals(1500,TrialPolicy.safeNow(1500,1000,200));}
}
