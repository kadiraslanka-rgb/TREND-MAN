package com.trendscanner.bybit;
import org.junit.Test;
import static org.junit.Assert.*;
import java.net.InetAddress;
import java.util.Arrays;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.SocketPolicy;
public class MarketTransportTest {
 @Test public void freshGetAndStaleConnection() throws Exception {
  try(MockWebServer server=new MockWebServer()){
   server.enqueue(new MockResponse().setBody("{\"ok\":1}").setSocketPolicy(SocketPolicy.DISCONNECT_AT_END));
   server.enqueue(new MockResponse().setBody("{\"ok\":2}"));server.start();
   assertEquals("{\"ok\":1}",MarketTransport.read(server.url("/first").toString()));
   assertEquals("{\"ok\":2}",MarketTransport.read(server.url("/second").toString()));
  }
 }
 @Test public void connectionResetRetry() throws Exception {
  try(MockWebServer server=new MockWebServer()){
   server.enqueue(new MockResponse().setSocketPolicy(SocketPolicy.DISCONNECT_AT_START));
   server.enqueue(new MockResponse().setBody("recovered"));server.start();
   assertEquals("recovered",MarketTransport.read(server.url("/reset").toString()));
  }
 }
 @Test public void httpDeniedIsNotRetried() throws Exception {
  try(MockWebServer server=new MockWebServer()){
   server.enqueue(new MockResponse().setResponseCode(403));server.start();
   try{MarketTransport.read(server.url("/denied").toString());fail();}catch(MarketTransport.HttpStatusException error){assertEquals("HTTP 403",error.getMessage());}
   assertEquals(1,server.getRequestCount());
  }
 }
 @Test public void ipv4PreferredAndIpv6Retained() throws Exception {
  InetAddress v6=InetAddress.getByName("::1"),v4=InetAddress.getByName("127.0.0.1");
  assertEquals(Arrays.asList(v4,v6),MarketTransport.ipv4First(Arrays.asList(v6,v4)));
 }
 @Test public void certificateChecksAndRedirectPolicyRemain() {
  assertNotNull(MarketTransport.CLIENT.hostnameVerifier());assertNotNull(MarketTransport.CLIENT.sslSocketFactory());assertFalse(MarketTransport.CLIENT.followRedirects());
 }
}
