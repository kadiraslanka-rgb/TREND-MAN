package com.trendscanner.bybit;
final class TrialPolicy {
 static final long DURATION=72L*60*60*1000;
 static long remaining(long start,long now){if(start<=0||now<start)return 0;return Math.max(0,DURATION-(now-start));}
 static long safeNow(long system,long baseline,long elapsed){return Math.max(system,baseline+Math.max(0,elapsed));}
}
