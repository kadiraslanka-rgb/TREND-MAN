package com.trendscanner.bybit;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLException;
import okhttp3.Dns;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/** Shared bounded read-only transport. Platform certificate and hostname checks are untouched. */
final class MarketTransport {
    static final OkHttpClient CLIENT = new OkHttpClient.Builder()
        .dns(host -> ipv4First(Dns.SYSTEM.lookup(host)))
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .followRedirects(false).followSslRedirects(false)
        .build();
    static List<InetAddress> ipv4First(List<InetAddress> addresses) {
        List<InetAddress> result = new ArrayList<>(addresses);
        result.sort((a,b) -> Boolean.compare(!(a instanceof Inet4Address), !(b instanceof Inet4Address)));
        return result;
    }
    static String read(String url) throws IOException {
        Request request = new Request.Builder().url(url).header("Accept", "application/json")
            .header("User-Agent", "TRADINGLY/1.4.5 Android").get().build();
        for (int attempt=0; ; attempt++) {
            try (Response response = CLIENT.newCall(request).execute()) {
                if (!response.isSuccessful()) throw new HttpStatusException(response.code());
                if (response.body() == null) throw new IOException("Empty response");
                if (response.body().contentLength() > 5000000) throw new IOException("Response too large");
                try (InputStream input = response.body().byteStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[8192]; int size;
                    while ((size=input.read(buffer))!=-1) {
                        if(out.size()+size>5000000)throw new IOException("Response too large");
                        out.write(buffer,0,size);
                    }
                    return out.toString("UTF-8");
                }
            } catch (IOException error) {
                if(attempt>=1 || error instanceof SSLException || error instanceof HttpStatusException
                    || "Response too large".equals(error.getMessage())) throw error;
                // Discard idle stale sockets before one bounded GET retry.
                CLIENT.connectionPool().evictAll();
            }
        }
    }
    static class HttpStatusException extends IOException {
        HttpStatusException(int status) {super("HTTP "+status);}
    }
}
