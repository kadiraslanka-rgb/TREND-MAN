package com.trendscanner.bybit;

import android.content.SharedPreferences;
import android.os.SystemClock;
import android.util.Base64;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.android.billingclient.api.*;
import java.util.*;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;

@CapacitorPlugin(name="Commerce")
public class CommercePlugin extends Plugin {
 private static final String PRODUCT="tradingly_lifetime";
 
 private BillingClient client;
 private SharedPreferences prefs;
 private boolean owned=false, ready=false;
 private long wall, elapsed;
 private String price="", note="";
 @Override public void load(){
  prefs=getContext().getSharedPreferences("tradingly_commerce",0);
  wall=Math.max(System.currentTimeMillis(),prefs.getLong("last",0));elapsed=SystemClock.elapsedRealtime();
  if(!prefs.contains("start"))prefs.edit().putLong("start",wall).commit();
  client=BillingClient.newBuilder(getContext()).setListener((result,purchases)->{
   if(result.getResponseCode()==BillingClient.BillingResponseCode.OK)refresh(null);
   else{note=result.getResponseCode()==BillingClient.BillingResponseCode.USER_CANCELED?"cancelled":"billing_error";emit();}
  }).enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()).enableAutoServiceReconnection().build();
 }
 private long now(){long n=TrialPolicy.safeNow(System.currentTimeMillis(),wall,SystemClock.elapsedRealtime()-elapsed);prefs.edit().putLong("last",n).apply();return n;}
 private JSObject state(){JSObject s=new JSObject();long left=TrialPolicy.remaining(prefs.getLong("start",0),now());s.put("configured",!BuildConfig.PLAY_LICENSE_KEY.isEmpty());s.put("owned",owned);s.put("remainingMs",left);s.put("allowed",owned||left>0);s.put("price",price);s.put("ready",ready&&!BuildConfig.PLAY_LICENSE_KEY.isEmpty());s.put("note",note);return s;}
 private void emit(){notifyListeners("changed",state());}
 private void finish(PluginCall call){emit();if(call!=null)call.resolve(state());}
 private boolean verified(Purchase p){try{
  if(!p.getProducts().contains(PRODUCT)||p.getPurchaseState()!=Purchase.PurchaseState.PURCHASED||BuildConfig.PLAY_LICENSE_KEY.isEmpty())return false;
  org.json.JSONObject data=new org.json.JSONObject(p.getOriginalJson());
  if(!getContext().getPackageName().equals(data.optString("packageName")))return false;
  PublicKey key=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(BuildConfig.PLAY_LICENSE_KEY,Base64.DEFAULT)));
  Signature signature=Signature.getInstance("SHA1withRSA");signature.initVerify(key);signature.update(p.getOriginalJson().getBytes(java.nio.charset.StandardCharsets.UTF_8));
  return signature.verify(Base64.decode(p.getSignature(),Base64.DEFAULT));
 }catch(Exception e){return false;}}
 private void refresh(PluginCall call){
  if(!client.isReady()){client.startConnection(new BillingClientStateListener(){public void onBillingSetupFinished(BillingResult r){if(r.getResponseCode()==0)refresh(call);else{note="unavailable";finish(call);}}public void onBillingServiceDisconnected(){ready=false;emit();}});return;}
  client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(),(r,items)->{
   if(r.getResponseCode()==0){owned=false;for(Purchase purchase:items){
    if(verified(purchase)){owned=true;if(!purchase.isAcknowledged())client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build(),result->{if(result.getResponseCode()!=0){note="ack_retry";emit();}});}
    else if(purchase.getProducts().contains(PRODUCT)&&purchase.getPurchaseState()==Purchase.PurchaseState.PENDING)note="pending";
   }}else note="unavailable";
   queryProduct(call,false);
  });
 }
 private void queryProduct(PluginCall call,boolean buy){
  client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(Collections.singletonList(QueryProductDetailsParams.Product.newBuilder().setProductId(PRODUCT).setProductType(BillingClient.ProductType.INAPP).build())).build(),(r,result)->{
   ready=false;
   if(r.getResponseCode()==0&&!result.getProductDetailsList().isEmpty()){
    ProductDetails product=result.getProductDetailsList().get(0);
    List<ProductDetails.OneTimePurchaseOfferDetails> offers=product.getOneTimePurchaseOfferDetailsList();
    if(offers!=null&&!offers.isEmpty()){
     ready=true;price=offers.get(0).getFormattedPrice();
     if(buy){getActivity().runOnUiThread(()->{BillingResult launch=client.launchBillingFlow(getActivity(),BillingFlowParams.newBuilder().setProductDetailsParamsList(Collections.singletonList(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(product).setOfferToken(offers.get(0).getOfferToken()).build())).build());if(launch.getResponseCode()!=0)note="billing_error";finish(call);});return;}
    }
   }
   if(!ready)note="unavailable";finish(call);
  });
 }
 @PluginMethod public void status(PluginCall call){call.resolve(state());}
 @PluginMethod public void restore(PluginCall call){refresh(call);}
 @PluginMethod public void purchase(PluginCall call){
  if(BuildConfig.PLAY_LICENSE_KEY.isEmpty()){note="unavailable";finish(call);return;}
  if(owned){finish(call);return;}
  if(!client.isReady()){note="unavailable";finish(call);return;}
  queryProduct(call,true);
 }
 @Override protected void handleOnResume(){refresh(null);}
 @Override protected void handleOnDestroy(){if(client!=null)client.endConnection();}
}
