package com.trendscanner.bybit;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.net.URI;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name="MarketConnection")
public class MarketConnectionPlugin extends Plugin {
 private final ExecutorService executor=Executors.newFixedThreadPool(12);
 static boolean allowed(String value){
  try{URI u=new URI(value);String h=u.getHost();return "https".equals(u.getScheme())&&u.getUserInfo()==null&&u.getFragment()==null&&(u.getPort()==-1||u.getPort()==443)&&("api.bybit.com".equals(h)||"fapi.binance.com".equals(h)||"www.okx.com".equals(h));}catch(Exception ignored){return false;}
 }
 @PluginMethod public void get(PluginCall call){
  String url=call.getString("url","");
  if(!allowed(url)){call.reject("Invalid market endpoint","INVALID_ENDPOINT");return;}
  if(executor.isShutdown()){call.reject("Connection closed","CONNECTION_CLOSED");return;}
  executor.execute(()->{try{String data=MarketTransport.read(url);JSObject result=new JSObject();result.put("status",200);result.put("data",data);call.resolve(result);}catch(Exception error){call.reject(error instanceof MarketTransport.HttpStatusException?error.getMessage():error.getClass().getSimpleName(),error.getClass().getSimpleName());}});
 }
 @Override protected void handleOnDestroy(){executor.shutdownNow();}
}
