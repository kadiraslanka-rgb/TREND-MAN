package com.trendscanner.bybit;

import android.Manifest;
import android.app.*;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.NotificationCompat;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;
import androidx.core.app.NotificationManagerCompat;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;

/** Immediate notifications: no alarm scheduling or automatic settings navigation. */
@CapacitorPlugin(name="NotificationBridge", permissions={@Permission(alias="display", strings={Manifest.permission.POST_NOTIFICATIONS})})
public class NotificationBridgePlugin extends Plugin {
 private ActivityResultLauncher<String> permissionLauncher;
 private PluginCall permissionCall;
 private static final String AUDIBLE="tradingly_audible_v1", SILENT="tradingly_silent_v1";
 private NotificationManager manager(){return (NotificationManager)getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE);}
 @Override public void load(){
  permissionLauncher=getActivity().registerForActivityResult(new ActivityResultContracts.RequestPermission(),granted->{
   PluginCall pending=permissionCall;permissionCall=null;if(pending!=null)pending.resolve(state());
  });
  if(Build.VERSION.SDK_INT>=26){
   NotificationChannel audible=new NotificationChannel(AUDIBLE,"TRADINGLY • Sound",NotificationManager.IMPORTANCE_DEFAULT);
   audible.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
   audible.enableVibration(true);
   NotificationChannel silent=new NotificationChannel(SILENT,"TRADINGLY • Silent",NotificationManager.IMPORTANCE_LOW);
   silent.setSound(null,null);silent.enableVibration(false);
   manager().createNotificationChannel(audible);manager().createNotificationChannel(silent);
  }
 }
 private JSObject state(){
  JSObject result=new JSObject();result.put("enabled",NotificationManagerCompat.from(getContext()).areNotificationsEnabled());
  if(Build.VERSION.SDK_INT>=26){NotificationChannel c=manager().getNotificationChannel(AUDIBLE);result.put("audible",c!=null&&c.getImportance()>=3&&c.getSound()!=null);}
  else result.put("audible",true);
  return result;
 }
 @PluginMethod public void status(PluginCall call){call.resolve(state());}
 @PluginMethod public void enable(PluginCall call){
  getActivity().runOnUiThread(()->{
   if(NotificationManagerCompat.from(getContext()).areNotificationsEnabled()){call.resolve(state());return;}
   if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(getContext(),Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
    if(permissionCall!=null){call.reject("A notification permission request is already open");return;}
    permissionCall=call;
    try{permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);}catch(Exception e){permissionCall=null;call.reject("Notification permission request failed",e);}
   }else call.resolve(state());
  });
 }
 @PluginMethod public void openSettings(PluginCall call){
  getActivity().runOnUiThread(()->{try{
   Intent intent=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getContext().getPackageName());
   getActivity().startActivity(intent);call.resolve();
  }catch(Exception e){call.reject("Notification settings could not be opened",e);}});
 }
 @PluginMethod public void post(PluginCall call){
  if(!NotificationManagerCompat.from(getContext()).areNotificationsEnabled()){call.reject("Notifications are disabled");return;}
  boolean sound=Boolean.TRUE.equals(call.getBoolean("sound",true));String channel=sound?AUDIBLE:SILENT;
  if(Build.VERSION.SDK_INT>=26 && manager().getNotificationChannel(channel).getImportance()==0){call.reject("Notification channel is disabled");return;}
  int id=call.getInt("id",1);
  Intent intent=new Intent(getContext(),MainActivity.class).setAction(Intent.ACTION_MAIN).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
  JSObject extra=call.getObject("extra");if(extra!=null){intent.putExtra("tradingly_symbol",extra.optString("symbol"));intent.putExtra("tradingly_timeframe",extra.optString("timeframe"));}
  PendingIntent tap=PendingIntent.getActivity(getContext(),id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  NotificationCompat.Builder builder=new NotificationCompat.Builder(getContext(),channel).setSmallIcon(R.drawable.ic_stat_trend)
   .setContentTitle(call.getString("title","TRADINGLY")).setContentText(call.getString("body",""))
   .setStyle(new NotificationCompat.BigTextStyle().bigText(call.getString("body",""))).setContentIntent(tap).setAutoCancel(true)
   .setPriority(sound?NotificationCompat.PRIORITY_DEFAULT:NotificationCompat.PRIORITY_LOW).setSilent(!sound);
  if(Build.VERSION.SDK_INT<26&&sound)builder.setDefaults(Notification.DEFAULT_SOUND|Notification.DEFAULT_VIBRATE);
  try{manager().notify(id,builder.build());call.resolve();}catch(Exception e){call.reject("Notification delivery failed",e);}
 }
 @Override protected void handleOnNewIntent(Intent intent){
  String symbol=intent.getStringExtra("tradingly_symbol");if(symbol==null||symbol.isEmpty())return;
  JSObject data=new JSObject();data.put("symbol",symbol);data.put("timeframe",intent.getStringExtra("tradingly_timeframe"));notifyListeners("notificationTap",data,true);
 }
}
