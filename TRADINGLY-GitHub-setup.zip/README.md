# TRADINGLY build investigation

`tradingly-project.zip` contains the frozen 1.4.5 web app/scan worker and native Android project. The previous workflow accidentally built `do-it (1).zip`, a second-hand marketplace app, erased native Android source, and changed the app ID. This workflow selects the actual TRADINGLY project and retains `com.trendscanner.bybit`.

## Unresolved issue
On the real Android phone, Bybit, Binance and OKX returned Connection reset on both mobile data and Wi-Fi. The subsequent native OkHttp build also failed according to the user. Automated mocked/JVM tests passed but did not establish real-device success. This PR is not a confirmed scanning fix.

Run Actions → TRADINGLY Android investigation → Run workflow, selecting this branch. The artifact is a diagnostic debug APK and test reports. Debug signing differs from the original release signing certificate: it is not a drop-in update or a Play Store release. Preserve the original private signing key outside the repository.

Next investigation should capture native exception causes from a real device and compare direct Chrome API reachability with native transport, retaining identical market URLs and the 1.4.5 analysis rules. Do not replace the app with the unrelated marketplace ZIP or alter scanning filters to conceal transport failures.
