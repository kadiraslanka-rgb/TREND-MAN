import React from 'react';
import { ExternalLink, Calendar, BarChart2, Flame, Award, Clock } from 'lucide-react';
import { MajorBreakoutSignal } from '../types/scanner';

interface TrendCardProps {
  signal: MajorBreakoutSignal;
  onOpenChart: (signal: MajorBreakoutSignal) => void;
}

export const TrendCard: React.FC<TrendCardProps> = ({ signal, onOpenChart }) => {
  return (
    <div className="relative bg-slate-900 border-2 border-emerald-500/40 hover:border-emerald-500 rounded-2xl p-5 shadow-xl shadow-emerald-500/5 transition-all flex flex-col justify-between gap-4">
      {/* Top Banner */}
      <div>
        {/* Signal Tag */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <Flame className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
            <span>MAJÖR DÜŞEN TREND KIRILDI</span>
          </span>

          <span className="px-2.5 py-0.5 rounded-lg text-xs font-black bg-amber-500 text-slate-950 font-mono">
            {signal.timeframe}
          </span>
        </div>

        {/* COIN Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-white font-extrabold text-sm">
              {signal.symbol.slice(0, 3)}
            </div>
            <div>
              <h3 className="text-xl font-black text-white tracking-wide">{signal.symbol}</h3>
              <p className="text-[11px] text-slate-400">Bybit USDT Perpetual</p>
            </div>
          </div>

          <a
            href={`https://www.bybit.com/trade/usdt/${signal.symbol}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-xl transition-colors"
            title="Bybit'te Aç"
          >
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* Main Spec Grid (Strictly what the user requested) */}
      <div className="space-y-2.5 py-1">
        {/* TREND YAŞI */}
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/70 text-xs">
          <span className="text-slate-400 flex items-center gap-1.5 font-medium">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>TREND YAŞI:</span>
          </span>
          <span className="font-extrabold text-white font-mono text-sm">
            {signal.trendAgeDays} Gün{' '}
            <span className="text-[11px] text-slate-500 font-normal">
              ({signal.trendAgeBars} Bar)
            </span>
          </span>
        </div>

        {/* MAJÖR TEMAS SAYISI */}
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/70 text-xs">
          <span className="text-slate-400 flex items-center gap-1.5 font-medium">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>MAJÖR TEMAS SAYISI:</span>
          </span>
          <span className="font-extrabold text-amber-400 font-mono text-sm">
            {signal.majorTouchCount} Tepe{' '}
            {signal.majorTouchCount >= 3 && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold ml-1 border border-amber-500/30">
                3+ MAJÖR
              </span>
            )}
          </span>
        </div>

        {/* KIRILIM FİYATI */}
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs">
          <span className="text-emerald-400 flex items-center gap-1.5 font-semibold">
            <Flame className="w-3.5 h-3.5 text-emerald-400" />
            <span>KIRILIM FİYATI:</span>
          </span>
          <span className="font-mono font-black text-emerald-300 text-sm">
            ${signal.breakoutPrice.toFixed(4)}
          </span>
        </div>

        {/* KIRILIM ZAMANI */}
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/70 text-xs">
          <span className="text-slate-400 flex items-center gap-1.5 font-medium">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>KIRILIM ZAMANI:</span>
          </span>
          <span className="font-semibold text-slate-200 text-xs font-mono">
            {signal.breakoutTimeStr}
          </span>
        </div>
      </div>

      {/* Action Button: GRAFİĞİ AÇ */}
      <button
        onClick={() => onOpenChart(signal)}
        className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-black rounded-xl text-xs sm:text-sm shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
      >
        <BarChart2 className="w-4 h-4 stroke-[2.5]" />
        <span>GRAFİĞİ AÇ</span>
      </button>
    </div>
  );
};
