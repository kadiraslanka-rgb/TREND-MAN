import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  MajorBreakoutSignal,
  ScanFilterOptions,
  ScanProgress,
  SymbolInfo,
  Timeframe,
} from './types/scanner';
import { fetchAllActiveUsdtPerpetuals, fetchKlines, runWithConcurrency } from './services/bybit';
import { detectMajorBreakout } from './services/trend';
import {
  initNotificationService,
  sendBreakoutNotification,
  NotificationActionPayload,
} from './services/notificationService';
import { backgroundScanner } from './services/backgroundScanner';
import { Header } from './components/Header';
import { FilterBar } from './components/FilterBar';
import { TrendCard } from './components/TrendCard';
import { ChartModal } from './components/ChartModal';
import {
  Flame,
  AlertCircle,
  RefreshCw,
  ShieldCheck,
  Bell,
  Smartphone,
  CheckCircle2,
} from 'lucide-react';

const AVAILABLE_TIMEFRAMES: Timeframe[] = ['4H', '6H', '1D', '3D', '1W', '1M'];

export default function App() {
  const [symbols, setSymbols] = useState<SymbolInfo[]>([]);
  const [isLoadingSymbols, setIsLoadingSymbols] = useState<boolean>(true);
  const [initError, setInitError] = useState<string | null>(null);

  // Scanner state
  const [signals, setSignals] = useState<MajorBreakoutSignal[]>([]);
  const [selectedSignal, setSelectedSignal] = useState<MajorBreakoutSignal | null>(null);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [bgTrackingEnabled, setBgTrackingEnabled] = useState<boolean>(true);
  const [notificationTestSent, setNotificationTestSent] = useState<boolean>(false);

  // Filter state
  const [filters, setFilters] = useState<ScanFilterOptions>({
    timeframes: ['1D'], // default to 1D, user can select any of 4H, 6H, 1D, 3D, 1W, 1M
    minTouches: 2, // 2 or 3
    searchQuery: '',
  });

  // Scan progress state
  const [progress, setProgress] = useState<ScanProgress>({
    isScanning: false,
    isPaused: false,
    totalSymbols: 0,
    scannedSymbols: 0,
    currentSymbol: '',
    matchesCount: 0,
    speed: 0,
  });

  const stopRequestedRef = useRef<boolean>(false);
  const pauseRequestedRef = useRef<boolean>(false);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Sound alert
  const playBreakoutAlert = useCallback(() => {
    if (!soundEnabled) return;
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'triangle';
      osc1.frequency.setValueAtTime(880, now);
      osc1.frequency.exponentialRampToValueAtTime(1320, now + 0.25);

      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(587.33, now);
      osc2.frequency.exponentialRampToValueAtTime(880, now + 0.25);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.35);
      osc2.stop(now + 0.35);
    } catch {
      // Audio might be waiting for interaction
    }
  }, [soundEnabled]);

  // Handler when user taps a notification on Android or desktop
  const handleOpenFromNotification = useCallback(
    async (payload: NotificationActionPayload) => {
      // First check if already in signals state
      const existing = signals.find(
        (s) => s.symbol === payload.symbol && s.timeframe === payload.timeframe
      );
      if (existing) {
        setSelectedSignal(existing);
        return;
      }

      // If not yet in state, fetch klines on-demand and compute breakout to open chart
      try {
        const candles = await fetchKlines(payload.symbol, payload.timeframe as Timeframe, 200);
        const signal = detectMajorBreakout(candles, payload.symbol, payload.timeframe as Timeframe);
        if (signal) {
          setSelectedSignal(signal);
        }
      } catch (err) {
        console.error('Failed to load chart from notification click:', err);
      }
    },
    [signals]
  );

  // Initialize notifications, background scanner, and Bybit symbols
  useEffect(() => {
    let isMounted = true;

    // 1. Initialize Android / Web notification service & click listener
    initNotificationService((payload) => {
      handleOpenFromNotification(payload);
    });

    // 2. Setup background scanner listener
    const unsubscribeBg = backgroundScanner.onSignal((newSignal) => {
      setSignals((prev) => {
        const map = new Map<string, MajorBreakoutSignal>();
        for (const s of prev) map.set(`${s.symbol}-${s.timeframe}`, s);
        map.set(`${newSignal.symbol}-${newSignal.timeframe}`, newSignal);
        return Array.from(map.values());
      });
      playBreakoutAlert();
    });

    // 3. Load Bybit symbols
    async function loadSymbols() {
      setIsLoadingSymbols(true);
      setInitError(null);
      try {
        const list = await fetchAllActiveUsdtPerpetuals();
        if (!isMounted) return;
        setSymbols(list);
        setIsLoadingSymbols(false);

        // Start background scanner loop
        backgroundScanner.start(filters.timeframes);

        // Initial scan on all symbols for the selected timeframe
        if (list.length > 0) {
          triggerScan(list, ['1D']);
        }
      } catch (err) {
        if (!isMounted) return;
        setInitError(
          err instanceof Error
            ? err.message
            : 'Bybit verileri yüklenemedi. Lütfen internet bağlantınızı kontrol edin.'
        );
        setIsLoadingSymbols(false);
      }
    }

    loadSymbols();

    return () => {
      isMounted = false;
      stopRequestedRef.current = true;
      unsubscribeBg();
      backgroundScanner.stop();
    };
  }, []);

  // Update background scanner timeframes when filter changes
  useEffect(() => {
    backgroundScanner.setTimeframes(filters.timeframes);
  }, [filters.timeframes]);

  // Main Scanning Engine
  const triggerScan = async (
    targetSymbolsList?: SymbolInfo[],
    timeframesToScan?: Timeframe[]
  ) => {
    if (progress.isScanning) return;

    stopRequestedRef.current = false;
    pauseRequestedRef.current = false;

    // Bybit'teki TÜM aktif USDT Perpetual coinleri tara
    const targetSymbols = targetSymbolsList || symbols;
    const tfs = timeframesToScan || filters.timeframes;
    const totalItems = targetSymbols.length * tfs.length;

    setProgress({
      isScanning: true,
      isPaused: false,
      totalSymbols: totalItems,
      scannedSymbols: 0,
      currentSymbol: '',
      matchesCount: 0,
      speed: 0,
      startedAt: Date.now(),
    });

    const queue: Array<{ symbolInfo: SymbolInfo; tf: Timeframe }> = [];
    for (const sym of targetSymbols) {
      for (const tf of tfs) {
        queue.push({ symbolInfo: sym, tf });
      }
    }

    const discoveredSignals: MajorBreakoutSignal[] = [];
    const startTime = Date.now();

    try {
      await runWithConcurrency(
        queue,
        async (item) => {
          while (pauseRequestedRef.current && !stopRequestedRef.current) {
            await new Promise((r) => setTimeout(r, 200));
          }

          if (stopRequestedRef.current) {
            return null;
          }

          const { symbolInfo, tf } = item;
          const candles = await fetchKlines(symbolInfo.symbol, tf, 200);
          if (!candles || candles.length < 40) return null;

          // Strict major descending trendline breakout detector (UNTOUCHED)
          const signal = detectMajorBreakout(
            candles,
            symbolInfo.symbol,
            tf,
            symbolInfo.volume24hUsd,
            symbolInfo.change24h
          );

          return signal;
        },
        12, // 12 parallel workers
        async (completed, total, lastResult) => {
          const elapsedSec = Math.max(1, (Date.now() - startTime) / 1000);
          const currentSpeed = Math.round(completed / elapsedSec);

          if (lastResult) {
            discoveredSignals.push(lastResult);
            playBreakoutAlert();

            // Send notification only if not already sent for this coin + tf + breakout candle
            await sendBreakoutNotification(lastResult);

            setSignals((prev) => {
              const map = new Map<string, MajorBreakoutSignal>();
              for (const s of prev) {
                map.set(`${s.symbol}-${s.timeframe}`, s);
              }
              map.set(`${lastResult.symbol}-${lastResult.timeframe}`, lastResult);
              return Array.from(map.values());
            });
          }

          setProgress((prev) => ({
            ...prev,
            scannedSymbols: completed,
            matchesCount: discoveredSignals.length,
            speed: currentSpeed,
            currentSymbol: queue[Math.min(completed, queue.length - 1)]?.symbolInfo.symbol || '',
          }));
        },
        () => stopRequestedRef.current
      );
    } catch (err) {
      console.error('Scan error:', err);
    } finally {
      setProgress((prev) => ({
        ...prev,
        isScanning: false,
        isPaused: false,
        currentSymbol: '',
      }));
    }
  };

  const handleStartScan = () => {
    setSignals([]);
    triggerScan(symbols, filters.timeframes);
  };

  const handlePauseScan = () => {
    pauseRequestedRef.current = !pauseRequestedRef.current;
    setProgress((prev) => ({
      ...prev,
      isPaused: pauseRequestedRef.current,
    }));
  };

  const handleStopScan = () => {
    stopRequestedRef.current = true;
    setProgress((prev) => ({
      ...prev,
      isScanning: false,
      isPaused: false,
    }));
  };

  const toggleBackgroundTracking = () => {
    if (bgTrackingEnabled) {
      backgroundScanner.stop();
      setBgTrackingEnabled(false);
    } else {
      backgroundScanner.start(filters.timeframes);
      setBgTrackingEnabled(true);
    }
  };

  const handleSendTestNotification = async () => {
    // Send a sample notification to verify Android / Web notifications
    const sampleSignal: MajorBreakoutSignal = {
      symbol: 'VIRTUALUSDT',
      timeframe: '1D',
      signalName: '🔥 MAJÖR DÜŞEN TREND KIRILDI',
      trendAgeDays: 142,
      trendAgeBars: 142,
      majorTouchCount: 3,
      breakoutPrice: 0.7818,
      breakoutTime: Math.floor(Date.now() / 1000),
      breakoutTimeStr: 'Şimdi',
      trendlinePriceAtBreakout: 0.775,
      startPrice: 2.15,
      startDateStr: '12 May 2026',
      touches: [],
      klines: [],
      lineFormula: () => 0,
      volume24hUsd: 15000000,
      change24h: 8.4,
    };

    const sent = await sendBreakoutNotification(sampleSignal);
    playBreakoutAlert();
    setNotificationTestSent(true);
    setTimeout(() => setNotificationTestSent(false), 4000);
  };

  // Filter signals strictly based on active filters
  const filteredSignals = useMemo(() => {
    return signals
      .filter((s) => {
        if (!filters.timeframes.includes(s.timeframe)) return false;
        if (s.majorTouchCount < filters.minTouches) return false;
        if (filters.searchQuery.trim()) {
          const q = filters.searchQuery.trim().toUpperCase();
          if (!s.symbol.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (b.majorTouchCount !== a.majorTouchCount) {
          return b.majorTouchCount - a.majorTouchCount;
        }
        return b.trendAgeDays - a.trendAgeDays;
      });
  }, [signals, filters]);

  return (
    <div className="min-h-screen bg-[#070A11] text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Header */}
      <Header
        progress={progress}
        totalAvailableSymbols={symbols.length}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
        onStartScan={handleStartScan}
        onPauseScan={handlePauseScan}
        onStopScan={handleStopScan}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-5">
        {/* Android Background & Notification Banner */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 sm:p-4 flex flex-wrap items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs sm:text-sm font-black text-white">
                  Android APK & Arka Plan Bildirim Sistemi
                </span>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  {bgTrackingEnabled ? 'Arka Plan Aktif' : 'Durduruldu'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Uygulama kapalıyken de Bybit vadeli coinleri taranır • Gerçek kırılımda tekil Android bildirimi gönderilir • Dokununca grafik açılır
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSendTestNotification}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              {notificationTestSent ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Bildirim Gönderildi!</span>
                </>
              ) : (
                <>
                  <Bell className="w-3.5 h-3.5 text-amber-400" />
                  <span>Test Bildirimi Gönder</span>
                </>
              )}
            </button>

            <button
              onClick={toggleBackgroundTracking}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                bgTrackingEnabled
                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/25'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
              }`}
            >
              {bgTrackingEnabled ? 'Takip Açık' : 'Takibi Aç'}
            </button>
          </div>
        </div>

        {isLoadingSymbols ? (
          <div className="flex flex-col items-center justify-center py-24 gap-3">
            <RefreshCw className="w-10 h-10 text-emerald-500 animate-spin" />
            <p className="text-sm font-bold text-slate-200">
              Bybit USDT Perpetual çiftleri alınıyor...
            </p>
            <p className="text-xs text-slate-500">
              780+ aktif vadeli sözleşme taranmaya hazırlanıyor.
            </p>
          </div>
        ) : initError ? (
          <div className="p-6 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center justify-between gap-4 text-rose-300">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-rose-400 shrink-0" />
              <div>
                <h3 className="font-bold text-sm">Bağlantı Hatası</h3>
                <p className="text-xs text-rose-300/80">{initError}</p>
              </div>
            </div>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-rose-500 text-white rounded-xl text-xs font-bold hover:bg-rose-600 transition-colors"
            >
              Yeniden Dene
            </button>
          </div>
        ) : (
          <>
            {/* Filter Bar */}
            <FilterBar
              filters={filters}
              onChangeFilters={(updated) => setFilters((prev) => ({ ...prev, ...updated }))}
              availableTimeframes={AVAILABLE_TIMEFRAMES}
            />

            {/* Results Counter Banner */}
            <div className="flex items-center justify-between px-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="font-bold text-slate-300">
                  Gerçekleşen Majör Kırılımlar: <b className="text-emerald-400 font-mono text-sm">{filteredSignals.length}</b> Sinyal
                </span>
              </div>
              <div className="text-slate-500">
                Seçili Zaman Dilimleri: <b className="text-slate-300">{filters.timeframes.join(', ')}</b> | Asgari: <b className="text-amber-400">{filters.minTouches}+ Tepe</b>
              </div>
            </div>

            {/* Signals Grid */}
            {filteredSignals.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredSignals.map((signal, idx) => (
                  <TrendCard
                    key={`${signal.symbol}-${signal.timeframe}-${idx}`}
                    signal={signal}
                    onOpenChart={setSelectedSignal}
                  />
                ))}
              </div>
            ) : (
              /* High-discipline 0-signal explanatory state */
              <div className="p-10 text-center bg-slate-900/60 border border-slate-800 rounded-3xl space-y-4 max-w-2xl mx-auto my-6">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-400">
                  <ShieldCheck className="w-7 h-7 stroke-[2]" />
                </div>
                <div className="space-y-1.5">
                  <h3 className="text-base font-black text-white tracking-wide">
                    {progress.isScanning ? 'Tarama Devam Ediyor...' : 'Şu Anda Aktif Sinyal Yok'}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Bybit'teki 780+ coin taranıp <b className="text-amber-400">0 sinyal bulunması tamamen normaldir</b>.
                    Sinyal üretmek için kurallar asla gevşetilmez.
                  </p>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Yalnızca VIRTUAL ve ETHFI yapısındaki gibi, <b className="text-slate-300">aylarca süren majör düşen trendin son kapanan mumda yukarı kırıldığı (gerçek cross)</b> nadir ve yüksek kaliteli anlar tespit edilir.
                  </p>
                </div>

                {!progress.isScanning && (
                  <div className="pt-2">
                    <button
                      onClick={handleStartScan}
                      className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
                    >
                      Tüm Coinleri Yeniden Tara ({symbols.length} Çift)
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </main>

      {/* Chart Modal - Works identically on Web and Android APK */}
      <ChartModal signal={selectedSignal} onClose={() => setSelectedSignal(null)} />
    </div>
  );
}
