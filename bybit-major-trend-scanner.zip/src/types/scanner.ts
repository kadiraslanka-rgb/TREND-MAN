export type Timeframe = '4H' | '6H' | '1D' | '3D' | '1W' | '1M';

export interface KlineCandle {
  time: number; // Unix timestamp in seconds
  rawTime: number; // Unix timestamp in ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface SymbolInfo {
  symbol: string;
  baseCoin: string;
  lastPrice: number;
  change24h: number;
  volume24hUsd: number;
}

export interface BybitTicker {
  symbol: string;
  lastPrice: string;
  price24hPcnt: string;
  turnover24h: string;
  volume24h: string;
  highPrice24h: string;
  lowPrice24h: string;
}

export interface TrendTouch {
  index: number;
  time: number; // seconds
  dateStr: string;
  price: number;
  candleHigh: number;
}

export interface MajorBreakoutSignal {
  symbol: string;
  timeframe: Timeframe;
  signalName: '🔥 MAJÖR DÜŞEN TREND KIRILDI';
  trendAgeDays: number; // Trend Yaşı (Gün)
  trendAgeBars: number; // Trend Yaşı (Bar)
  majorTouchCount: number; // Majör Temas Sayısı (2, 3+)
  breakoutPrice: number; // Kırılım Fiyatı
  breakoutTime: number; // Kırılım Zamanı
  breakoutTimeStr: string; // Kırılım Zamanı formatlı
  trendlinePriceAtBreakout: number;
  startPrice: number;
  startDateStr: string;
  touches: TrendTouch[];
  klines: KlineCandle[];
  lineFormula: (barIndex: number) => number;
  volume24hUsd: number;
  change24h: number;
}

export interface ScanFilterOptions {
  timeframes: Timeframe[];
  minTouches: number; // 2 or 3
  searchQuery: string;
}

export interface ScanProgress {
  isScanning: boolean;
  isPaused: boolean;
  totalSymbols: number;
  scannedSymbols: number;
  currentSymbol: string;
  matchesCount: number;
  speed: number;
  startedAt?: number;
}
