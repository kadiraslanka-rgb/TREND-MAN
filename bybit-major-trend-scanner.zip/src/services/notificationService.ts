import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';
import { MajorBreakoutSignal } from '../types/scanner';

const STORAGE_NOTIFIED_KEY = 'bybit_trend_notified_signals_v1';
const CHANNEL_ID = 'major_breakouts';

export interface NotificationActionPayload {
  symbol: string;
  timeframe: string;
}

/**
 * Get the set of already notified signal IDs
 * Key format: `${symbol}_${timeframe}_${breakoutTime}`
 */
function getNotifiedSet(): Set<string> {
  try {
    const raw = localStorage.getItem(STORAGE_NOTIFIED_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

/**
 * Save a newly notified signal ID
 */
function markAsNotified(key: string): void {
  try {
    const set = getNotifiedSet();
    set.add(key);
    // Keep max 1000 items to avoid infinite storage growth
    const arr = Array.from(set).slice(-1000);
    localStorage.setItem(STORAGE_NOTIFIED_KEY, JSON.stringify(arr));
  } catch (e) {
    console.error('Failed to save notified key:', e);
  }
}

/**
 * Check if this exact breakout signal was already notified
 */
export function isSignalAlreadyNotified(signal: MajorBreakoutSignal): boolean {
  const key = `${signal.symbol}_${signal.timeframe}_${signal.breakoutTime}`;
  return getNotifiedSet().has(key);
}

/**
 * Initialize notification channels and listeners
 */
export async function initNotificationService(
  onNotificationClick?: (payload: NotificationActionPayload) => void
): Promise<boolean> {
  const isNative = Capacitor.isNativePlatform();

  if (isNative) {
    try {
      // 1. Request notification permission on Android 13+
      const permStatus = await LocalNotifications.checkPermissions();
      if (permStatus.display !== 'granted') {
        const req = await LocalNotifications.requestPermissions();
        if (req.display !== 'granted') {
          console.warn('Android notification permission not granted');
        }
      }

      // 2. Create High-Priority Notification Channel for Android
      await LocalNotifications.createChannel({
        id: CHANNEL_ID,
        name: 'Majör Trend Kırılım Sinyalleri',
        description: 'Uzun vadeli düşen majör trend kırılımlarında anında bildirim gönderir.',
        importance: 5, // High importance
        visibility: 1, // Public on lockscreen
        sound: 'beep.wav',
        vibration: true,
        lights: true,
        lightColor: '#10B981',
      });

      // 3. Listen for notification click to open the coin chart directly
      LocalNotifications.removeAllListeners();
      await LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
        const extra = action.notification.extra as NotificationActionPayload | undefined;
        if (extra?.symbol && onNotificationClick) {
          onNotificationClick(extra);
        }
      });

      return true;
    } catch (err) {
      console.error('Capacitor notifications init error:', err);
      return false;
    }
  } else {
    // Web environment: check/request Web Notifications API
    if ('Notification' in window) {
      if (Notification.permission === 'default') {
        try {
          await Notification.requestPermission();
        } catch {
          // Ignore
        }
      }
    }
    return true;
  }
}

/**
 * Send an Android or Web notification for a verified Major Trend Breakout.
 *
 * Requirements:
 * - SADECE gerçek MAJÖR DÜŞEN TREND KIRILIMI gerçekleştiğinde bildirim gönder.
 * - Aynı coin + timeframe + aynı trend kırılımı için yalnızca 1 bildirim gönder.
 * - Format:
 *   🔥 MAJÖR TREND KIRILDI
 *   VIRTUALUSDT • 1D
 *   Uzun vadeli düşen trend yukarı kırıldı.
 *   Kırılım: $0.7818
 */
export async function sendBreakoutNotification(signal: MajorBreakoutSignal): Promise<boolean> {
  const signalKey = `${signal.symbol}_${signal.timeframe}_${signal.breakoutTime}`;

  // Rule 5: Tekrar bildirim gönderme!
  if (getNotifiedSet().has(signalKey)) {
    return false;
  }

  const title = '🔥 MAJÖR TREND KIRILDI';
  const body = `${signal.symbol} • ${signal.timeframe}\nUzun vadeli düşen trend yukarı kırıldı.\nKırılım: $${signal.breakoutPrice.toFixed(4)}`;

  const isNative = Capacitor.isNativePlatform();

  if (isNative) {
    try {
      // Deterministic numeric notification ID
      const notifId = Math.abs(
        signal.symbol.split('').reduce((acc, char) => (acc << 5) - acc + char.charCodeAt(0), 0)
      ) % 100000;

      await LocalNotifications.schedule({
        notifications: [
          {
            title,
            body,
            id: notifId,
            channelId: CHANNEL_ID,
            schedule: { at: new Date(Date.now() + 100) },
            sound: 'beep.wav',
            smallIcon: 'ic_stat_name',
            actionTypeId: 'OPEN_CHART',
            extra: {
              symbol: signal.symbol,
              timeframe: signal.timeframe,
              breakoutPrice: signal.breakoutPrice,
              breakoutTime: signal.breakoutTime,
            },
          },
        ],
      });

      markAsNotified(signalKey);
      return true;
    } catch (err) {
      console.error('Failed to schedule native local notification:', err);
      return false;
    }
  } else {
    // Web / Desktop fallback
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        const notif = new Notification(title, {
          body,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: signalKey,
        });

        notif.onclick = () => {
          window.focus();
        };

        markAsNotified(signalKey);
        return true;
      } catch (err) {
        console.error('Web notification error:', err);
      }
    }
    // Mark as notified in storage anyway to prevent repeats
    markAsNotified(signalKey);
    return false;
  }
}
