import { KlineCandle, MajorBreakoutSignal, Timeframe, TrendTouch } from '../types/scanner';

interface PivotPoint {
  index: number;
  time: number;
  high: number;
}

/**
 * Format timestamp to readable Turkish date string (e.g. "30 Eyl 2026, 03:00")
 */
function formatDateTime(timeInSeconds: number): string {
  const d = new Date(timeInSeconds * 1000);
  return d.toLocaleDateString('tr-TR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatDate(timeInSeconds: number): string {
  const d = new Date(timeInSeconds * 1000);
  return d.toLocaleDateString('tr-TR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

/**
 * Minimum duration in days required for a trend to qualify as "Majör Uzun Süreli"
 * Rule 1 & Rule 6: Kısa vadeli kabul etme, aylarca devam eden ana düşen trendleri ara.
 */
const MIN_DURATION_DAYS: Record<Timeframe, number> = {
  '4H': 14,   // at least 14 days (84 bars)
  '6H': 16,   // at least 16 days (64 bars)
  '1D': 45,   // at least 45 days (months of downtrend)
  '3D': 90,   // at least 90 days
  '1W': 180,  // at least 6 months
  '1M': 365,  // at least 1 year
};

/**
 * Minimum bars required between the origin peak and the breakout candle
 */
const MIN_SPAN_BARS: Record<Timeframe, number> = {
  '4H': 60,
  '6H': 50,
  '1D': 35,
  '3D': 25,
  '1W': 20,
  '1M': 10,
};

/**
 * Rule 2: Mikro tepeleri trend teması sayma.
 * Detect prominent macro swing highs with substantial left/right lookback.
 */
export function findMacroSwingHighs(candles: KlineCandle[], timeframe: Timeframe): PivotPoint[] {
  // Use large lookback so micro zigzags are never treated as swing highs
  const lookback = ['4H', '6H'].includes(timeframe) ? 7 : 5;
  const pivots: PivotPoint[] = [];
  const n = candles.length;

  for (let i = lookback; i < n - lookback; i++) {
    const currentHigh = candles[i].high;
    let isPivot = true;

    // Check left bars
    for (let j = 1; j <= lookback; j++) {
      if (candles[i - j].high > currentHigh) {
        isPivot = false;
        break;
      }
    }

    if (!isPivot) continue;

    // Check right bars
    for (let j = 1; j <= lookback; j++) {
      if (candles[i + j].high > currentHigh) {
        isPivot = false;
        break;
      }
    }

    if (isPivot) {
      pivots.push({
        index: i,
        time: candles[i].time,
        high: currentHigh,
      });
    }
  }

  return pivots;
}

/**
 * STRICT SCANNER FOR MAJOR DESCENDING TRENDLINE BREAKOUTS
 *
 * Rules:
 * 1. Kısa vadeli düşen çizgileri kabul etme.
 * 2. Mikro tepeleri trend teması sayma.
 * 3. Trend çizgisi önemli MAJÖR swing high tepelerinden geçmeli.
 * 4. Ana tepeler Lower High yapısı oluşturmalı.
 * 5. Trend çizgisi belirgin şekilde aşağı eğimli olmalı (min %15 drop).
 * 6. Trend mümkün olduğunca uzun süreli olmalı (aylarca süren).
 * 7. Aynı bölgedeki küçük tepeleri ayrı temaslar olarak sayma (min 10 bar mesafe).
 * 8. Fiyat geçmişte çizginin sürekli üstüne-altına geçmişse o trendi REDDET.
 * 9. KIR -> DÜŞ -> KIR -> DÜŞ şeklindeki çizgileri kesinlikle sinyal olarak verme.
 * SİNYAL KURALI:
 * - Önceki KAPANMIŞ mum çizginin altında, son KAPANMIŞ mum çizginin üzerinde.
 * - Sadece SON KAPANAN MUMDA gerçekleşen kırılımı göster (5, 10, 20 mum önce kırılmışlar elenir).
 * - Fitil yetmez, mum kapanışı şart.
 */
export function detectMajorBreakout(
  candles: KlineCandle[],
  symbol: string,
  timeframe: Timeframe,
  volume24hUsd: number = 0,
  change24h: number = 0
): MajorBreakoutSignal | null {
  if (!candles || candles.length < 40) {
    return null;
  }

  const n = candles.length;
  const pivots = findMacroSwingHighs(candles, timeframe);

  if (pivots.length < 2) {
    return null;
  }

  const minDurationDays = MIN_DURATION_DAYS[timeframe];
  const minSpanBars = MIN_SPAN_BARS[timeframe];

  // In Bybit klines, the last candle (index n - 1) is currently forming / live.
  // The last COMPLETED closed candle is at index n - 2 (or n - 1 if close time arrived).
  // We evaluate breakout candidates strictly on the freshest closed candle:
  // Candidate 1: Breakout on candle n - 1 (if it closed or freshly crossed)
  // Candidate 2: Breakout on candle n - 2 (the latest definitely-closed candle)
  const candidatePairs = [
    { prevIdx: n - 2, currIdx: n - 1 },
    { prevIdx: n - 3, currIdx: n - 2 },
  ];

  let bestSignal: MajorBreakoutSignal | null = null;

  for (const pair of candidatePairs) {
    if (pair.prevIdx < 0 || pair.currIdx >= n) continue;

    const prevCandle = candles[pair.prevIdx];
    const currCandle = candles[pair.currIdx];

    // Iterate over candidate major swing high pairs
    for (let p1 = 0; p1 < pivots.length; p1++) {
      const pivot1 = pivots[p1];

      // Trend must have originated at least minSpanBars ago
      if (pair.currIdx - pivot1.index < minSpanBars) {
        continue;
      }

      // Check duration in days
      const trendAgeDays = Math.round((currCandle.time - pivot1.time) / 86400);
      if (trendAgeDays < minDurationDays) {
        continue;
      }

      for (let p2 = p1 + 1; p2 < pivots.length; p2++) {
        const pivot2 = pivots[p2];

        // Anchor 2 must be prior to the breakout candle
        if (pivot2.index >= pair.prevIdx) {
          continue;
        }

        // Rule 4: Lower High structure!
        // Pivot 2 MUST be distinctly lower than Pivot 1
        if (pivot2.high >= pivot1.high) {
          continue;
        }

        // Significant bar separation between the two major peaks (at least 10-15 bars)
        const peakSpan = pivot2.index - pivot1.index;
        if (peakSpan < 10) {
          continue;
        }

        // Linear slope: change in price per candle bar index
        const slope = (pivot2.high - pivot1.high) / peakSpan;
        if (slope >= 0) continue;

        const lineFormula = (barIndex: number) => {
          return pivot1.high + slope * (barIndex - pivot1.index);
        };

        const lineAtCurr = lineFormula(pair.currIdx);
        const lineAtPrev = lineFormula(pair.prevIdx);

        if (lineAtCurr <= 0 || lineAtPrev <= 0) continue;

        // Rule 5: Trend çizgisi belirgin şekilde aşağı eğimli olmalı.
        // Total percentage drop along the line from start to current must be at least 15%
        const totalDropPct = (pivot1.high - lineAtCurr) / pivot1.high;
        if (totalDropPct < 0.15) {
          continue;
        }

        // Rule 8 & 9: Strict resistance integrity!
        // Fiyat geçmişte çizginin sürekli üstüne-altına geçmişse o trendi REDDET.
        // KIR -> DÜŞ -> KIR -> DÜŞ şeklindeki çizgileri kesinlikle sinyal olarak verme.
        // NO candle prior to the breakout candle could have closed above the trendline!
        let hadPriorBreach = false;
        for (let i = pivot1.index; i < pair.currIdx; i++) {
          const lineY = lineFormula(i);
          // If price closed above the line (+0.8% margin), line was invalidated in the past!
          if (candles[i].close > lineY * 1.008) {
            hadPriorBreach = true;
            break;
          }
        }

        if (hadPriorBreach) {
          continue;
        }

        // SİNYAL KURALI:
        // Önceki KAPANMIŞ mum trend çizgisinin altında olmalı:
        if (prevCandle.close > lineAtPrev) {
          continue; // was not below
        }

        // Son KAPANMIŞ mum trend çizgisinin üzerinde kapanmış olmalı:
        // Fitil yetmez! Mum KAPANIŞI şart!
        if (currCandle.close <= lineAtCurr) {
          continue; // curr did not close above the line
        }

        // Rule 3 & 7: Count meaningful touches on the trendline
        // Aynı bölgedeki küçük tepeleri ayrı temaslar olarak sayma (min 10 bar mesafe)
        const touches: TrendTouch[] = [];
        let lastTouchIdx = -100;

        for (let i = pivot1.index; i <= pair.prevIdx; i++) {
          const lineY = lineFormula(i);
          const candleHigh = candles[i].high;
          const diffPct = Math.abs(candleHigh - lineY) / lineY;

          // Wick came within 2% of the trendline and candle closed below it
          if (diffPct <= 0.02 && candles[i].close <= lineY * 1.008) {
            // Must be at least 8-10 bars apart from the previous touch to avoid clustering
            if (i - lastTouchIdx >= 8) {
              touches.push({
                index: i,
                time: candles[i].time,
                dateStr: formatDate(candles[i].time),
                price: lineY,
                candleHigh,
              });
              lastTouchIdx = i;
            }
          }
        }

        // Must have at least 2 distinct major touches (preferably 3+)
        if (touches.length < 2) {
          continue;
        }

        // We found a genuine MAJOR DESCENDING TRENDLINE BREAKOUT ON THE LATEST CANDLE!
        const trendAgeBars = pair.currIdx - pivot1.index;

        const signal: MajorBreakoutSignal = {
          symbol,
          timeframe,
          signalName: '🔥 MAJÖR DÜŞEN TREND KIRILDI',
          trendAgeDays,
          trendAgeBars,
          majorTouchCount: touches.length,
          breakoutPrice: currCandle.close,
          breakoutTime: currCandle.time,
          breakoutTimeStr: formatDateTime(currCandle.time),
          trendlinePriceAtBreakout: lineAtCurr,
          startPrice: pivot1.high,
          startDateStr: formatDate(pivot1.time),
          touches,
          klines: candles,
          lineFormula,
          volume24hUsd,
          change24h,
        };

        // If multiple candidate lines cross on the same pair, pick the one with
        // highest touches, or longest duration
        if (
          !bestSignal ||
          signal.majorTouchCount > bestSignal.majorTouchCount ||
          (signal.majorTouchCount === bestSignal.majorTouchCount &&
            signal.trendAgeDays > bestSignal.trendAgeDays)
        ) {
          bestSignal = signal;
        }
      }
    }
  }

  return bestSignal;
}
