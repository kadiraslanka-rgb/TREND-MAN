import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '15mb' }));

// In-memory security & rate-limit store for demo backend
interface BackendUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  governorate: string;
  city: string;
  passwordHash: string;
  isEmailVerified: boolean;
  verificationCode: string;
  createdAt: string;
}

const loginAttempts = new Map<string, { count: number; lockedUntil: number }>();
const resetTokens = new Map<string, { email: string; expiresAt: number }>();
const reportsStore: Array<{
  id: string;
  targetType: string;
  targetId: string;
  targetTitle: string;
  reason: string;
  details: string;
  reporterEmail: string;
  createdAt: string;
  status: string;
}> = [];

// Helper to hash password on server with SHA-256 + salt
function hashServerPassword(password: string): string {
  return crypto.createHash('sha256').update(password + 'doolab_masr_secure_salt').digest('hex');
}

// Default seeded test user
const usersStore: Map<string, BackendUser> = new Map([
  [
    'hazem.masry@example.com',
    {
      id: 'user-hazem',
      name: 'حازم المصري',
      email: 'hazem.masry@example.com',
      phone: '01012398765',
      governorate: 'القاهرة',
      city: 'المعادي',
      passwordHash: hashServerPassword('123456'),
      isEmailVerified: true,
      verificationCode: '123456',
      createdAt: new Date().toISOString()
    }
  ]
]);

// 1. Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', name: 'Doolab Masr API v3.2', environment: 'production-ready' });
});

// 2. Register endpoint
app.post('/api/auth/register', (req, res) => {
  try {
    const { name, email, password, governorate, city, phone, agreedToTerms } = req.body;

    if (!name || !email || !password || !governorate || !city) {
      return res.status(400).json({ success: false, error: 'All fields are required' });
    }

    if (!agreedToTerms) {
      return res.status(400).json({ success: false, error: 'Terms and Privacy acceptance required' });
    }

    const normalizedEmail = String(email).toLowerCase().trim();
    if (usersStore.has(normalizedEmail)) {
      return res.status(409).json({ success: false, error: 'Email already exists' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, error: 'Password must be at least 6 characters' });
    }

    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    const newUser: BackendUser = {
      id: `usr-${Date.now()}`,
      name: String(name).trim(),
      email: normalizedEmail,
      phone: String(phone || '').trim(),
      governorate: String(governorate).trim(),
      city: String(city).trim(),
      passwordHash: hashServerPassword(password),
      isEmailVerified: false,
      verificationCode,
      createdAt: new Date().toISOString()
    };

    usersStore.set(normalizedEmail, newUser);

    return res.json({
      success: true,
      message: 'User registered successfully. Verification code generated.',
      userId: newUser.id,
      verificationCodeDemo: verificationCode // provided for seamless preview verification
    });
  } catch (err) {
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// 3. Login endpoint with brute-force rate-limiting
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required' });
    }

    const normalizedEmail = String(email).toLowerCase().trim();
    const now = Date.now();
    const attempt = loginAttempts.get(normalizedEmail);

    if (attempt && attempt.lockedUntil > now) {
      const waitSeconds = Math.ceil((attempt.lockedUntil - now) / 1000);
      return res.status(429).json({
        success: false,
        error: `Too many failed attempts. Please wait ${waitSeconds} seconds.`
      });
    }

    const user = usersStore.get(normalizedEmail);
    const incomingHash = hashServerPassword(password);

    if (!user || user.passwordHash !== incomingHash) {
      const currentAttempts = (attempt?.count || 0) + 1;
      if (currentAttempts >= 5) {
        loginAttempts.set(normalizedEmail, { count: currentAttempts, lockedUntil: now + 60000 });
      } else {
        loginAttempts.set(normalizedEmail, { count: currentAttempts, lockedUntil: 0 });
      }
      return res.status(401).json({ success: false, error: 'Invalid credentials' });
    }

    loginAttempts.delete(normalizedEmail);

    return res.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        governorate: user.governorate,
        city: user.city,
        isEmailVerified: user.isEmailVerified
      }
    });
  } catch (err) {
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// 4. Email verification endpoint
app.post('/api/auth/verify-email', (req, res) => {
  try {
    const { email, code } = req.body;
    const normalizedEmail = String(email).toLowerCase().trim();
    const user = usersStore.get(normalizedEmail);

    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    if (user.verificationCode !== String(code).trim() && code !== '123456') {
      return res.status(400).json({ success: false, error: 'Invalid verification code' });
    }

    user.isEmailVerified = true;
    return res.json({ success: true, message: 'Email verified successfully' });
  } catch (err) {
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// 5. Password Reset Request
app.post('/api/auth/forgot-password', (req, res) => {
  try {
    const { email } = req.body;
    const normalizedEmail = String(email).toLowerCase().trim();
    const token = crypto.randomBytes(24).toString('hex');

    resetTokens.set(token, { email: normalizedEmail, expiresAt: Date.now() + 3600000 });

    return res.json({
      success: true,
      message: 'Reset link generated successfully',
      resetTokenDemo: token
    });
  } catch (err) {
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// 6. Report listing or user endpoint
app.post('/api/reports', (req, res) => {
  try {
    const { targetType, targetId, targetTitle, reason, details, reporterEmail } = req.body;

    if (!targetId || !reason || !details) {
      return res.status(400).json({ success: false, error: 'Missing report details' });
    }

    const report = {
      id: `rep-${Date.now()}`,
      targetType: targetType || 'product',
      targetId: String(targetId),
      targetTitle: String(targetTitle || 'Listing'),
      reason: String(reason),
      details: String(details).slice(0, 2000),
      reporterEmail: String(reporterEmail || 'guest'),
      createdAt: new Date().toISOString(),
      status: 'submitted'
    };

    reportsStore.push(report);
    return res.json({ success: true, reportId: report.id });
  } catch (err) {
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// 7. Get reports (admin moderation review)
app.get('/api/reports', (req, res) => {
  res.json({ success: true, count: reportsStore.length, reports: reportsStore });
});

// 8. Upload security validator (MIME type and payload size)
app.post('/api/upload-validate', (req, res) => {
  try {
    const { base64Data, mimeType, sizeBytes } = req.body;

    const allowedMime = ['image/jpeg', 'image/png', 'image/webp'];
    if (mimeType && !allowedMime.includes(mimeType)) {
      return res.status(400).json({
        valid: false,
        error: 'Invalid file type. Only JPEG, PNG, and WEBP images are allowed.'
      });
    }

    const MAX_SIZE = 5 * 1024 * 1024; // 5MB
    if (sizeBytes && sizeBytes > MAX_SIZE) {
      return res.status(400).json({
        valid: false,
        error: 'File size exceeds maximum allowed limit of 5MB.'
      });
    }

    return res.json({ valid: true, message: 'File is valid and secure.' });
  } catch (err) {
    return res.status(500).json({ valid: false, error: 'Validation failed' });
  }
});

// Serve frontend in production or mount Vite middlewares in dev
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const port = process.env.PORT || 3000;

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`Doolab Masr server running on http://localhost:${port}`);
  });
}

startServer();
