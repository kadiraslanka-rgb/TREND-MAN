import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Language,
  FilterState,
  Conversation,
  Seller,
  LegalDocumentType,
  Category,
  CartItem,
  ScreenType,
  ReportReason
} from '../types';
import { INITIAL_PRODUCTS } from '../data/mockProducts';
import { TRANSLATIONS } from '../i18n/translations';
import { useAuth } from './AuthContext';

interface ReportTargetData {
  targetType: 'product' | 'user';
  targetId: string;
  targetTitle: string;
}

interface AppContextType {
  // Navigation & Screens
  currentScreen: ScreenType;
  navigateTo: (screen: ScreenType) => void;
  goBack: () => void;
  canGoBack: boolean;

  // Language & i18n
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (typeof TRANSLATIONS)['ar'];

  // Products
  products: Product[];
  filteredProducts: Product[];
  selectedProduct: Product | null;
  openProductDetail: (product: Product) => void;
  addProduct: (product: Omit<Product, 'id' | 'createdAt' | 'views' | 'seller'>) => Product;
  selectedCategory: Category | null;
  openCategoryPage: (cat: Category) => void;

  // Cart (Requirement 11)
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  isInCart: (productId: string) => boolean;

  // Seller & Profile
  selectedSeller: Seller | null;
  openSellerProfile: (seller: Seller) => void;

  // Favorites
  favorites: string[];
  toggleFavorite: (productId: string) => void;
  isFavorite: (productId: string) => boolean;

  // Messaging & Chat
  conversations: Conversation[];
  activeConversation: Conversation | null;
  startChatWithSeller: (product: Product) => void;
  selectConversation: (conversation: Conversation) => void;
  sendMessage: (conversationId: string, text: string, isOffer?: boolean, offerAmount?: number) => void;
  respondToOffer: (conversationId: string, messageId: string, status: 'accepted' | 'rejected') => void;

  // Search & Filters
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;

  // Legal & Reports (Requirement 7 & 8)
  selectedLegalDoc: LegalDocumentType;
  openLegalDoc: (doc: LegalDocumentType) => void;
  reportTargetData: ReportTargetData | null;
  openReportPage: (targetType: 'product' | 'user', targetId: string, targetTitle: string) => void;
  submitReport: (reason: ReportReason, details: string) => Promise<{ success: boolean }>;
}

const defaultFilters: FilterState = {
  sortBy: 'newest',
  searchQuery: ''
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, isAuthenticated } = useAuth();

  // Screen navigation state
  // If first launch without auth, show welcome_auth screen (Requirement 9)
  const [currentScreen, setCurrentScreen] = useState<ScreenType>(() => {
    return isAuthenticated ? 'home' : 'welcome_auth';
  });

  const [navigationStack, setNavigationStack] = useState<ScreenType[]>([]);

  // When auth state changes, handle redirection
  useEffect(() => {
    if (!isAuthenticated && currentScreen !== 'welcome_auth') {
      // User logged out
      setCurrentScreen('welcome_auth');
      setNavigationStack([]);
    }
  }, [isAuthenticated]);

  const navigateTo = (screen: ScreenType) => {
    setNavigationStack((prev) => [...prev, currentScreen]);
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const goBack = () => {
    if (navigationStack.length > 0) {
      const prev = navigationStack[navigationStack.length - 1];
      setNavigationStack((prevStack) => prevStack.slice(0, -1));
      setCurrentScreen(prev);
    } else {
      // Fallback to home
      setCurrentScreen('home');
    }
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  // Products state
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('doolab_products_v3');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('doolab_products_v3', JSON.stringify(products));
    } catch {}
  }, [products]);

  // Language state
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('doolab_lang');
      return (saved as Language) || 'ar';
    } catch {
      return 'ar';
    }
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('doolab_lang', lang);
    } catch {}
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  };

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const t = TRANSLATIONS[language] || TRANSLATIONS.ar;

  // Cart state (Requirement 11)
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('doolab_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('doolab_cart', JSON.stringify(cart));
    } catch {}
  }, [cart]);

  const addToCart = (product: Product) => {
    setCart((prev) => {
      if (prev.some((item) => item.productId === product.id)) return prev;
      return [...prev, { id: `cart-${Date.now()}`, productId: product.id, product, addedAt: new Date().toISOString() }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.productId !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const isInCart = (productId: string) => {
    return cart.some((item) => item.productId === productId);
  };

  // Favorites state
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('doolab_favs');
      return saved ? JSON.parse(saved) : ['prod-1', 'prod-2'];
    } catch {
      return ['prod-1', 'prod-2'];
    }
  });

  const toggleFavorite = (productId: string) => {
    setFavorites((prev) => {
      const next = prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId];
      try {
        localStorage.setItem('doolab_favs', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const isFavorite = (productId: string) => favorites.includes(productId);

  // Selected entities for deep pages
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedSeller, setSelectedSeller] = useState<Seller | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [selectedLegalDoc, setSelectedLegalDoc] = useState<LegalDocumentType>('terms');
  const [reportTargetData, setReportTargetData] = useState<ReportTargetData | null>(null);

  const openProductDetail = (product: Product) => {
    setSelectedProduct(product);
    navigateTo('product_detail');
  };

  const openSellerProfile = (seller: Seller) => {
    setSelectedSeller(seller);
    navigateTo('seller_profile');
  };

  const openCategoryPage = (cat: Category) => {
    setSelectedCategory(cat);
    navigateTo('category');
  };

  const openLegalDoc = (doc: LegalDocumentType) => {
    setSelectedLegalDoc(doc);
    navigateTo(doc as ScreenType);
  };

  const openReportPage = (targetType: 'product' | 'user', targetId: string, targetTitle: string) => {
    setReportTargetData({ targetType, targetId, targetTitle });
    navigateTo('report_problem');
  };

  const submitReport = async (reason: ReportReason, details: string) => {
    if (!reportTargetData) return { success: false };

    try {
      await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetType: reportTargetData.targetType,
          targetId: reportTargetData.targetId,
          targetTitle: reportTargetData.targetTitle,
          reason,
          details,
          reporterEmail: currentUser?.email || 'guest'
        })
      });
    } catch {}

    return { success: true };
  };

  // Conversations & Messaging
  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: 'conv-1',
      productId: 'prod-1',
      product: INITIAL_PRODUCTS[0],
      otherUser: INITIAL_PRODUCTS[0].seller,
      messages: [
        {
          id: 'm1',
          senderId: INITIAL_PRODUCTS[0].seller.id,
          text: 'أهلاً بحضرتك يا فندم! الموبايل متاح وبحالة ممتازة وجاهز للمعاينة في التجمع.',
          timestamp: '10:30 ص'
        },
        {
          id: 'm2',
          senderId: 'user-me',
          text: 'تمام، هل ممكن نتفاوض على 27,500 ج.م والمقابلة اليوم في التجمع الخامس؟',
          timestamp: '10:35 ص',
          isOffer: true,
          offerAmount: 27500,
          offerStatus: 'pending'
        }
      ],
      lastMessage: 'عرض سعر بقيمة 27,500 ج.م',
      lastMessageTime: '10:35 ص',
      unreadCount: 1
    }
  ]);

  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);

  const startChatWithSeller = (product: Product) => {
    const existing = conversations.find(
      (c) => c.productId === product.id && c.otherUser.id === product.seller.id
    );

    if (existing) {
      setActiveConversation(existing);
      navigateTo('conversation');
      return;
    }

    const newConv: Conversation = {
      id: `conv-${Date.now()}`,
      productId: product.id,
      product,
      otherUser: product.seller,
      messages: [
        {
          id: `msg-${Date.now()}`,
          senderId: product.seller.id,
          text: `مرحباً بك! شكراً لاهتمامك بـ "${product.title}". أنا متاح للرد على أي استفسار أو تحديد موعد المعاينة.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ],
      lastMessage: 'مرحباً بك! شكراً لاهتمامك...',
      lastMessageTime: 'الآن',
      unreadCount: 0
    };

    setConversations((prev) => [newConv, ...prev]);
    setActiveConversation(newConv);
    navigateTo('conversation');
  };

  const selectConversation = (conv: Conversation) => {
    setActiveConversation(conv);
    navigateTo('conversation');
  };

  const sendMessage = (conversationId: string, text: string, isOffer = false, offerAmount?: number) => {
    const newMsg: any = {
      id: `m-${Date.now()}`,
      senderId: currentUser?.id || 'me',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isOffer,
      offerAmount,
      offerStatus: isOffer ? 'pending' : undefined
    };

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          return {
            ...c,
            messages: [...c.messages, newMsg],
            lastMessage: text,
            lastMessageTime: 'الآن'
          };
        }
        return c;
      })
    );

    if (activeConversation && activeConversation.id === conversationId) {
      setActiveConversation((prev) => (prev ? { ...prev, messages: [...prev.messages, newMsg] } : null));
    }
  };

  const respondToOffer = (conversationId: string, messageId: string, status: 'accepted' | 'rejected') => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          return {
            ...c,
            messages: c.messages.map((m) => (m.id === messageId ? { ...m, offerStatus: status } : m))
          };
        }
        return c;
      })
    );

    if (activeConversation && activeConversation.id === conversationId) {
      setActiveConversation((prev) =>
        prev
          ? {
              ...prev,
              messages: prev.messages.map((m) => (m.id === messageId ? { ...m, offerStatus: status } : m))
            }
          : null
      );
    }
  };

  const addProduct = (newProdData: Omit<Product, 'id' | 'createdAt' | 'views' | 'seller'>): Product => {
    const sellerUser = currentUser || {
      id: 'usr-guest',
      name: 'مستخدم دولاب مصر',
      email: 'user@doolab.eg',
      phone: '01000000000',
      governorate: newProdData.location.governorate,
      city: newProdData.location.city,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      isEmailVerified: true,
      memberSince: new Date().getFullYear().toString(),
      rating: 5.0,
      reviewCount: 1,
      activeListingsCount: 1,
      soldCount: 0,
      responseRate: 'خلال دقائق',
      verified: true
    };

    const created: Product = {
      ...newProdData,
      id: `prod-${Date.now()}`,
      createdAt: 'الآن',
      views: 1,
      seller: sellerUser
    };

    setProducts((prev) => [created, ...prev]);
    return created;
  };

  // Filters & search
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const resetFilters = () => setFilters(defaultFilters);

  const filteredProducts = products.filter((p) => {
    if (filters.searchQuery) {
      const q = filters.searchQuery.toLowerCase();
      const matchTitle = p.title.toLowerCase().includes(q);
      const matchDesc = p.description.toLowerCase().includes(q);
      const matchBrand = (p.brand || '').toLowerCase().includes(q);
      if (!matchTitle && !matchDesc && !matchBrand) return false;
    }

    if (filters.categoryId && p.categoryId !== filters.categoryId) return false;
    if (filters.subcategoryId && p.subcategoryId !== filters.subcategoryId) return false;
    if (filters.governorate && p.location.governorate !== filters.governorate) return false;
    if (filters.city && p.location.city !== filters.city) return false;
    if (filters.minPrice !== undefined && p.price < filters.minPrice) return false;
    if (filters.maxPrice !== undefined && p.price > filters.maxPrice) return false;
    if (filters.deliveryMethod && p.deliveryMethod !== filters.deliveryMethod && p.deliveryMethod !== 'both') return false;

    return true;
  });

  return (
    <AppContext.Provider
      value={{
        currentScreen,
        navigateTo,
        goBack,
        canGoBack: navigationStack.length > 0 || currentScreen !== 'home',
        language,
        setLanguage,
        t,
        products,
        filteredProducts,
        selectedProduct,
        openProductDetail,
        addProduct,
        selectedCategory,
        openCategoryPage,
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        isInCart,
        selectedSeller,
        openSellerProfile,
        favorites,
        toggleFavorite,
        isFavorite,
        conversations,
        activeConversation,
        startChatWithSeller,
        selectConversation,
        sendMessage,
        respondToOffer,
        filters,
        setFilters,
        resetFilters,
        selectedLegalDoc,
        openLegalDoc,
        reportTargetData,
        openReportPage,
        submitReport
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
