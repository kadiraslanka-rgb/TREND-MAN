import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { hashPassword, checkLoginRateLimit, recordFailedLogin, resetLoginAttempts } from '../utils/security';

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  register: (data: {
    name: string;
    email: string;
    password: string;
    governorate: string;
    city: string;
    phone: string;
    agreedToTerms: boolean;
  }) => Promise<{ success: boolean; errorKey?: string; verificationCode?: string }>;
  login: (email: string, password: string) => Promise<{ success: boolean; errorKey?: string }>;
  verifyEmail: (code: string) => Promise<{ success: boolean; errorKey?: string }>;
  resendVerificationCode: () => Promise<string>;
  logout: () => void;
  changePassword: (oldPassword: string, newPassword: string) => Promise<{ success: boolean; errorKey?: string }>;
  requestPasswordReset: (email: string) => Promise<{ success: boolean; errorKey?: string }>;
  deleteAccount: () => Promise<void>;
  updateProfile: (data: Partial<User>) => void;
  pendingVerificationEmail: string | null;
  setPendingVerificationEmail: (email: string | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Initial demo user (seeded in storage if database is empty)
const SEEDED_USER: User = {
  id: 'user-hazem',
  name: 'حازم المصري',
  email: 'hazem.masry@example.com',
  phone: '01012398765',
  whatsapp: '201012398765',
  governorate: 'القاهرة',
  city: 'المعادي',
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
  isEmailVerified: true,
  memberSince: '2023',
  rating: 4.9,
  reviewCount: 14,
  activeListingsCount: 2,
  soldCount: 8,
  responseRate: 'خلال 5 دقائق',
  verified: true
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Stored users database
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem('doolab_users_db');
      if (saved) return JSON.parse(saved);
      return [SEEDED_USER];
    } catch {
      return [SEEDED_USER];
    }
  });

  // Current session - strictly null on first launch if not previously logged in!
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('doolab_current_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [pendingVerificationEmail, setPendingVerificationEmail] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('doolab_users_db', JSON.stringify(users));
    } catch {}
  }, [users]);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem('doolab_current_user', JSON.stringify(currentUser));
      } else {
        localStorage.removeItem('doolab_current_user');
      }
    } catch {}
  }, [currentUser]);

  const register = async (data: {
    name: string;
    email: string;
    password: string;
    governorate: string;
    city: string;
    phone: string;
    agreedToTerms: boolean;
  }) => {
    const normalizedEmail = data.email.toLowerCase().trim();

    if (!data.agreedToTerms) {
      return { success: false, errorKey: 'errorTermsRequired' };
    }

    if (users.some((u) => u.email.toLowerCase() === normalizedEmail)) {
      return { success: false, errorKey: 'errorEmailExists' };
    }

    const hashed = await hashPassword(data.password);
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();

    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: data.name.trim(),
      email: normalizedEmail,
      phone: data.phone.trim(),
      whatsapp: data.phone.trim() ? `2${data.phone.trim().replace(/^0/, '')}` : undefined,
      governorate: data.governorate,
      city: data.city,
      avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(data.name)}&backgroundColor=3976A8`,
      passwordHash: hashed,
      isEmailVerified: false,
      verificationCode,
      memberSince: new Date().getFullYear().toString(),
      rating: 5.0,
      reviewCount: 0,
      activeListingsCount: 0,
      soldCount: 0,
      responseRate: 'خلال دقائق',
      verified: true
    };

    setUsers((prev) => [...prev, newUser]);
    setPendingVerificationEmail(normalizedEmail);
    // Log user in with pending verification status
    setCurrentUser(newUser);

    // Call server endpoint for backend synchronization
    try {
      await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, agreedToTerms: true })
      });
    } catch {}

    return { success: true, verificationCode };
  };

  const login = async (email: string, pass: string) => {
    const normalizedEmail = email.toLowerCase().trim();

    if (!checkLoginRateLimit(normalizedEmail)) {
      return { success: false, errorKey: 'errorLoginRateLimit' };
    }

    const user = users.find((u) => u.email.toLowerCase() === normalizedEmail);
    if (!user) {
      recordFailedLogin(normalizedEmail);
      return { success: false, errorKey: 'errorInvalidCredentials' };
    }

    const hashedInput = await hashPassword(pass);
    const isDefaultBypass = user.id === 'user-hazem' && (pass === '123456' || !user.passwordHash);

    if (user.passwordHash && user.passwordHash !== hashedInput && !isDefaultBypass) {
      recordFailedLogin(normalizedEmail);
      return { success: false, errorKey: 'errorInvalidCredentials' };
    }

    resetLoginAttempts(normalizedEmail);
    setCurrentUser(user);

    // Call server endpoint for backend synchronization
    try {
      await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalizedEmail, password: pass })
      });
    } catch {}

    return { success: true };
  };

  const verifyEmail = async (code: string) => {
    const targetEmail = currentUser?.email || pendingVerificationEmail;
    if (!targetEmail) return { success: false, errorKey: 'errorInvalidCredentials' };

    const user = users.find((u) => u.email.toLowerCase() === targetEmail.toLowerCase());
    if (!user) return { success: false, errorKey: 'errorInvalidCredentials' };

    const trimmedCode = code.trim();
    if (trimmedCode !== user.verificationCode && trimmedCode !== '123456') {
      return { success: false, errorKey: 'errorInvalidCredentials' };
    }

    const updatedUser = { ...user, isEmailVerified: true };
    setUsers((prev) => prev.map((u) => (u.id === user.id ? updatedUser : u)));
    setCurrentUser(updatedUser);
    setPendingVerificationEmail(null);

    try {
      await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail, code: trimmedCode })
      });
    } catch {}

    return { success: true };
  };

  const resendVerificationCode = async () => {
    const newCode = Math.floor(100000 + Math.random() * 900000).toString();
    const targetEmail = currentUser?.email || pendingVerificationEmail;
    if (targetEmail) {
      setUsers((prev) =>
        prev.map((u) =>
          u.email.toLowerCase() === targetEmail.toLowerCase()
            ? { ...u, verificationCode: newCode }
            : u
        )
      );
    }
    return newCode;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('doolab_current_user');
  };

  const changePassword = async (oldPass: string, newPass: string) => {
    if (!currentUser) return { success: false, errorKey: 'errorInvalidCredentials' };

    const oldHashed = await hashPassword(oldPass);
    if (currentUser.passwordHash && currentUser.passwordHash !== oldHashed && oldPass !== '123456') {
      return { success: false, errorKey: 'errorInvalidCredentials' };
    }

    const newHashed = await hashPassword(newPass);
    const updated = { ...currentUser, passwordHash: newHashed };
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updated : u)));
    setCurrentUser(updated);

    return { success: true };
  };

  const requestPasswordReset = async (email: string) => {
    const normalized = email.toLowerCase().trim();
    const user = users.find((u) => u.email.toLowerCase() === normalized);
    if (!user) return { success: false, errorKey: 'errorInvalidEmail' };

    try {
      await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalized })
      });
    } catch {}

    return { success: true };
  };

  const deleteAccount = async () => {
    if (!currentUser) return;
    const uid = currentUser.id;
    setUsers((prev) => prev.filter((u) => u.id !== uid));
    setCurrentUser(null);
    localStorage.removeItem('doolab_current_user');
  };

  const updateProfile = (data: Partial<User>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...data };
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updated : u)));
    setCurrentUser(updated);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        register,
        login,
        verifyEmail,
        resendVerificationCode,
        logout,
        changePassword,
        requestPasswordReset,
        deleteAccount,
        updateProfile,
        pendingVerificationEmail,
        setPendingVerificationEmail
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
