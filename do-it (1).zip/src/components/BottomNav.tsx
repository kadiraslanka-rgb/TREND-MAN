import React from 'react';
import { Home, MessageCircle, ShoppingCart, PlusCircle, Menu } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const BottomNav: React.FC = () => {
  const { currentScreen, navigateTo, t, conversations, cart } = useApp();

  const totalUnreadMessages = conversations.reduce(
    (sum, conv) => sum + (conv.unreadCount || 0),
    0
  );

  const cartItemsCount = cart.length;

  const isHome = currentScreen === 'home';
  const isMessages = currentScreen === 'messages' || currentScreen === 'conversation';
  const isCart = currentScreen === 'cart';
  const isAddProduct = currentScreen === 'add_product';
  const isMenu = currentScreen === 'menu';

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 bg-white border-t border-stone-200/90 shadow-[0_-2px_12px_rgba(0,0,0,0.06)] max-w-2xl mx-auto">
      <div className="grid grid-cols-5 h-16 items-center px-1">
        {/* 1. HOME */}
        <button
          onClick={() => navigateTo('home')}
          className={`flex flex-col items-center justify-center py-1.5 transition-colors relative min-h-[48px] ${
            isHome ? 'text-[#3976A8] font-black' : 'text-stone-500 hover:text-stone-800'
          }`}
          aria-label={t.navHome}
        >
          <Home className={`w-5 h-5 mb-0.5 ${isHome ? 'stroke-[2.5] text-[#3976A8]' : 'text-stone-500'}`} />
          <span className="text-[11px] font-bold leading-tight">{t.navHome}</span>
          {isHome && <span className="w-1.5 h-1.5 rounded-full bg-[#3976A8] mt-0.5" />}
        </button>

        {/* 2. MESSAGES */}
        <button
          onClick={() => navigateTo('messages')}
          className={`flex flex-col items-center justify-center py-1.5 transition-colors relative min-h-[48px] ${
            isMessages ? 'text-[#3976A8] font-black' : 'text-stone-500 hover:text-stone-800'
          }`}
          aria-label={t.navMessages}
        >
          <div className="relative">
            <MessageCircle
              className={`w-5 h-5 mb-0.5 ${isMessages ? 'stroke-[2.5] text-[#3976A8]' : 'text-stone-500'}`}
            />
            {totalUnreadMessages > 0 && (
              <span className="absolute -top-1 -right-2 bg-red-500 text-white font-black text-[9px] min-w-4 h-4 px-1 rounded-full flex items-center justify-center shadow-xs">
                {totalUnreadMessages}
              </span>
            )}
          </div>
          <span className="text-[11px] font-bold leading-tight">{t.navMessages}</span>
          {isMessages && <span className="w-1.5 h-1.5 rounded-full bg-[#3976A8] mt-0.5" />}
        </button>

        {/* 3. CART (Requirement 10 & 11) */}
        <button
          onClick={() => navigateTo('cart')}
          className={`flex flex-col items-center justify-center py-1.5 transition-colors relative min-h-[48px] ${
            isCart ? 'text-[#3976A8] font-black' : 'text-stone-500 hover:text-stone-800'
          }`}
          aria-label={t.navCart}
        >
          <div className="relative">
            <ShoppingCart
              className={`w-5 h-5 mb-0.5 ${isCart ? 'stroke-[2.5] text-[#3976A8]' : 'text-stone-500'}`}
            />
            {cartItemsCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-[#3976A8] text-white font-black text-[9px] min-w-4 h-4 px-1 rounded-full flex items-center justify-center shadow-xs">
                {cartItemsCount}
              </span>
            )}
          </div>
          <span className="text-[11px] font-bold leading-tight">{t.navCart}</span>
          {isCart && <span className="w-1.5 h-1.5 rounded-full bg-[#3976A8] mt-0.5" />}
        </button>

        {/* 4. ADD PRODUCT */}
        <button
          onClick={() => navigateTo('add_product')}
          className={`flex flex-col items-center justify-center py-1.5 transition-colors relative min-h-[48px] ${
            isAddProduct ? 'text-[#3976A8] font-black' : 'text-stone-500 hover:text-stone-800'
          }`}
          aria-label={t.navAddProduct}
        >
          <PlusCircle
            className={`w-5 h-5 mb-0.5 ${
              isAddProduct ? 'stroke-[2.5] text-[#3976A8]' : 'text-stone-500'
            }`}
          />
          <span className="text-[11px] font-bold leading-tight">{t.navAddProduct}</span>
          {isAddProduct && <span className="w-1.5 h-1.5 rounded-full bg-[#3976A8] mt-0.5" />}
        </button>

        {/* 5. MENU (Requirement 10 & 12) */}
        <button
          onClick={() => navigateTo('menu')}
          className={`flex flex-col items-center justify-center py-1.5 transition-colors relative min-h-[48px] ${
            isMenu ? 'text-[#3976A8] font-black' : 'text-stone-500 hover:text-stone-800'
          }`}
          aria-label={t.navMenu}
        >
          <Menu className={`w-5 h-5 mb-0.5 ${isMenu ? 'stroke-[2.5] text-[#3976A8]' : 'text-stone-500'}`} />
          <span className="text-[11px] font-bold leading-tight">{t.navMenu}</span>
          {isMenu && <span className="w-1.5 h-1.5 rounded-full bg-[#3976A8] mt-0.5" />}
        </button>
      </div>
    </nav>
  );
};
