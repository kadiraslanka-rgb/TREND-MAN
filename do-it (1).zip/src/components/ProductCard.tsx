import React from 'react';
import { Heart, MapPin, CheckCircle2, Truck, AlertTriangle } from 'lucide-react';
import { Product } from '../types';
import { useApp } from '../context/AppContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { openProductDetail, toggleFavorite, isFavorite, t } = useApp();

  const isFav = isFavorite(product.id);

  const getConditionLabel = () => {
    switch (product.condition) {
      case 'new_with_tags':
        return t.conditionNewWithTags;
      case 'new':
        return t.conditionNew;
      case 'like_new':
        return t.conditionLikeNew;
      case 'lightly_used':
        return t.conditionLightlyUsed;
      case 'heavily_used':
        return t.conditionHeavilyUsed;
      default:
        return t.condition;
    }
  };

  const getConditionStyle = () => {
    switch (product.condition) {
      case 'new_with_tags':
        return 'bg-blue-50 text-[#3976A8] border-[#3976A8]/40';
      case 'new':
        return 'bg-emerald-50 text-emerald-800 border-emerald-300';
      case 'like_new':
        return 'bg-stone-100 text-stone-900 border-stone-300';
      case 'lightly_used':
        return 'bg-stone-50 text-stone-700 border-stone-200';
      case 'heavily_used':
        return 'bg-amber-50 text-amber-900 border-amber-300';
      default:
        return 'bg-stone-100 text-stone-700 border-stone-200';
    }
  };

  return (
    <div
      onClick={() => openProductDetail(product)}
      className="group bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col relative"
    >
      {/* Image Container */}
      <div className="relative aspect-square w-full bg-stone-100 overflow-hidden">
        <img
          src={product.images[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80'}
          alt={product.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 inset-x-2.5 flex items-center justify-between pointer-events-none">
          {/* Condition Badge (Requirement 3 - Exact 5) */}
          <span
            className={`px-2 py-0.5 text-[10px] font-black rounded-lg border shadow-xs pointer-events-auto ${getConditionStyle()}`}
          >
            {getConditionLabel()}
          </span>

          {/* Favorite Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleFavorite(product.id);
            }}
            className={`w-8 h-8 rounded-full flex items-center justify-center pointer-events-auto transition-transform active:scale-90 shadow-sm ${
              isFav ? 'bg-red-500 text-white' : 'bg-white/95 text-stone-600 hover:bg-white'
            }`}
            aria-label="Favorite"
          >
            <Heart className={`w-4 h-4 ${isFav ? 'fill-white' : ''}`} />
          </button>
        </div>

        {/* Defect Indicator Tag (Requirement 4) */}
        {product.hasDefects && (
          <div className="absolute bottom-2 start-2 pointer-events-none">
            <span className="px-2 py-0.5 text-[9px] font-bold rounded-md bg-amber-500 text-white shadow-xs flex items-center gap-1">
              <AlertTriangle className="w-2.5 h-2.5" />
              <span>{t.defectYes}</span>
            </span>
          </div>
        )}
      </div>

      {/* Product Content Details */}
      <div className="p-3.5 flex flex-col flex-1 justify-between gap-2">
        <div>
          {/* Price */}
          <div className="flex items-baseline gap-1">
            <span className="text-base font-black text-stone-900 group-hover:text-[#3976A8] transition-colors">
              {product.price.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-stone-500">{t.currency}</span>
          </div>

          {/* Title */}
          <h3 className="text-xs font-bold text-stone-800 line-clamp-2 leading-snug mt-1">
            {product.title}
          </h3>
        </div>

        {/* Location & Delivery Method */}
        <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
          <div className="flex items-center gap-1 truncate max-w-[70%]">
            <MapPin className="w-3 h-3 text-stone-400 shrink-0" />
            <span className="truncate">
              {product.location.city ? `${product.location.city}، ` : ''}{product.location.governorate}
            </span>
          </div>

          <div className="shrink-0 flex items-center gap-0.5 text-stone-600 font-medium">
            <Truck className="w-3 h-3 text-[#3976A8]" />
            <span className="text-[10px]">
              {product.deliveryMethod === 'face_to_face'
                ? t.deliveryFaceToFaceShort
                : product.deliveryMethod === 'shipping'
                ? t.deliveryShippingShort
                : t.deliveryBothShort}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
