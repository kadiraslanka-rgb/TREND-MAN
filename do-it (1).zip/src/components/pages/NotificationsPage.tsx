import React from 'react';
import { ArrowRight, ArrowLeft, Bell, ShieldCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const NotificationsPage: React.FC = () => {
  const { goBack, t, language } = useApp();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const notifications = [
    {
      id: 'n1',
      title: t.notifWelcomeTitle,
      body: t.notifWelcomeBody,
      time: t.timeTwoHoursAgo,
      icon: Bell
    },
    {
      id: 'n2',
      title: t.notifSafetyTitle,
      body: t.notifSafetyBody,
      time: t.timeYesterday,
      icon: ShieldCheck
    }
  ];

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.menuNotifications}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-3">
        {notifications.map((notif) => {
          const Icon = notif.icon;
          return (
            <div
              key={notif.id}
              className="bg-white rounded-3xl p-4 border border-stone-200 shadow-xs flex items-start gap-3.5"
            >
              <div className="w-10 h-10 rounded-2xl bg-blue-50 text-[#3976A8] flex items-center justify-center shrink-0">
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1 mb-1">
                  <h3 className="text-xs font-black text-stone-900">{notif.title}</h3>
                  <span className="text-[10px] text-stone-400">{notif.time}</span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed">{notif.body}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
