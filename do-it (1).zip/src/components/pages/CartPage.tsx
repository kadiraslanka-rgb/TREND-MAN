import React, { useState } from 'react';
import {
  ShoppingCart,
  Trash2,
  MessageCircle,
  Truck,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  ShieldCheck,
  CreditCard
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const CartPage: React.FC = () => {
  const {
    cart,
    removeFromCart,
    clearCart,
    startChatWithSeller,
    openProductDetail,
    navigateTo,
    goBack,
    t,
    language
  } = useApp();

  const [checkoutDone, setCheckoutDone] = useState(false);

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const totalPrice = cart.reduce((sum, item) => sum + item.product.price, 0);

  const handleCheckout = () => {
    setCheckoutDone(true);
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-28">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.cartTitle}</h1>

        {cart.length > 0 ? (
          <button
            onClick={clearCart}
            className="text-xs text-red-600 font-bold hover:underline"
          >
            {t.clearCart}
          </button>
        ) : (
          <div className="w-12" />
        )}
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {checkoutDone ? (
          <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-3 shadow-xs my-6">
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-lg font-black text-stone-900">{t.checkoutSuccess}</h2>
            <p className="text-xs text-stone-600 max-w-sm mx-auto leading-relaxed">
              {t.cartNotice}
            </p>
            <div className="pt-3 flex flex-col gap-2 max-w-xs mx-auto">
              <button
                onClick={() => navigateTo('orders')}
                className="w-full py-3 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-xs shadow-xs"
              >
                {t.menuOrders}
              </button>
              <button
                onClick={() => {
                  setCheckoutDone(false);
                  clearCart();
                  navigateTo('home');
                }}
                className="w-full py-3 rounded-2xl bg-stone-100 text-stone-700 font-bold text-xs hover:bg-stone-200"
              >
                {t.browseCategories}
              </button>
            </div>
          </div>
        ) : cart.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-3 shadow-xs my-8">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 text-[#3976A8] flex items-center justify-center mx-auto">
              <ShoppingCart className="w-8 h-8" />
            </div>
            <h2 className="text-base font-black text-stone-900">{t.cartEmpty}</h2>
            <p className="text-xs text-stone-500 max-w-xs mx-auto leading-relaxed">
              {t.cartEmptySub}
            </p>
            <div className="pt-2">
              <button
                onClick={() => navigateTo('home')}
                className="px-6 py-3 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-xs shadow-xs"
              >
                {t.browseCategories}
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Cart Items List */}
            <div className="space-y-3">
              {cart.map(({ id, product }) => (
                <div
                  key={id}
                  className="bg-white rounded-3xl p-4 border border-stone-200 shadow-xs space-y-3"
                >
                  <div className="flex gap-3">
                    <img
                      src={product.images[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80'}
                      alt={product.title}
                      onClick={() => openProductDetail(product)}
                      className="w-20 h-20 rounded-2xl object-cover border border-stone-200 shrink-0 cursor-pointer"
                    />

                    <div className="flex-1 min-w-0">
                      <h3
                        onClick={() => openProductDetail(product)}
                        className="text-sm font-bold text-stone-900 leading-snug line-clamp-2 cursor-pointer hover:text-[#3976A8]"
                      >
                        {product.title}
                      </h3>

                      <div className="flex items-baseline gap-1 mt-1">
                        <span className="text-base font-black text-[#3976A8]">
                          {product.price.toLocaleString()}
                        </span>
                        <span className="text-xs font-bold text-stone-600">{t.currency}</span>
                      </div>

                      {/* Seller Information */}
                      <div className="text-xs text-stone-500 mt-1 flex items-center gap-1.5 truncate">
                        <span>{t.sellerInfo}:</span>
                        <span className="font-bold text-stone-800">{product.seller.name}</span>
                      </div>
                    </div>
                  </div>

                  {/* Delivery Availability (Requirement 11) */}
                  <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 text-stone-600 font-medium">
                      <Truck className="w-3.5 h-3.5 text-[#3976A8]" />
                      <span>{t.deliveryAvailable}</span>
                    </div>
                    <span className="font-bold text-stone-900">
                      {product.deliveryMethod === 'face_to_face'
                        ? t.deliveryFaceToFace
                        : product.deliveryMethod === 'shipping'
                        ? t.deliveryShipping
                        : t.deliveryBoth}
                    </span>
                  </div>

                  {/* Action Buttons: Chat to buy / Remove */}
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => startChatWithSeller(product)}
                      className="flex-1 py-2.5 px-3 rounded-xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors min-h-[44px]"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>{t.contactSellerForPurchase}</span>
                    </button>

                    <button
                      onClick={() => removeFromCart(product.id)}
                      className="p-2.5 rounded-xl border border-stone-200 text-stone-500 hover:text-red-600 hover:bg-red-50 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
                      title={t.removeFromCart}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Total Summary Card & Checkout Button */}
            <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-stone-600">{t.cartTotal}</span>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black text-stone-900">
                    {totalPrice.toLocaleString()}
                  </span>
                  <span className="text-xs font-bold text-stone-600">{t.currency}</span>
                </div>
              </div>

              {/* Checkout Button (Requirement 11) */}
              <button
                onClick={handleCheckout}
                className="w-full py-4 px-6 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-black text-base shadow-sm transition-all text-center flex items-center justify-center gap-2 min-h-[52px]"
              >
                <CreditCard className="w-5 h-5" />
                <span>{t.checkout}</span>
              </button>

              <div className="pt-2 border-t border-stone-100 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-[#3976A8] shrink-0 mt-0.5" />
                <p className="text-[11px] text-stone-500 leading-relaxed font-medium">
                  {t.cartNotice}
                </p>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
