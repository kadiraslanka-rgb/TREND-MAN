import React from 'react';
import { MessageCircle, ArrowRight, ArrowLeft, Clock, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const MessagesPage: React.FC = () => {
  const { conversations, selectConversation, goBack, navigateTo, t, language } = useApp();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.messagesTitle}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-3">
        {conversations.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-3 shadow-xs my-8">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 text-[#3976A8] flex items-center justify-center mx-auto">
              <MessageCircle className="w-8 h-8" />
            </div>
            <h2 className="text-base font-black text-stone-900">{t.noMessagesTitle}</h2>
            <p className="text-xs text-stone-500 max-w-xs mx-auto leading-relaxed">
              {t.noMessagesSub}
            </p>
            <div className="pt-2">
              <button
                onClick={() => navigateTo('home')}
                className="px-6 py-3 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-xs shadow-xs"
              >
                {t.browseCategories}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-2.5">
            {conversations.map((conv) => (
              <div
                key={conv.id}
                onClick={() => selectConversation(conv)}
                className="bg-white rounded-3xl p-4 border border-stone-200 shadow-xs flex items-center gap-3.5 cursor-pointer hover:bg-stone-50 transition-colors"
              >
                <div className="relative shrink-0">
                  <img
                    src={conv.otherUser.avatar}
                    alt={conv.otherUser.name}
                    className="w-14 h-14 rounded-2xl object-cover ring-2 ring-[#3976A8]/20"
                  />
                  <img
                    src={conv.product.images[0]}
                    alt=""
                    className="w-6 h-6 rounded-lg object-cover absolute -bottom-1 -end-1 ring-2 ring-white shadow-xs"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <h3 className="text-sm font-black text-stone-900 truncate">
                      {conv.otherUser.name}
                    </h3>
                    <span className="text-[10px] text-stone-400 shrink-0 font-medium">
                      {conv.lastMessageTime}
                    </span>
                  </div>

                  <p className="text-xs text-[#3976A8] font-bold truncate mb-1">
                    {conv.product.title}
                  </p>

                  <p className="text-xs text-stone-600 truncate leading-tight">
                    {conv.lastMessage}
                  </p>
                </div>

                {conv.unreadCount > 0 && (
                  <span className="w-5 h-5 rounded-full bg-[#3976A8] text-white text-[10px] font-black flex items-center justify-center shrink-0">
                    {conv.unreadCount}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
