import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  Send,
  Phone,
  MessageCircle,
  Truck,
  CheckCircle2,
  XCircle,
  Tag,
  ShieldCheck,
  MapPin
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';

export const ConversationPage: React.FC = () => {
  const { activeConversation, sendMessage, respondToOffer, openProductDetail, goBack, t, language } = useApp();
  const { currentUser } = useAuth();

  const [inputText, setInputText] = useState('');
  const [showOfferBox, setShowOfferBox] = useState(false);
  const [offerValue, setOfferValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeConversation?.messages]);

  if (!activeConversation) {
    return (
      <div className="min-h-screen bg-[#FAF8F5] p-6 text-center flex flex-col items-center justify-center">
        <p className="text-stone-500 font-bold mb-4">{t.noMessagesTitle}</p>
        <button onClick={goBack} className="px-6 py-2.5 rounded-xl bg-[#3976A8] text-white font-bold text-sm">
          {t.back}
        </button>
      </div>
    );
  }

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    sendMessage(activeConversation.id, inputText.trim());
    setInputText('');
  };

  const handleMakeOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!offerValue.trim()) return;
    const amount = parseFloat(offerValue);
    if (isNaN(amount) || amount <= 0) return;

    sendMessage(
      activeConversation.id,
      `${t.officialPriceOffer} ${amount.toLocaleString()} ${t.currency}`,
      true,
      amount
    );
    setOfferValue('');
    setShowOfferBox(false);
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] flex flex-col justify-between text-stone-900">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2 min-w-0">
          <button
            onClick={goBack}
            className="flex items-center justify-center w-9 h-9 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 transition-colors shrink-0"
          >
            <BackIcon className="w-4 h-4" />
          </button>

          <img
            src={activeConversation.otherUser.avatar}
            alt={activeConversation.otherUser.name}
            className="w-10 h-10 rounded-xl object-cover ring-2 ring-[#3976A8]/20 shrink-0"
          />

          <div className="min-w-0">
            <h2 className="text-sm font-black text-stone-900 truncate">
              {activeConversation.otherUser.name}
            </h2>
            <div className="flex items-center gap-1 text-[11px] text-emerald-600 font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>{activeConversation.otherUser.responseRate}</span>
            </div>
          </div>
        </div>

        {/* Call button */}
        <a
          href={`tel:${activeConversation.otherUser.phone}`}
          className="w-9 h-9 rounded-xl border border-stone-200 flex items-center justify-center text-stone-700 hover:bg-stone-50 shrink-0"
          title={t.callSeller}
        >
          <Phone className="w-4 h-4 text-stone-600" />
        </a>
      </div>

      {/* Product Banner Strip */}
      <div
        onClick={() => openProductDetail(activeConversation.product)}
        className="bg-white border-b border-stone-200 px-4 py-2.5 flex items-center gap-3 cursor-pointer hover:bg-stone-50 transition-colors"
      >
        <img
          src={activeConversation.product.images[0]}
          alt=""
          className="w-12 h-12 rounded-xl object-cover border border-stone-200 shrink-0"
        />
        <div className="flex-1 min-w-0">
          <p className="text-xs font-bold text-stone-900 truncate">
            {activeConversation.product.title}
          </p>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="text-sm font-black text-[#3976A8]">
              {activeConversation.product.price.toLocaleString()}
            </span>
            <span className="text-[10px] font-bold text-stone-500">{t.currency}</span>
          </div>
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            setShowOfferBox(!showOfferBox);
          }}
          className="px-3 py-1.5 rounded-xl bg-blue-50 border border-blue-200 text-[#3976A8] text-xs font-bold shrink-0 hover:bg-blue-100"
        >
          {t.makeOffer}
        </button>
      </div>

      {/* Offer Input Box */}
      {showOfferBox && (
        <form onSubmit={handleMakeOffer} className="p-3 bg-blue-50/80 border-b border-blue-200 flex gap-2">
          <input
            type="number"
            min="1"
            value={offerValue}
            onChange={(e) => setOfferValue(e.target.value)}
            placeholder={t.offerAmount}
            className="flex-1 px-3 py-2 rounded-xl border border-blue-300 bg-white text-xs font-medium outline-hidden"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-xl bg-[#3976A8] text-white font-bold text-xs shadow-xs"
          >
            {t.sendOffer}
          </button>
        </form>
      )}

      {/* Messages Stream */}
      <div className="flex-1 p-4 space-y-3 overflow-y-auto max-w-2xl mx-auto w-full">
        {activeConversation.messages.map((msg) => {
          const isMe = msg.senderId === (currentUser?.id || 'me');

          return (
            <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[82%] sm:max-w-md rounded-2xl p-3.5 space-y-1.5 text-xs shadow-xs ${
                  isMe
                    ? 'bg-[#3976A8] text-white rounded-br-none'
                    : 'bg-white text-stone-800 border border-stone-200 rounded-bl-none'
                }`}
              >
                {/* Official Offer Card inside message */}
                {msg.isOffer ? (
                  <div className={`p-2.5 rounded-xl border ${isMe ? 'bg-white/10 border-white/20' : 'bg-blue-50 border-blue-200'}`}>
                    <div className="flex items-center gap-1.5 font-bold mb-1">
                      <Tag className="w-3.5 h-3.5" />
                      <span>{t.officialOfferBanner}</span>
                    </div>
                    <div className="text-sm font-black">
                      {msg.offerAmount?.toLocaleString()} {t.currency}
                    </div>

                    {msg.offerStatus === 'accepted' && (
                      <div className="flex items-center gap-1 text-emerald-400 font-bold mt-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{t.offerAccepted}</span>
                      </div>
                    )}

                    {msg.offerStatus === 'rejected' && (
                      <div className="flex items-center gap-1 text-red-400 font-bold mt-1">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>{t.offerRejected}</span>
                      </div>
                    )}

                    {!isMe && msg.offerStatus === 'pending' && (
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => respondToOffer(activeConversation.id, msg.id, 'accepted')}
                          className="flex-1 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-[11px]"
                        >
                          {t.accept}
                        </button>
                        <button
                          onClick={() => respondToOffer(activeConversation.id, msg.id, 'rejected')}
                          className="flex-1 py-1.5 rounded-lg bg-red-600 text-white font-bold text-[11px]"
                        >
                          {t.reject}
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                )}

                <div className={`text-[10px] text-end ${isMe ? 'text-blue-100' : 'text-stone-400'}`}>
                  {msg.timestamp}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Row */}
      <div className="p-2 bg-stone-50 border-t border-stone-200 overflow-x-auto flex gap-1.5 max-w-2xl mx-auto w-full">
        {[t.quickIsAvailable, t.quickWhereMeet, t.quickLastPrice].map((quick, qIdx) => (
          <button
            key={qIdx}
            onClick={() => sendMessage(activeConversation.id, quick)}
            className="px-3 py-1.5 rounded-xl bg-white border border-stone-200 text-stone-700 text-xs font-medium shrink-0 hover:bg-stone-100 shadow-2xs"
          >
            {quick}
          </button>
        ))}
      </div>

      {/* Message Input Bar */}
      <div className="bg-white border-t border-stone-200 p-3 max-w-2xl mx-auto w-full">
        <form onSubmit={handleSend} className="flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={t.chatPlaceholder}
            className="flex-1 px-4 py-3 rounded-2xl border border-stone-300 text-sm font-medium focus:border-[#3976A8] focus:ring-1 focus:ring-[#3976A8] outline-hidden"
          />
          <button
            type="submit"
            className="p-3.5 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white flex items-center justify-center transition-colors shadow-xs shrink-0"
          >
            <Send className={`w-4 h-4 ${isRtl ? 'rotate-180' : ''}`} />
          </button>
        </form>
      </div>
    </div>
  );
};
