import React, { useState } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  MapPin,
  CheckCircle2,
  Phone,
  MessageCircle,
  Package,
  Star,
  Flag
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../ProductCard';

export const SellerProfilePage: React.FC = () => {
  const { selectedSeller, products, openReportPage, goBack, t, language } = useApp();
  const [activeTab, setActiveTab] = useState<'active' | 'sold' | 'reviews'>('active');

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  if (!selectedSeller) {
    return (
      <div className="min-h-screen bg-[#FAF8F5] p-6 text-center flex flex-col items-center justify-center">
        <p className="text-stone-500 font-bold mb-4">{t.noProductsFound}</p>
        <button onClick={goBack} className="px-6 py-2.5 rounded-xl bg-[#3976A8] text-white font-bold text-sm">
          {t.back}
        </button>
      </div>
    );
  }

  const sellerProducts = products.filter((p) => p.seller.id === selectedSeller.id);

  const mockReviews = [
    {
      id: 'r1',
      author: language === 'ar' ? 'إسلام فهمي' : language === 'tr' ? 'İslam Fehmî' : 'Eslam Fahmy',
      rating: 5,
      date: t.timeOneWeekAgo,
      comment: language === 'ar'
        ? 'بائع محترم جداً وأمين، الموبايل طلع ممتاز وحسب الوصف والمقابلة تمت في مكان عام بأمان.'
        : language === 'tr'
        ? 'Çok dürüst ve saygılı bir satıcı. Telefon tam tarif edildiği gibiydi ve güvenle teslim aldım.'
        : 'Very respectful and honest seller. The item matched the exact description and the public meetup was seamless.'
    },
    {
      id: 'r2',
      author: language === 'ar' ? 'سارة عبد الرحمن' : language === 'tr' ? 'Sarah Abdurrahman' : 'Sarah Abdelrahman',
      rating: 5,
      date: t.timeThreeWeeksAgo,
      comment: language === 'ar'
        ? 'تعامل راقي وسرعة في الرد، البضاعة أصلية وأنصح بالتعامل معه بشدة.'
        : language === 'tr'
        ? 'Hızlı iletişim ve orijinal ürün. Güvenle alışveriş yapabilirsiniz.'
        : 'Great communication and prompt reply. Item was 100% genuine, highly recommended.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.sellerInfo}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Seller Hero Card */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center gap-4">
            <img
              src={selectedSeller.avatar}
              alt={selectedSeller.name}
              className="w-16 h-16 rounded-2xl object-cover ring-2 ring-[#3976A8]/20 shrink-0"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <h2 className="text-base font-black text-stone-900 truncate">
                  {selectedSeller.name}
                </h2>
                {selectedSeller.verified && (
                  <CheckCircle2 className="w-4 h-4 text-[#3976A8] shrink-0" />
                )}
              </div>

              <div className="flex items-center gap-1 text-stone-500 text-xs mt-0.5">
                <MapPin className="w-3.5 h-3.5 text-stone-400" />
                <span>
                  {selectedSeller.city ? `${selectedSeller.city}، ` : ''}{selectedSeller.governorate}
                </span>
              </div>

              <div className="flex items-center gap-2 mt-1">
                <div className="flex items-center gap-1 text-amber-600 font-black text-xs bg-amber-50 px-2 py-0.5 rounded-md">
                  <Star className="w-3.5 h-3.5 fill-amber-500" />
                  <span>{selectedSeller.rating}</span>
                  <span className="text-stone-400 font-normal">({selectedSeller.reviewCount})</span>
                </div>
                <span className="text-[11px] text-stone-500 font-bold bg-stone-100 px-2 py-0.5 rounded-md">
                  {selectedSeller.memberSince}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-stone-100 text-center">
            <div className="p-2.5 bg-stone-50 rounded-2xl">
              <span className="text-stone-400 block text-[10px] mb-0.5">{t.activeAds}</span>
              <span className="font-black text-stone-900 text-sm">
                {selectedSeller.activeListingsCount}
              </span>
            </div>
            <div className="p-2.5 bg-stone-50 rounded-2xl">
              <span className="text-stone-400 block text-[10px] mb-0.5">{t.soldItems}</span>
              <span className="font-black text-stone-900 text-sm">{selectedSeller.soldCount}</span>
            </div>
            <div className="p-2.5 bg-stone-50 rounded-2xl">
              <span className="text-stone-400 block text-[10px] mb-0.5">{t.responseRate}</span>
              <span className="font-black text-[#3976A8] text-xs truncate block">
                {selectedSeller.responseRate}
              </span>
            </div>
          </div>

          {/* Contact Actions */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <a
              href={`tel:${selectedSeller.phone}`}
              className="py-3 rounded-xl border border-stone-300 bg-white hover:bg-stone-50 font-bold text-stone-800 text-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <Phone className="w-4 h-4 text-stone-600" />
              <span>{t.callSeller}</span>
            </a>

            {selectedSeller.whatsapp && (
              <a
                href={`https://wa.me/${selectedSeller.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-xs"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{t.whatsappChat}</span>
              </a>
            )}
          </div>

          {/* Report Seller Button */}
          <div className="pt-1 text-center border-t border-stone-100">
            <button
              onClick={() => openReportPage('user', selectedSeller.id, selectedSeller.name)}
              className="inline-flex items-center gap-1 text-[11px] text-stone-400 hover:text-red-600 font-bold transition-colors py-1"
            >
              <Flag className="w-3 h-3" />
              <span>{t.reportUser}</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-stone-200 bg-white rounded-2xl p-1 gap-1">
          <button
            onClick={() => setActiveTab('active')}
            className={`flex-1 py-2 rounded-xl font-bold text-xs transition-colors ${
              activeTab === 'active'
                ? 'bg-[#3976A8] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            {t.menuMyListings} ({sellerProducts.length})
          </button>
          <button
            onClick={() => setActiveTab('sold')}
            className={`flex-1 py-2 rounded-xl font-bold text-xs transition-colors ${
              activeTab === 'sold'
                ? 'bg-[#3976A8] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            {t.soldItems} ({selectedSeller.soldCount})
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`flex-1 py-2 rounded-xl font-bold text-xs transition-colors ${
              activeTab === 'reviews'
                ? 'bg-[#3976A8] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            {t.sellerReviews} ({mockReviews.length})
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'active' && (
          <div className="grid grid-cols-2 gap-3">
            {sellerProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}

        {activeTab === 'sold' && (
          <div className="p-8 bg-white rounded-3xl border border-stone-200 text-center space-y-2">
            <Package className="w-10 h-10 text-stone-300 mx-auto" />
            <p className="font-bold text-stone-800 text-sm">
              {t.sellerSoldSummary.replace('{count}', selectedSeller.soldCount.toString())}
            </p>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="space-y-2.5">
            {mockReviews.map((rev) => (
              <div
                key={rev.id}
                className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs space-y-1.5 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-900">{rev.author}</span>
                  <span className="text-[10px] text-stone-400">{rev.date}</span>
                </div>
                <div className="flex items-center gap-0.5 text-amber-500">
                  {Array.from({ length: rev.rating }).map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                  ))}
                </div>
                <p className="text-stone-600 leading-relaxed font-normal">{rev.comment}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
