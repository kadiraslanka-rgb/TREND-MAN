import React from 'react';
import { ArrowRight, ArrowLeft, Globe, Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Language } from '../../types';

export const LanguageSettingsPage: React.FC = () => {
  const { language, setLanguage, goBack, t } = useApp();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const languages: { id: Language; label: string; subLabel: string; flag: string }[] = [
    { id: 'ar', label: 'العربية', subLabel: 'Arabic (RTL)', flag: '🇪🇬' },
    { id: 'en', label: 'English', subLabel: 'English (LTR)', flag: '🇬🇧' },
    { id: 'tr', label: 'Türkçe', subLabel: 'Turkish (LTR)', flag: '🇹🇷' }
  ];

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.menuLanguage}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-3">
        <div className="bg-white rounded-3xl p-3 border border-stone-200 shadow-xs space-y-1">
          {languages.map((lng) => {
            const isSelected = language === lng.id;
            return (
              <button
                key={lng.id}
                onClick={() => setLanguage(lng.id)}
                className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all text-start min-h-[56px] ${
                  isSelected
                    ? 'bg-blue-50/70 border border-[#3976A8] text-[#3976A8]'
                    : 'hover:bg-stone-50 text-stone-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{lng.flag}</span>
                  <div>
                    <span className="text-sm font-black block">{lng.label}</span>
                    <span className="text-xs text-stone-500 font-medium">{lng.subLabel}</span>
                  </div>
                </div>

                {isSelected && (
                  <div className="w-6 h-6 rounded-full bg-[#3976A8] text-white flex items-center justify-center">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
