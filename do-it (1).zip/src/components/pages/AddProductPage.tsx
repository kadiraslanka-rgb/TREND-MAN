import React, { useState, useRef } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  Camera,
  Upload,
  X,
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  Truck,
  Sparkles,
  Info
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { CATEGORIES } from '../../data/categories';
import { BRANDS } from '../../data/brands';
import { EGYPT_GOVERNORATES } from '../../data/locations';
import { ProductCondition, DeliveryMethod } from '../../types';

export const AddProductPage: React.FC = () => {
  const { addProduct, goBack, navigateTo, openProductDetail, t, language } = useApp();
  const { currentUser } = useAuth();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  // Form State
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [categoryId, setCategoryId] = useState(CATEGORIES[0].id);
  const [subcategoryId, setSubcategoryId] = useState(CATEGORIES[0].subcategories[0]?.id || '');
  const [brand, setBrand] = useState('Apple');
  const [customBrandName, setCustomBrandName] = useState('');

  // 1. EXACT 5 CONDITIONS (Requirement 3)
  const [condition, setCondition] = useState<ProductCondition>('like_new');

  // 2. DEFECT SECTION (Requirement 4)
  const [hasDefects, setHasDefects] = useState<boolean>(false);
  const [defectDescription, setDefectDescription] = useState('');
  const [defectImages, setDefectImages] = useState<string[]>([]);

  // 3. DELIVERY & ESTIMATED SHIPPING (Requirement 5)
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>('both');
  const [estimatedShippingCost, setEstimatedShippingCost] = useState('');

  // 4. PROHIBITED ITEMS POLICY CONFIRMATION (Requirement 6)
  const [acceptedProhibitedPolicy, setAcceptedProhibitedPolicy] = useState(false);

  // Photos & Description
  const [images, setImages] = useState<string[]>([
    'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80'
  ]);
  const [description, setDescription] = useState('');
  const [governorate, setGovernorate] = useState(currentUser?.governorate || EGYPT_GOVERNORATES[0].name.ar);
  const [city, setCity] = useState(currentUser?.city || EGYPT_GOVERNORATES[0].cities[0].name.ar);
  const [negotiable, setNegotiable] = useState(true);

  // Error feedback
  const [errorNotice, setErrorNotice] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const defectFileInputRef = useRef<HTMLInputElement>(null);

  const currentCategory = CATEGORIES.find((c) => c.id === categoryId) || CATEGORIES[0];
  const currentGov = EGYPT_GOVERNORATES.find((g) => g.name.ar === governorate || g.name.en === governorate);

  // Condition options definition
  const conditionOptions: { id: ProductCondition; label: string }[] = [
    { id: 'new_with_tags', label: t.conditionNewWithTags },
    { id: 'new', label: t.conditionNew },
    { id: 'like_new', label: t.conditionLikeNew },
    { id: 'lightly_used', label: t.conditionLightlyUsed },
    { id: 'heavily_used', label: t.conditionHeavilyUsed }
  ];

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      if (file.size > 5 * 1024 * 1024) {
        alert(t.errorFileTooLarge);
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setImages((prev) => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDefectPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      if (file.size > 5 * 1024 * 1024) {
        alert(t.errorFileTooLarge);
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setDefectImages((prev) => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorNotice('');

    if (!title.trim() || !price || !description.trim()) {
      setErrorNotice(t.errorFillAllFields);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    // Validate Defect Requirement (Requirement 4)
    if (hasDefects) {
      if (!defectDescription.trim() || defectImages.length === 0) {
        setErrorNotice(t.defectRequiredError);
        window.scrollTo({ top: 200, behavior: 'smooth' });
        return;
      }
    }

    // Validate Prohibited policy acceptance (Requirement 6)
    if (!acceptedProhibitedPolicy) {
      setErrorNotice(t.prohibitedNotice);
      window.scrollTo({ top: 400, behavior: 'smooth' });
      return;
    }

    setIsSubmitting(true);

    const estCostNum = estimatedShippingCost ? parseFloat(estimatedShippingCost) : undefined;

    const newProd = addProduct({
      title: title.trim(),
      price: parseFloat(price),
      originalPrice: originalPrice ? parseFloat(originalPrice) : undefined,
      categoryId,
      subcategoryId,
      brand: brand === 'other' ? 'Other' : brand,
      customBrandName: brand === 'other' ? customBrandName.trim() : undefined,
      condition,
      hasDefects,
      defectDescription: hasDefects ? defectDescription.trim() : undefined,
      defectImages: hasDefects ? defectImages : undefined,
      deliveryMethod,
      estimatedShippingCost: estCostNum,
      description: description.trim(),
      images,
      location: {
        governorate,
        city
      },
      negotiable,
      acceptedProhibitedPolicy: true
    });

    setIsSubmitting(false);
    openProductDetail(newProd);
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.addProductTitle}</h1>
        <div className="w-16" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {errorNotice && (
          <div className="p-3.5 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-xs font-bold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorNotice}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Photos Upload */}
          <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
            <div>
              <h2 className="text-sm font-black text-stone-900">{t.photosSection}</h2>
              <p className="text-xs text-stone-500 mt-0.5">{t.photoLimitInfo}</p>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5">
              {images.map((img, idx) => (
                <div key={idx} className="relative aspect-square rounded-2xl overflow-hidden border border-stone-200 bg-stone-100 group">
                  <img src={img} alt="Product" className="w-full h-full object-cover" />
                  {images.length > 1 && (
                    <button
                      type="button"
                      onClick={() => setImages((prev) => prev.filter((_, i) => i !== idx))}
                      className="absolute top-1.5 end-1.5 w-6 h-6 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-red-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {idx === 0 && (
                    <span className="absolute bottom-1 inset-x-1 py-0.5 bg-black/50 text-white text-[9px] font-bold text-center rounded">
                      الرئيسية
                    </span>
                  )}
                </div>
              ))}

              {/* Upload Button */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="aspect-square rounded-2xl border-2 border-dashed border-[#3976A8]/40 hover:border-[#3976A8] bg-blue-50/30 flex flex-col items-center justify-center gap-1 text-[#3976A8] transition-colors"
              >
                <Camera className="w-6 h-6" />
                <span className="text-[11px] font-bold">{t.addPhotosButton}</span>
              </button>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              multiple
              onChange={handlePhotoUpload}
              className="hidden"
            />
          </div>

          {/* Basic Info */}
          <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">{t.productTitle} *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={t.productTitlePlaceholder}
                className="w-full px-3.5 py-3 rounded-xl border border-stone-300 text-sm font-medium focus:border-[#3976A8] focus:ring-1 focus:ring-[#3976A8] outline-hidden"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.categorySelect} *</label>
                <select
                  value={categoryId}
                  onChange={(e) => {
                    const cid = e.target.value;
                    setCategoryId(cid);
                    const cat = CATEGORIES.find((c) => c.id === cid);
                    if (cat && cat.subcategories.length > 0) {
                      setSubcategoryId(cat.subcategories[0].id);
                    }
                  }}
                  className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-sm bg-white font-medium"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name[language === 'en' ? 'en' : language === 'tr' ? 'tr' : 'ar']}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.subcategorySelect}</label>
                <select
                  value={subcategoryId}
                  onChange={(e) => setSubcategoryId(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-sm bg-white font-medium"
                >
                  {currentCategory.subcategories.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name[language === 'en' ? 'en' : language === 'tr' ? 'tr' : 'ar']}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Brand Selection with Other */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">{t.brandSelect}</label>
              <select
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-sm bg-white font-medium mb-2"
              >
                {BRANDS.map((b) => (
                  <option key={b.id} value={b.name}>
                    {b.name}
                  </option>
                ))}
                <option value="other">{t.brandOther}</option>
              </select>

              {brand === 'other' && (
                <input
                  type="text"
                  required
                  value={customBrandName}
                  onChange={(e) => setCustomBrandName(e.target.value)}
                  placeholder={t.customBrandPlaceholder}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm font-medium"
                />
              )}
            </div>

            {/* Price */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.askingPrice} *</label>
                <input
                  type="number"
                  required
                  min="1"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder={t.askingPricePlaceholder}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.originalPriceOptional}</label>
                <input
                  type="number"
                  min="1"
                  value={originalPrice}
                  onChange={(e) => setOriginalPrice(e.target.value)}
                  placeholder="مثال: 5000"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm font-medium"
                />
              </div>
            </div>

            <label className="flex items-center gap-2 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={negotiable}
                onChange={(e) => setNegotiable(e.target.checked)}
                className="w-4 h-4 rounded text-[#3976A8] border-stone-300"
              />
              <span className="text-xs font-bold text-stone-700">{t.priceNegotiableLabel}</span>
            </label>
          </div>

          {/* 1. EXACT 5 CONDITIONS (Requirement 3) */}
          <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
            <label className="block text-xs font-black text-stone-900">{t.condition} *</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {conditionOptions.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setCondition(opt.id)}
                  className={`p-3 rounded-2xl text-xs font-bold text-start border transition-all flex items-center justify-between min-h-[48px] ${
                    condition === opt.id
                      ? 'border-[#3976A8] bg-blue-50/50 text-[#3976A8] ring-1 ring-[#3976A8]'
                      : 'border-stone-200 hover:border-stone-300 text-stone-700'
                  }`}
                >
                  <span>{opt.label}</span>
                  {condition === opt.id && <CheckCircle2 className="w-4 h-4 text-[#3976A8]" />}
                </button>
              ))}
            </div>
          </div>

          {/* 2. PRODUCT DEFECTS (Requirement 4) */}
          <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
            <label className="block text-xs font-black text-stone-900">{t.hasDefectQuestion} *</label>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setHasDefects(false)}
                className={`py-3 px-4 rounded-2xl text-xs font-bold border transition-all flex items-center justify-center gap-2 min-h-[48px] ${
                  !hasDefects
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 ring-1 ring-emerald-500'
                    : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{t.defectNo}</span>
              </button>

              <button
                type="button"
                onClick={() => setHasDefects(true)}
                className={`py-3 px-4 rounded-2xl text-xs font-bold border transition-all flex items-center justify-center gap-2 min-h-[48px] ${
                  hasDefects
                    ? 'bg-amber-50 text-amber-900 border-amber-300 ring-1 ring-amber-500'
                    : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                <AlertTriangle className="w-4 h-4" />
                <span>{t.defectYes}</span>
              </button>
            </div>

            {/* If YES: Require Defect Description and Defect Photos (Requirement 4) */}
            {hasDefects && (
              <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 space-y-3 mt-2 animate-in fade-in duration-150">
                <div>
                  <label className="block text-xs font-black text-amber-900 mb-1">
                    {t.defectDescriptionLabel} *
                  </label>
                  <textarea
                    required={hasDefects}
                    rows={3}
                    value={defectDescription}
                    onChange={(e) => setDefectDescription(e.target.value)}
                    placeholder={t.defectDescriptionPlaceholder}
                    className="w-full p-3 rounded-xl border border-amber-300 bg-white text-xs font-medium focus:ring-1 focus:ring-amber-500 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black text-amber-900 mb-1.5">
                    {t.defectPhotosLabel} *
                  </label>

                  <div className="flex gap-2 items-center flex-wrap">
                    {defectImages.map((dimg, i) => (
                      <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden border border-amber-300 bg-white">
                        <img src={dimg} alt="" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setDefectImages((prev) => prev.filter((_, idx) => idx !== i))}
                          className="absolute top-1 end-1 w-5 h-5 rounded-full bg-black/60 text-white flex items-center justify-center"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}

                    <button
                      type="button"
                      onClick={() => defectFileInputRef.current?.click()}
                      className="w-20 h-20 rounded-xl border-2 border-dashed border-amber-400 bg-white flex flex-col items-center justify-center text-amber-800 text-[10px] font-bold gap-1"
                    >
                      <Camera className="w-5 h-5" />
                      <span>{t.addDefectPhoto}</span>
                    </button>
                  </div>

                  <input
                    ref={defectFileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    multiple
                    onChange={handleDefectPhotoUpload}
                    className="hidden"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 3. DELIVERY OPTIONS & ESTIMATED SHIPPING COST (Requirement 5) */}
          <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
            <label className="block text-xs font-black text-stone-900">{t.deliveryMethodLabel} *</label>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setDeliveryMethod('face_to_face')}
                className={`py-3 px-2 rounded-2xl text-xs font-bold border transition-all text-center min-h-[48px] ${
                  deliveryMethod === 'face_to_face'
                    ? 'border-[#3976A8] bg-blue-50/50 text-[#3976A8] ring-1 ring-[#3976A8]'
                    : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                {t.deliveryFaceToFace}
              </button>

              <button
                type="button"
                onClick={() => setDeliveryMethod('shipping')}
                className={`py-3 px-2 rounded-2xl text-xs font-bold border transition-all text-center min-h-[48px] ${
                  deliveryMethod === 'shipping'
                    ? 'border-[#3976A8] bg-blue-50/50 text-[#3976A8] ring-1 ring-[#3976A8]'
                    : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                {t.deliveryShipping}
              </button>

              <button
                type="button"
                onClick={() => setDeliveryMethod('both')}
                className={`py-3 px-2 rounded-2xl text-xs font-bold border transition-all text-center min-h-[48px] ${
                  deliveryMethod === 'both'
                    ? 'border-[#3976A8] bg-blue-50/50 text-[#3976A8] ring-1 ring-[#3976A8]'
                    : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                {t.deliveryBoth}
              </button>
            </div>

            {/* If Shipping or Both: Optional Estimated Shipping Cost */}
            {(deliveryMethod === 'shipping' || deliveryMethod === 'both') && (
              <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-2 mt-2">
                <label className="block text-xs font-bold text-stone-700">
                  {t.estimatedShippingCostLabel}
                </label>
                <input
                  type="number"
                  min="0"
                  value={estimatedShippingCost}
                  onChange={(e) => setEstimatedShippingCost(e.target.value)}
                  placeholder={t.estimatedShippingCostPlaceholder}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm font-medium bg-white"
                />
                <p className="text-[11px] text-stone-500 italic">
                  {t.estimatedShippingCostNotice}
                </p>
              </div>
            )}
          </div>

          {/* Description & Location */}
          <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">{t.productDescription} *</label>
              <textarea
                required
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={t.productDescriptionPlaceholder}
                className="w-full p-3.5 rounded-xl border border-stone-300 text-sm font-medium focus:ring-1 focus:ring-[#3976A8] outline-hidden leading-relaxed"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.governorate}</label>
                <select
                  value={governorate}
                  onChange={(e) => {
                    setGovernorate(e.target.value);
                    const g = EGYPT_GOVERNORATES.find((item) => item.name.ar === e.target.value || item.name.en === e.target.value);
                    if (g && g.cities.length > 0) {
                      setCity(g.cities[0].name.ar);
                    }
                  }}
                  className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-sm bg-white font-medium"
                >
                  {EGYPT_GOVERNORATES.map((gov) => (
                    <option key={gov.id} value={gov.name.ar}>
                      {gov.name[language === 'en' ? 'en' : 'ar']}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.city}</label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-sm bg-white font-medium"
                >
                  {currentGov?.cities.map((c) => (
                    <option key={c.id} value={c.name.ar}>
                      {c.name[language === 'en' ? 'en' : 'ar']}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* 4. STRICT PROHIBITED PRODUCTS POLICY NOTICE & CHECKBOX (Requirement 6) */}
          <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#3976A8]" />
              <h3 className="text-sm font-black text-stone-900">{t.prohibitedItemsPolicyTitle}</h3>
            </div>

            <div className="p-3.5 rounded-2xl bg-blue-50/60 border border-blue-200/80 text-xs text-stone-700 space-y-2">
              <p className="font-bold text-[#3976A8] leading-relaxed">
                {t.prohibitedNotice}
              </p>
              <p className="text-[11px] text-stone-600 leading-relaxed">
                {t.foodProhibitedWarning}
              </p>
            </div>

            <label className="flex items-start gap-2.5 cursor-pointer pt-1">
              <input
                type="checkbox"
                required
                checked={acceptedProhibitedPolicy}
                onChange={(e) => setAcceptedProhibitedPolicy(e.target.checked)}
                className="mt-1 w-4 h-4 rounded text-[#3976A8] border-stone-300 focus:ring-[#3976A8]"
              />
              <span className="text-xs font-bold text-stone-800 leading-tight">
                {t.prohibitedNoticeCheckbox} *
              </span>
            </label>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-base shadow-sm transition-colors disabled:opacity-50 min-h-[50px]"
          >
            {isSubmitting ? '...' : t.publishAd}
          </button>
        </form>
      </div>
    </div>
  );
};
