import React, { useState } from 'react';
import { ArrowRight, ArrowLeft, Flag, Send, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ReportReason } from '../../types';

export const ReportPage: React.FC = () => {
  const { reportTargetData, submitReport, goBack, t, language } = useApp();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const [reason, setReason] = useState<ReportReason>('scam_fraud');
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const reportReasons: { id: ReportReason; label: string }[] = [
    { id: 'prohibited_product', label: t.reasonProhibitedProduct },
    { id: 'counterfeit', label: t.reasonCounterfeit },
    { id: 'scam_fraud', label: t.reasonScamFraud },
    { id: 'misleading_description', label: t.reasonMisleadingDescription },
    { id: 'dangerous_product', label: t.reasonDangerousProduct },
    { id: 'stolen_product', label: t.reasonStolenProduct },
    { id: 'inappropriate_content', label: t.reasonInappropriateContent },
    { id: 'other', label: t.reasonOther }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!details.trim()) {
      alert(t.errorFillAllFields);
      return;
    }

    setIsSubmitting(true);
    try {
      await submitReport(reason, details.trim());
      setSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.reportListingTitle}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {submitted ? (
          <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-3 shadow-xs my-8">
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-base font-black text-stone-900">{t.reportReceivedTitle}</h2>
            <p className="text-xs text-stone-600 max-w-sm mx-auto leading-relaxed">
              {t.reportSubmittedSuccess}
            </p>
            <div className="pt-2">
              <button
                onClick={goBack}
                className="px-6 py-3 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-xs shadow-xs"
              >
                {t.confirm}
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-4">
            {reportTargetData?.targetTitle && (
              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-100 text-xs">
                <span className="text-stone-400 block mb-0.5">{t.productTitle}:</span>
                <span className="font-bold text-stone-900">{reportTargetData.targetTitle}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-black text-stone-900 mb-2">
                {t.reasonOther}:
              </label>

              <div className="space-y-2">
                {reportReasons.map((item) => (
                  <label
                    key={item.id}
                    className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs font-bold cursor-pointer transition-colors ${
                      reason === item.id
                        ? 'border-[#3976A8] bg-blue-50/50 text-[#3976A8]'
                        : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="reportReason"
                      value={item.id}
                      checked={reason === item.id}
                      onChange={() => setReason(item.id)}
                      className="text-[#3976A8] focus:ring-[#3976A8]"
                    />
                    <span>{item.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-stone-900 mb-1">
                {t.reportDetailsLabel} *
              </label>
              <textarea
                required
                rows={4}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder={t.reportDetailsPlaceholder}
                className="w-full p-3 rounded-xl border border-stone-300 text-xs font-medium focus:ring-1 focus:ring-[#3976A8] outline-hidden leading-relaxed"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-sm shadow-xs flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? '...' : t.submitReport}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
