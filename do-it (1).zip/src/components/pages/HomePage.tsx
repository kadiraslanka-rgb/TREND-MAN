import React, { useState } from 'react';
import {
  Search,
  Sparkles,
  Flame,
  Clock,
  Heart,
  MapPin,
  PlusCircle,
  Truck,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  ArrowLeft,
  SlidersHorizontal,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CATEGORIES } from '../../data/categories';
import { ProductCard } from '../ProductCard';
import { Category } from '../../types';

export const HomePage: React.FC = () => {
  const {
    products,
    filteredProducts,
    filters,
    setFilters,
    resetFilters,
    openCategoryPage,
    navigateTo,
    favorites,
    t,
    language
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'newest' | 'featured' | 'nearby' | 'favorites'>('all');
  const [searchInput, setSearchInput] = useState(filters.searchQuery || '');

  const isRtl = language === 'ar';

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFilters((prev) => ({ ...prev, searchQuery: searchInput.trim() }));
  };

  const handleClearSearch = () => {
    setSearchInput('');
    setFilters((prev) => ({ ...prev, searchQuery: '' }));
  };

  // Filtered view by activeTab
  const displayedProducts = filteredProducts.filter((p) => {
    if (activeTab === 'featured') return p.isFeatured;
    if (activeTab === 'nearby') return p.location.governorate === 'القاهرة' || p.location.governorate === 'الجيزة';
    if (activeTab === 'favorites') return favorites.includes(p.id);
    return true;
  });

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Search Bar */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 shadow-xs">
        <form onSubmit={handleSearchSubmit} className="relative flex items-center">
          <Search className="w-4 h-4 text-stone-400 absolute start-3.5 pointer-events-none" />
          <input
            type="text"
            value={searchInput}
            onChange={(e) => {
              setSearchInput(e.target.value);
              setFilters((prev) => ({ ...prev, searchQuery: e.target.value }));
            }}
            placeholder={t.searchPlaceholder}
            className="w-full ps-10 pe-10 py-3 rounded-2xl bg-stone-100 hover:bg-stone-100/80 focus:bg-white border border-transparent focus:border-[#3976A8] text-xs font-medium outline-hidden transition-all shadow-inner"
          />
          {searchInput && (
            <button
              type="button"
              onClick={handleClearSearch}
              className="absolute end-3 p-1 rounded-full text-stone-400 hover:text-stone-700"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </form>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-5">
        {/* Marketplace Trust Banner (NO "Made for Egypt" - Requirement 2) */}
        <div className="bg-gradient-to-br from-[#3976A8] to-[#2B5E87] rounded-3xl p-5 text-white shadow-sm space-y-3">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[11px] font-bold">
              {t.appName}
            </span>
          </div>

          <h2 className="text-lg sm:text-xl font-black leading-snug">
            {t.homeBannerTitle}
          </h2>

          <p className="text-xs text-blue-100 leading-relaxed max-w-lg">
            {t.homeBannerSub}
          </p>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/20 text-center text-xs">
            <div className="p-2 rounded-xl bg-white/10">
              <span className="font-black block text-xs">{t.trustMeetupTitle}</span>
              <span className="text-[10px] text-blue-100">{t.trustMeetupDesc}</span>
            </div>
            <div className="p-2 rounded-xl bg-white/10">
              <span className="font-black block text-xs">{t.trustPriceTitle}</span>
              <span className="text-[10px] text-blue-100">{t.trustPriceDesc}</span>
            </div>
            <div className="p-2 rounded-xl bg-white/10">
              <span className="font-black block text-xs">{t.trustGovTitle}</span>
              <span className="text-[10px] text-blue-100">{t.trustGovDesc}</span>
            </div>
          </div>
        </div>

        {/* Categories Section (Requirement 1: Opens Category Page, NOT a modal!) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-sm font-black text-stone-900">{t.browseCategories}</h3>
            <span className="text-xs text-stone-400 font-bold">{CATEGORIES.length} {t.categoriesCount}</span>
          </div>

          <div className="grid grid-cols-4 sm:grid-cols-7 gap-2.5">
            {CATEGORIES.slice(0, 8).map((cat) => (
              <button
                key={cat.id}
                onClick={() => openCategoryPage(cat)}
                className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white border border-stone-200 hover:border-[#3976A8] hover:bg-blue-50/30 transition-all text-center group shadow-2xs"
              >
                <div className="w-10 h-10 rounded-xl bg-stone-100 group-hover:bg-blue-50 flex items-center justify-center text-stone-700 group-hover:text-[#3976A8] mb-1.5 transition-colors">
                  <Sparkles className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-bold text-stone-800 line-clamp-1 leading-tight">
                  {cat.name[language === 'en' ? 'en' : language === 'tr' ? 'tr' : 'ar']}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Feed Filter Tabs */}
        <div className="space-y-3">
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {[
              { id: 'all', label: t.tabAll, icon: Sparkles },
              { id: 'newest', label: t.tabNewest, icon: Clock },
              { id: 'featured', label: t.tabFeatured, icon: Flame },
              { id: 'nearby', label: t.tabNearby, icon: MapPin },
              { id: 'favorites', label: t.tabFavorites, icon: Heart }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-bold shrink-0 transition-all min-h-[44px] ${
                    isActive
                      ? 'bg-[#3976A8] text-white shadow-xs'
                      : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Product Feed Grid */}
          {displayedProducts.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-2 my-6">
              <p className="text-sm font-bold text-stone-600">{t.noProductsFound}</p>
              {filters.searchQuery && (
                <button
                  onClick={handleClearSearch}
                  className="mt-2 px-4 py-2 rounded-xl bg-stone-100 text-stone-700 text-xs font-bold"
                >
                  {t.clearFilters}
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {displayedProducts.map((prod) => (
                <ProductCard key={prod.id} product={prod} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
