import React, { useState } from 'react';
import {
  Mail,
  Lock,
  User as UserIcon,
  Phone,
  MapPin,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  ShieldCheck,
  Building2,
  Globe
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { EGYPT_GOVERNORATES } from '../../data/locations';
import { Language } from '../../types';

export const WelcomeAuthPage: React.FC = () => {
  const {
    login,
    register,
    verifyEmail,
    resendVerificationCode,
    requestPasswordReset,
    pendingVerificationEmail
  } = useAuth();

  const { t, language, setLanguage, navigateTo } = useApp();

  const [mode, setMode] = useState<'welcome' | 'login' | 'register' | 'forgot_password' | 'verify_email'>('welcome');

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [governorate, setGovernorate] = useState(EGYPT_GOVERNORATES[0].name.ar);
  const [city, setCity] = useState(EGYPT_GOVERNORATES[0].cities[0].name.ar);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [readPrivacy, setReadPrivacy] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');

  // Status & feedback
  const [errorMessage, setErrorMessage] = useState('');
  const [successNotice, setSuccessNotice] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const currentGov = EGYPT_GOVERNORATES.find(
    (g) => g.name.ar === governorate || g.name.en === governorate
  );

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!email.trim() || !password.trim()) {
      setErrorMessage(t.errorFillAllFields);
      return;
    }

    setIsLoading(true);
    try {
      const res = await login(email, password);
      if (res.success) {
        navigateTo('home');
      } else {
        setErrorMessage(
          res.errorKey === 'errorLoginRateLimit' ? t.errorLoginRateLimit : t.errorInvalidCredentials
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim() || !email.trim() || !password.trim() || !confirmPassword.trim()) {
      setErrorMessage(t.errorFillAllFields);
      return;
    }

    if (password.length < 6) {
      setErrorMessage(t.errorPasswordTooShort);
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage(t.errorPasswordMismatch);
      return;
    }

    if (!agreedToTerms || !readPrivacy) {
      setErrorMessage(t.errorTermsRequired);
      return;
    }

    setIsLoading(true);
    try {
      const res = await register({
        name,
        email,
        password,
        governorate,
        city,
        phone,
        agreedToTerms: true
      });

      if (res.success) {
        setSuccessNotice(t.accountCreatedSuccess || 'تم إنشاء الحساب بنجاح!');
        setMode('verify_email');
      } else {
        setErrorMessage(res.errorKey === 'errorEmailExists' ? t.errorEmailExists : t.errorFillAllFields);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!verificationCode.trim()) {
      setErrorMessage(t.errorFillAllFields);
      return;
    }

    setIsLoading(true);
    try {
      const res = await verifyEmail(verificationCode);
      if (res.success) {
        navigateTo('home');
      } else {
        setErrorMessage(t.errorInvalidCredentials);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!email.trim()) {
      setErrorMessage(t.errorFillAllFields);
      return;
    }

    setIsLoading(true);
    try {
      await requestPasswordReset(email);
      setSuccessNotice('تم إرسال رابط استعادة كلمة المرور إلى بريدك الإلكتروني بنجاح.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] flex flex-col justify-between p-4 sm:p-6 text-stone-900">
      {/* Top Bar with Language Switcher */}
      <div className="flex items-center justify-between pb-3">
        {mode !== 'welcome' ? (
          <button
            onClick={() => {
              setErrorMessage('');
              setSuccessNotice('');
              setMode('welcome');
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-stone-200 text-stone-700 font-bold text-sm shadow-xs hover:bg-stone-50"
          >
            <BackIcon className="w-4 h-4" />
            <span>{t.back}</span>
          </button>
        ) : (
          <div />
        )}

        {/* Language selector */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-stone-200 shadow-xs">
          <Globe className="w-3.5 h-3.5 text-stone-500 mx-1" />
          {(['ar', 'en', 'tr'] as Language[]).map((lng) => (
            <button
              key={lng}
              onClick={() => setLanguage(lng)}
              className={`px-2 py-1 rounded-lg text-xs font-bold transition-colors ${
                language === lng
                  ? 'bg-[#3976A8] text-white'
                  : 'text-stone-600 hover:bg-stone-100'
              }`}
            >
              {lng === 'ar' ? 'عربي' : lng === 'tr' ? 'TR' : 'EN'}
            </button>
          ))}
        </div>
      </div>

      {/* Main Container */}
      <div className="w-full max-w-md mx-auto my-auto py-4">
        {/* Brand Hero */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-[#3976A8] text-white flex items-center justify-center font-black text-2xl mx-auto shadow-md mb-3">
            د
          </div>
          <h1 className="text-2xl font-black text-stone-900 tracking-tight">{t.appName}</h1>
          <p className="text-sm text-stone-600 mt-1 max-w-xs mx-auto leading-relaxed">
            {t.welcomeSubtitle}
          </p>
        </div>

        {/* Error / Success Notices */}
        {errorMessage && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-bold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successNotice && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{successNotice}</span>
          </div>
        )}

        {/* 1. WELCOME SCREEN */}
        {mode === 'welcome' && (
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
            <div className="text-center pb-2">
              <h2 className="text-lg font-black text-stone-900">{t.welcomeTitle}</h2>
            </div>

            <button
              onClick={() => {
                setErrorMessage('');
                setMode('register');
              }}
              className="w-full py-4 px-6 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-base shadow-sm transition-all text-center flex items-center justify-center gap-2"
            >
              <UserIcon className="w-5 h-5" />
              <span>{t.createAccount}</span>
            </button>

            <button
              onClick={() => {
                setErrorMessage('');
                setMode('login');
              }}
              className="w-full py-3.5 px-6 rounded-2xl bg-white hover:bg-stone-50 text-[#3976A8] border-2 border-[#3976A8] font-bold text-base transition-all text-center flex items-center justify-center gap-2"
            >
              <Lock className="w-5 h-5" />
              <span>{t.loginAccount}</span>
            </button>

            <button
              onClick={() => {
                setErrorMessage('');
                setMode('forgot_password');
              }}
              className="w-full py-3 px-6 rounded-2xl bg-stone-50 hover:bg-stone-100 text-stone-700 font-bold text-sm transition-all text-center flex items-center justify-center gap-2"
            >
              <span>{t.forgotPassword}</span>
            </button>

            <div className="pt-2 border-t border-stone-100 text-center">
              <button
                onClick={() => navigateTo('home')}
                className="text-stone-500 hover:text-stone-800 text-sm font-bold underline py-2 inline-block"
              >
                {t.guestBrowse}
              </button>
            </div>
          </div>
        )}

        {/* 2. LOGIN FORM */}
        {mode === 'login' && (
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
            <div className="pb-1">
              <h2 className="text-lg font-black text-stone-900">{t.loginTitle}</h2>
              <p className="text-xs text-stone-500 mt-0.5">{t.loginSubtitle}</p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.emailAddress}</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-400 absolute top-3.5 start-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={t.emailPlaceholder}
                    className="w-full ps-9 pe-3 py-3 rounded-xl border border-stone-300 text-sm focus:border-[#3976A8] focus:ring-1 focus:ring-[#3976A8] outline-hidden font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.password}</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-400 absolute top-3.5 start-3" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={t.passwordPlaceholder}
                    className="w-full ps-9 pe-3 py-3 rounded-xl border border-stone-300 text-sm focus:border-[#3976A8] focus:ring-1 focus:ring-[#3976A8] outline-hidden font-medium"
                  />
                </div>
              </div>

              <div className="text-end">
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage('');
                    setMode('forgot_password');
                  }}
                  className="text-xs text-[#3976A8] font-bold hover:underline"
                >
                  {t.forgotPassword}
                </button>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 rounded-xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-sm shadow-xs transition-colors disabled:opacity-50"
              >
                {isLoading ? '...' : t.loginAccount}
              </button>
            </form>

            <div className="pt-2 text-center border-t border-stone-100">
              <button
                type="button"
                onClick={() => {
                  setErrorMessage('');
                  setMode('register');
                }}
                className="text-xs text-stone-600 font-bold hover:text-[#3976A8]"
              >
                {t.dontHaveAccount}
              </button>
            </div>
          </div>
        )}

        {/* 3. REGISTRATION FORM (Requirement 9) */}
        {mode === 'register' && (
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
            <div className="pb-1">
              <h2 className="text-lg font-black text-stone-900">{t.registerTitle}</h2>
              <p className="text-xs text-stone-500 mt-0.5">{t.registerSubtitle}</p>
            </div>

            <form onSubmit={handleRegisterSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.fullName}</label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-stone-400 absolute top-3.5 start-3" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t.fullNamePlaceholder}
                    className="w-full ps-9 pe-3 py-2.5 rounded-xl border border-stone-300 text-sm focus:border-[#3976A8] focus:ring-1 focus:ring-[#3976A8] outline-hidden font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.emailAddress}</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-400 absolute top-3.5 start-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={t.emailPlaceholder}
                    className="w-full ps-9 pe-3 py-2.5 rounded-xl border border-stone-300 text-sm focus:border-[#3976A8] focus:ring-1 focus:ring-[#3976A8] outline-hidden font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">{t.password}</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={t.passwordPlaceholder}
                    className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-sm focus:border-[#3976A8] focus:ring-1 focus:ring-[#3976A8] outline-hidden font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">{t.confirmPassword}</label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder={t.confirmPasswordPlaceholder}
                    className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-sm focus:border-[#3976A8] focus:ring-1 focus:ring-[#3976A8] outline-hidden font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">{t.governorate}</label>
                  <select
                    value={governorate}
                    onChange={(e) => {
                      setGovernorate(e.target.value);
                      const g = EGYPT_GOVERNORATES.find((item) => item.name.ar === e.target.value || item.name.en === e.target.value);
                      if (g && g.cities.length > 0) {
                        setCity(g.cities[0].name[language === 'en' ? 'en' : 'ar']);
                      }
                    }}
                    className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-sm bg-white font-medium"
                  >
                    {EGYPT_GOVERNORATES.map((gov) => (
                      <option key={gov.id} value={gov.name[language === 'en' ? 'en' : 'ar']}>
                        {gov.name[language === 'en' ? 'en' : 'ar']}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">{t.city}</label>
                  <select
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-sm bg-white font-medium"
                  >
                    {currentGov?.cities.map((c) => (
                      <option key={c.id} value={c.name[language === 'en' ? 'en' : 'ar']}>
                        {c.name[language === 'en' ? 'en' : 'ar']}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  {t.phoneNumber} <span className="text-stone-400 font-normal">({t.optional})</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-stone-400 absolute top-3.5 start-3" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder={t.phonePlaceholder}
                    className="w-full ps-9 pe-3 py-2.5 rounded-xl border border-stone-300 text-sm font-medium"
                  />
                </div>
              </div>

              {/* Required Legal Checkboxes (Requirement 4 & 9) */}
              <div className="space-y-2 pt-1 border-t border-stone-100">
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={agreedToTerms}
                    onChange={(e) => setAgreedToTerms(e.target.checked)}
                    className="mt-1 w-4 h-4 rounded text-[#3976A8] border-stone-300 focus:ring-[#3976A8]"
                  />
                  <span className="text-xs text-stone-700 leading-tight">
                    {t.acceptTermsCheck}
                  </span>
                </label>

                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={readPrivacy}
                    onChange={(e) => setReadPrivacy(e.target.checked)}
                    className="mt-1 w-4 h-4 rounded text-[#3976A8] border-stone-300 focus:ring-[#3976A8]"
                  />
                  <span className="text-xs text-stone-700 leading-tight">
                    {t.readPrivacyCheck}
                  </span>
                </label>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 rounded-xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-sm shadow-xs transition-colors disabled:opacity-50"
              >
                {isLoading ? '...' : t.createAccount}
              </button>
            </form>

            <div className="pt-2 text-center border-t border-stone-100">
              <button
                type="button"
                onClick={() => {
                  setErrorMessage('');
                  setMode('login');
                }}
                className="text-xs text-stone-600 font-bold hover:text-[#3976A8]"
              >
                {t.alreadyHaveAccount}
              </button>
            </div>
          </div>
        )}

        {/* 4. EMAIL VERIFICATION */}
        {mode === 'verify_email' && (
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
            <div className="text-center pb-2">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#3976A8] flex items-center justify-center mx-auto mb-2">
                <Mail className="w-6 h-6" />
              </div>
              <h2 className="text-lg font-black text-stone-900">{t.emailVerification}</h2>
              <p className="text-xs text-stone-600 mt-1">{t.verificationCodePrompt}</p>
              <p className="text-xs font-mono font-bold text-[#3976A8] mt-1">{email || pendingVerificationEmail}</p>
            </div>

            <form onSubmit={handleVerifySubmit} className="space-y-3">
              <div>
                <input
                  type="text"
                  maxLength={6}
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  placeholder="123456"
                  className="w-full py-3 text-center tracking-widest font-mono text-xl font-black rounded-xl border border-stone-300 focus:border-[#3976A8] outline-hidden"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 rounded-xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-sm shadow-xs transition-colors disabled:opacity-50"
              >
                {t.verifyCodeButton}
              </button>

              <div className="flex items-center justify-between pt-2 text-xs">
                <button
                  type="button"
                  onClick={async () => {
                    const code = await resendVerificationCode();
                    setSuccessNotice(`تم إرسال كود جديد: ${code}`);
                  }}
                  className="text-[#3976A8] font-bold hover:underline"
                >
                  {t.resendCode}
                </button>
                <button
                  type="button"
                  onClick={() => navigateTo('home')}
                  className="text-stone-500 font-bold hover:text-stone-800"
                >
                  {t.guestBrowse}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* 5. FORGOT PASSWORD */}
        {mode === 'forgot_password' && (
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
            <div>
              <h2 className="text-lg font-black text-stone-900">{t.resetPassword}</h2>
              <p className="text-xs text-stone-500 mt-0.5">{t.resetPasswordInstruction}</p>
            </div>

            <form onSubmit={handleForgotSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">{t.emailAddress}</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-400 absolute top-3.5 start-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={t.emailPlaceholder}
                    className="w-full ps-9 pe-3 py-3 rounded-xl border border-stone-300 text-sm font-medium"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 rounded-xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-sm shadow-xs transition-colors disabled:opacity-50"
              >
                {t.sendResetLink}
              </button>
            </form>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setMode('login')}
                className="text-xs text-stone-600 font-bold hover:text-[#3976A8]"
              >
                {t.alreadyHaveAccount}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer Legal Disclaimer */}
      <div className="text-center text-[11px] text-stone-400 py-2">
        <p>{t.appName} • {t.appTagline}</p>
      </div>
    </div>
  );
};
