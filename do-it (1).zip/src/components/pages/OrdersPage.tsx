import React from 'react';
import { ArrowRight, ArrowLeft, ShoppingBag, Truck } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const OrdersPage: React.FC = () => {
  const { products, openProductDetail, goBack, t, language } = useApp();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  // Localized sample deals / orders
  const sampleOrders = [
    {
      id: 'ord-1',
      product: products[0],
      date: language === 'ar' ? 'اليوم، 12:30 م' : language === 'tr' ? 'Bugün, 12:30' : 'Today, 12:30 PM',
      statusText: language === 'ar'
        ? 'بانتظار تأكيد المقابلة والتسليم'
        : language === 'tr'
        ? 'Buluşma ve teslimat onayı bekleniyor'
        : 'Awaiting meetup & delivery confirmation',
      amount: products[0]?.price || 28500
    },
    {
      id: 'ord-2',
      product: products[1],
      date: language === 'ar' ? 'منذ يومين' : language === 'tr' ? '2 gün önce' : '2 days ago',
      statusText: language === 'ar'
        ? 'تم شحن السلعة - رقم التتبع: EG-987214'
        : language === 'tr'
        ? 'Ürün kargoya verildi - Takip No: EG-987214'
        : 'Item shipped - Tracking: EG-987214',
      amount: products[1]?.price || 3600
    }
  ];

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.menuOrders}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-3">
        {sampleOrders.map((ord) => (
          <div
            key={ord.id}
            onClick={() => ord.product && openProductDetail(ord.product)}
            className="bg-white rounded-3xl p-4 border border-stone-200 shadow-xs space-y-3 cursor-pointer hover:bg-stone-50 transition-colors"
          >
            <div className="flex items-center justify-between text-xs pb-2 border-b border-stone-100">
              <span className="font-bold text-stone-500">{t.orderNumber} #{ord.id}</span>
              <span className="text-stone-400">{ord.date}</span>
            </div>

            {ord.product && (
              <div className="flex gap-3">
                <img
                  src={ord.product.images[0]}
                  alt=""
                  className="w-16 h-16 rounded-xl object-cover border border-stone-200 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="text-xs font-bold text-stone-900 truncate">
                    {ord.product.title}
                  </h3>
                  <div className="text-sm font-black text-[#3976A8] mt-1">
                    {ord.amount.toLocaleString()} {t.currency}
                  </div>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    {t.sellerInfo}: {ord.product.seller.name}
                  </p>
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 p-2.5 rounded-xl bg-stone-50 border border-stone-100 text-xs font-bold text-stone-700">
              <Truck className="w-4 h-4 text-[#3976A8] shrink-0" />
              <span>{ord.statusText}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
