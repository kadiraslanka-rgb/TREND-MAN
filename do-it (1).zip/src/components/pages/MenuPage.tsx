import React from 'react';
import {
  User,
  Package,
  Heart,
  ShoppingBag,
  Truck,
  Settings,
  Globe,
  Bell,
  Headphones,
  ShieldCheck,
  FileText,
  AlertTriangle,
  Scale,
  Flag,
  LogOut,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  ArrowLeft,
  UserCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';

export const MenuPage: React.FC = () => {
  const { navigateTo, openLegalDoc, openReportPage, goBack, t, language, favorites, cart } = useApp();
  const { currentUser, logout, isAuthenticated } = useAuth();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;
  const Chevron = isRtl ? ChevronLeft : ChevronRight;

  const handleLogout = () => {
    if (window.confirm(t.logoutConfirm)) {
      logout();
      navigateTo('welcome_auth');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.menuTitle}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* User Card if Logged in */}
        {currentUser ? (
          <div
            onClick={() => navigateTo('my_profile')}
            className="bg-white rounded-3xl p-4 border border-stone-200 shadow-xs flex items-center gap-3.5 cursor-pointer hover:bg-stone-50 transition-colors"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-14 h-14 rounded-2xl object-cover ring-2 ring-[#3976A8]/20 shrink-0"
            />
            <div className="flex-1 min-w-0">
              <h2 className="text-base font-black text-stone-900 truncate">{currentUser.name}</h2>
              <p className="text-xs text-stone-500 mt-0.5">{currentUser.city}، {currentUser.governorate}</p>
              <span className="inline-block mt-1 text-[11px] font-bold text-[#3976A8]">
                {t.menuProfile} ←
              </span>
            </div>
          </div>
        ) : (
          <div
            onClick={() => navigateTo('welcome_auth')}
            className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs text-center space-y-2 cursor-pointer hover:bg-stone-50"
          >
            <p className="text-sm font-black text-stone-900">{t.welcomeTitle}</p>
            <span className="inline-block px-4 py-2 rounded-xl bg-[#3976A8] text-white font-bold text-xs">
              {t.loginAccount}
            </span>
          </div>
        )}

        {/* 1. Account & Marketplace Services (Requirement 12) */}
        <div className="bg-white rounded-3xl p-2 border border-stone-200 shadow-xs">
          <div className="px-3 pt-2 pb-1 text-[11px] font-black text-stone-400 uppercase tracking-wider">
            {t.menuGeneralHeader}
          </div>

          <div className="divide-y divide-stone-100">
            {/* My Profile */}
            <button
              onClick={() => navigateTo('my_profile')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#3976A8] flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuProfile}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* My Listings */}
            <button
              onClick={() => navigateTo('my_listings')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#3976A8] flex items-center justify-center">
                  <Package className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuMyListings}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Favorites */}
            <button
              onClick={() => navigateTo('favorites')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#3976A8] flex items-center justify-center">
                  <Heart className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuFavorites}</span>
              </div>
              <div className="flex items-center gap-1.5">
                {favorites.length > 0 && (
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-stone-100 text-stone-600">
                    {favorites.length}
                  </span>
                )}
                <Chevron className="w-4 h-4 text-stone-400" />
              </div>
            </button>

            {/* Orders / Purchases */}
            <button
              onClick={() => navigateTo('orders')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#3976A8] flex items-center justify-center">
                  <ShoppingBag className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuOrders}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Shipping */}
            <button
              onClick={() => navigateTo('shipping_rules')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#3976A8] flex items-center justify-center">
                  <Truck className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuShipping}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Account Settings */}
            <button
              onClick={() => navigateTo('account_settings')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#3976A8] flex items-center justify-center">
                  <Settings className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuAccount}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Language */}
            <button
              onClick={() => navigateTo('language_settings')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#3976A8] flex items-center justify-center">
                  <Globe className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuLanguage}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-stone-500">
                  {language === 'ar' ? 'العربية' : language === 'tr' ? 'Türkçe' : 'English'}
                </span>
                <Chevron className="w-4 h-4 text-stone-400" />
              </div>
            </button>

            {/* Notifications */}
            <button
              onClick={() => navigateTo('notifications')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#3976A8] flex items-center justify-center">
                  <Bell className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuNotifications}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Help & Support */}
            <button
              onClick={() => navigateTo('help_support')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#3976A8] flex items-center justify-center">
                  <Headphones className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuHelpSupport}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>
          </div>
        </div>

        {/* 2. Legal, Safety & Rules Section (Requirement 8 & 12) */}
        <div className="bg-white rounded-3xl p-2 border border-stone-200 shadow-xs">
          <div className="px-3 pt-2 pb-1 text-[11px] font-black text-stone-400 uppercase tracking-wider">
            {t.menuLegalSafetyHeader}
          </div>

          <div className="divide-y divide-stone-100">
            {/* Safety */}
            <button
              onClick={() => navigateTo('safety_guide')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuSafety}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Terms of Service */}
            <button
              onClick={() => openLegalDoc('terms')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuTerms}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Privacy Policy */}
            <button
              onClick={() => openLegalDoc('privacy')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <Scale className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuPrivacy}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Marketplace Rules */}
            <button
              onClick={() => openLegalDoc('marketplace_rules')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuRules}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Seller Rules */}
            <button
              onClick={() => openLegalDoc('seller_rules')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <UserCheck className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuSellerRules}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Prohibited Items (Requirement 6 & 12) */}
            <button
              onClick={() => openLegalDoc('prohibited_items')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-red-700">{t.menuProhibited}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>

            {/* Report a Problem */}
            <button
              onClick={() => openReportPage('product', '', '')}
              className="w-full flex items-center justify-between p-3.5 hover:bg-stone-50 transition-colors text-start min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <Flag className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-stone-800">{t.menuReport}</span>
              </div>
              <Chevron className="w-4 h-4 text-stone-400" />
            </button>
          </div>
        </div>

        {/* Logout Button if Logged In */}
        {currentUser && (
          <div className="bg-white rounded-3xl p-2 border border-stone-200 shadow-xs">
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-between p-3.5 hover:bg-red-50 text-red-600 font-bold text-sm transition-colors rounded-2xl min-h-[48px]"
            >
              <div className="flex items-center gap-3">
                <LogOut className="w-4 h-4" />
                <span>{t.menuLogout}</span>
              </div>
              <Chevron className="w-4 h-4 text-red-400" />
            </button>
          </div>
        )}

        {/* App Version Info */}
        <div className="text-center text-xs text-stone-400 py-3">
          <p>{t.appName} v3.2</p>
        </div>
      </div>
    </div>
  );
};
