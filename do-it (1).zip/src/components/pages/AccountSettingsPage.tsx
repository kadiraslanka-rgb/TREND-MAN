import React, { useState } from 'react';
import { ArrowRight, ArrowLeft, Lock, Trash2, CheckCircle2, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';

export const AccountSettingsPage: React.FC = () => {
  const { goBack, navigateTo, t, language } = useApp();
  const { currentUser, changePassword, deleteAccount } = useAuth();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg('');

    if (newPassword.length < 6) {
      setMsg(t.errorPasswordTooShort);
      setIsSuccess(false);
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setMsg(t.errorPasswordMismatch);
      setIsSuccess(false);
      return;
    }

    const res = await changePassword(currentPassword, newPassword);
    if (res.success) {
      setMsg(t.passwordChangedSuccess);
      setIsSuccess(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
    } else {
      setMsg(t.errorInvalidCredentials);
      setIsSuccess(false);
    }
  };

  const handleDelete = async () => {
    if (window.confirm(t.deleteAccountWarning)) {
      await deleteAccount();
      navigateTo('welcome_auth');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.menuAccount}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* User Info Card */}
        {currentUser && (
          <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-2">
            <h2 className="text-sm font-black text-stone-900">{t.fullName}</h2>
            <p className="text-sm text-stone-700 font-medium">{currentUser.name}</p>
            <p className="text-xs text-stone-500">{currentUser.email}</p>
          </div>
        )}

        {/* Change Password Form */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#3976A8]" />
            <h2 className="text-sm font-black text-stone-900">{t.changePassword}</h2>
          </div>

          {msg && (
            <div
              className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 ${
                isSuccess
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-red-50 text-red-700 border border-red-200'
              }`}
            >
              {isSuccess ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{msg}</span>
            </div>
          )}

          <form onSubmit={handlePasswordSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">{t.currentPassword}</label>
              <input
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">{t.newPassword}</label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder={t.passwordPlaceholder}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">{t.confirmPassword}</label>
              <input
                type="password"
                required
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                placeholder={t.confirmPasswordPlaceholder}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm font-medium"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-xs shadow-xs"
            >
              {t.changePassword}
            </button>
          </form>
        </div>

        {/* Delete Account (Requirement 8) */}
        <div className="bg-white rounded-3xl p-5 border border-red-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-red-600 font-black text-sm">
            <Trash2 className="w-4 h-4" />
            <span>{t.deleteAccount}</span>
          </div>

          <p className="text-xs text-stone-600 leading-relaxed font-medium">
            {t.deleteAccountWarning}
          </p>

          <button
            onClick={handleDelete}
            className="w-full py-3 rounded-xl border-2 border-red-500 text-red-600 hover:bg-red-50 font-bold text-xs transition-colors"
          >
            {t.confirmDeleteAccountButton}
          </button>
        </div>
      </div>
    </div>
  );
};
