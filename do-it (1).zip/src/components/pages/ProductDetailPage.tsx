import React, { useState } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  Heart,
  Share2,
  MapPin,
  Clock,
  ShieldCheck,
  AlertTriangle,
  Truck,
  Users,
  MessageCircle,
  Phone,
  ShoppingCart,
  CheckCircle2,
  Flag,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Tag
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';

export const ProductDetailPage: React.FC = () => {
  const {
    selectedProduct,
    goBack,
    t,
    language,
    toggleFavorite,
    isFavorite,
    addToCart,
    isInCart,
    startChatWithSeller,
    openSellerProfile,
    openReportPage,
    navigateTo
  } = useApp();

  const { currentUser } = useAuth();

  const [activePhotoIdx, setActivePhotoIdx] = useState(0);
  const [offerInput, setOfferInput] = useState('');
  const [isOfferSent, setIsOfferSent] = useState(false);

  if (!selectedProduct) {
    return (
      <div className="min-h-screen bg-[#FAF8F5] p-6 text-center flex flex-col items-center justify-center">
        <p className="text-stone-500 font-bold mb-4">{t.noProductsFound}</p>
        <button
          onClick={goBack}
          className="px-6 py-2.5 rounded-xl bg-[#3976A8] text-white font-bold text-sm"
        >
          {t.back}
        </button>
      </div>
    );
  }

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;
  const isFav = isFavorite(selectedProduct.id);
  const inCart = isInCart(selectedProduct.id);

  const images = selectedProduct.images.length > 0
    ? selectedProduct.images
    : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80'];

  const getConditionLabel = () => {
    switch (selectedProduct.condition) {
      case 'new_with_tags':
        return t.conditionNewWithTags;
      case 'new':
        return t.conditionNew;
      case 'like_new':
        return t.conditionLikeNew;
      case 'lightly_used':
        return t.conditionLightlyUsed;
      case 'heavily_used':
        return t.conditionHeavilyUsed;
      default:
        return t.condition;
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: selectedProduct.title,
        text: `${selectedProduct.title} - ${selectedProduct.price} ${t.currency}`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      alert('تم نسخ رابط الإعلان!');
    }
  };

  const handleSendOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!offerInput.trim()) return;
    const amount = parseFloat(offerInput);
    if (isNaN(amount) || amount <= 0) return;

    startChatWithSeller(selectedProduct);
    setIsOfferSent(true);
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-28">
      {/* Top Header Navigation Bar (Full Page) */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900 truncate max-w-[200px] text-center">
          {t.productDetailsTitle}
        </h1>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => toggleFavorite(selectedProduct.id)}
            className="w-9 h-9 rounded-xl border border-stone-200 flex items-center justify-center text-stone-600 hover:bg-stone-50"
            aria-label="Favorite"
          >
            <Heart
              className={`w-5 h-5 ${
                isFav ? 'fill-red-500 text-red-500' : 'text-stone-500'
              }`}
            />
          </button>
          <button
            onClick={handleShare}
            className="w-9 h-9 rounded-xl border border-stone-200 flex items-center justify-center text-stone-600 hover:bg-stone-50"
            aria-label="Share"
          >
            <Share2 className="w-5 h-5 text-stone-500" />
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Main Photo Gallery Carousel */}
        <div className="bg-white rounded-3xl overflow-hidden border border-stone-200 shadow-xs relative">
          <div className="relative aspect-4/3 sm:aspect-16/10 bg-stone-100 flex items-center justify-center overflow-hidden">
            <img
              src={images[activePhotoIdx]}
              alt={selectedProduct.title}
              className="w-full h-full object-contain"
            />

            {/* Condition Badge (Requirement 3 - EXACT 5) */}
            <div className="absolute top-3 start-3">
              <span className="px-3 py-1.5 rounded-xl bg-[#3976A8] text-white font-black text-xs shadow-md">
                {getConditionLabel()}
              </span>
            </div>

            {/* Carousel navigation arrows */}
            {images.length > 1 && (
              <>
                <button
                  onClick={() => setActivePhotoIdx((prev) => (prev > 0 ? prev - 1 : images.length - 1))}
                  className="absolute start-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/60"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setActivePhotoIdx((prev) => (prev < images.length - 1 ? prev + 1 : 0))}
                  className="absolute end-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/60"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}

            {/* Indicator dots */}
            {images.length > 1 && (
              <div className="absolute bottom-2.5 inset-x-0 flex justify-center gap-1.5">
                {images.map((_, i) => (
                  <span
                    key={i}
                    className={`h-1.5 rounded-full transition-all ${
                      activePhotoIdx === i ? 'w-5 bg-[#3976A8]' : 'w-1.5 bg-black/30'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Thumbnails row */}
          {images.length > 1 && (
            <div className="p-2.5 flex items-center gap-2 overflow-x-auto border-t border-stone-100">
              {images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActivePhotoIdx(i)}
                  className={`w-14 h-14 rounded-xl overflow-hidden border-2 shrink-0 ${
                    activePhotoIdx === i ? 'border-[#3976A8]' : 'border-transparent opacity-60'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Price & Title Card */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
          <div className="flex items-baseline justify-between gap-2">
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl sm:text-3xl font-black text-stone-900">
                  {selectedProduct.price.toLocaleString()}
                </span>
                <span className="text-base font-bold text-stone-600">{t.currency}</span>
              </div>
              {selectedProduct.originalPrice && selectedProduct.originalPrice > selectedProduct.price && (
                <span className="text-xs text-stone-400 line-through">
                  {selectedProduct.originalPrice.toLocaleString()} {t.currency}
                </span>
              )}
            </div>

            {selectedProduct.negotiable && (
              <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200">
                {t.negotiableBadge}
              </span>
            )}
          </div>

          <h2 className="text-lg font-bold text-stone-900 leading-snug">
            {selectedProduct.title}
          </h2>

          <div className="flex flex-wrap items-center gap-3 text-xs text-stone-500 pt-1 border-t border-stone-100">
            <div className="flex items-center gap-1">
              <MapPin className="w-4 h-4 text-stone-400" />
              <span>
                {selectedProduct.location.city ? `${selectedProduct.location.city}، ` : ''}
                {selectedProduct.location.governorate}
              </span>
            </div>
            <span>•</span>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4 text-stone-400" />
              <span>{selectedProduct.createdAt}</span>
            </div>
            {selectedProduct.brand && (
              <>
                <span>•</span>
                <div className="flex items-center gap-1 font-bold text-stone-700">
                  <Tag className="w-3.5 h-3.5 text-stone-400" />
                  <span>{selectedProduct.customBrandName || selectedProduct.brand}</span>
                </div>
              </>
            )}
          </div>
        </div>

        {/* PRODUCT DEFECT SECTION (Requirement 4 - Clearly Visible!) */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className={`w-5 h-5 ${selectedProduct.hasDefects ? 'text-amber-600' : 'text-emerald-600'}`} />
            <h3 className="text-base font-black text-stone-900">{t.productDefectTitle}</h3>
          </div>

          {selectedProduct.hasDefects ? (
            <div className="space-y-3 p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200">
              <div className="flex items-start gap-2">
                <span className="px-2 py-0.5 rounded-md bg-amber-600 text-white font-bold text-xs shrink-0">
                  {t.defectYes}
                </span>
                <p className="text-sm text-stone-800 leading-relaxed font-medium">
                  {selectedProduct.defectDescription || t.defectDescriptionPlaceholder}
                </p>
              </div>

              {/* Defect photos (Requirement 4) */}
              {selectedProduct.defectImages && selectedProduct.defectImages.length > 0 && (
                <div>
                  <span className="block text-xs font-bold text-stone-600 mb-1.5">
                    {t.defectPhotosLabel}:
                  </span>
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {selectedProduct.defectImages.map((dimg, dIdx) => (
                      <div
                        key={dIdx}
                        className="w-24 h-24 rounded-xl overflow-hidden border-2 border-amber-300 shrink-0 bg-white"
                      >
                        <img src={dimg} alt="Defect" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span className="text-sm font-bold text-emerald-800">
                {t.noDefectsFound}
              </span>
            </div>
          )}
        </div>

        {/* DELIVERY & SHIPPING SECTION (Requirement 5) */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-[#3976A8]" />
            <h3 className="text-base font-black text-stone-900">{t.deliveryMethodLabel}</h3>
          </div>

          <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-500">{t.deliveryAvailable}</span>
              <span className="text-sm font-black text-[#3976A8]">
                {selectedProduct.deliveryMethod === 'face_to_face'
                  ? t.deliveryFaceToFace
                  : selectedProduct.deliveryMethod === 'shipping'
                  ? t.deliveryShipping
                  : t.deliveryBoth}
              </span>
            </div>

            {/* Optional Estimated Shipping Cost (Requirement 5) */}
            {(selectedProduct.deliveryMethod === 'shipping' || selectedProduct.deliveryMethod === 'both') && (
              <div className="pt-2 border-t border-stone-200/80 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-700">{t.estimatedShippingCostLabel}:</span>
                  <span className="text-sm font-bold text-stone-900">
                    {selectedProduct.estimatedShippingCost !== undefined && selectedProduct.estimatedShippingCost > 0
                      ? `${selectedProduct.estimatedShippingCost} ${t.currency}`
                      : t.optional}
                  </span>
                </div>
                <p className="text-[11px] text-stone-500 italic">
                  {t.estimatedShippingCostNotice}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Product Description */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-2">
          <h3 className="text-base font-black text-stone-900">{t.productDescription}</h3>
          <p className="text-sm text-stone-700 whitespace-pre-line leading-relaxed font-normal">
            {selectedProduct.description}
          </p>
        </div>

        {/* Seller Profile Card (Clickable to Seller Page) */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-stone-900">{t.sellerInfo}</h3>
            <button
              onClick={() => openSellerProfile(selectedProduct.seller)}
              className="text-xs font-bold text-[#3976A8] hover:underline"
            >
              {t.viewSellerProfile}
            </button>
          </div>

          <div
            onClick={() => openSellerProfile(selectedProduct.seller)}
            className="flex items-center gap-3 p-3 rounded-2xl bg-stone-50 border border-stone-200 cursor-pointer hover:bg-stone-100 transition-colors"
          >
            <img
              src={selectedProduct.seller.avatar}
              alt={selectedProduct.seller.name}
              className="w-12 h-12 rounded-xl object-cover ring-2 ring-[#3976A8]/20 shrink-0"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-black text-stone-900 truncate">
                  {selectedProduct.seller.name}
                </span>
                {selectedProduct.seller.verified && (
                  <CheckCircle2 className="w-4 h-4 text-[#3976A8] shrink-0" />
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-stone-500 mt-0.5">
                <span className="text-amber-600 font-bold">★ {selectedProduct.seller.rating}</span>
                <span>•</span>
                <span>{selectedProduct.seller.soldCount} {t.soldItems}</span>
              </div>
            </div>
          </div>

          {/* Quick Contact Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <a
              href={`tel:${selectedProduct.seller.phone}`}
              className="py-3 rounded-xl border border-stone-300 bg-white hover:bg-stone-50 font-bold text-stone-800 text-xs flex items-center justify-center gap-1.5"
            >
              <Phone className="w-4 h-4 text-stone-600" />
              <span>{t.callSeller}</span>
            </a>

            {selectedProduct.seller.whatsapp && (
              <a
                href={`https://wa.me/${selectedProduct.seller.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{t.whatsappChat}</span>
              </a>
            )}
          </div>
        </div>

        {/* Safety Guide Notice */}
        <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200/70 text-xs text-stone-700 space-y-1">
          <div className="flex items-center gap-1.5 font-bold text-[#3976A8]">
            <ShieldCheck className="w-4 h-4" />
            <span>{t.menuSafety}</span>
          </div>
          <p className="leading-relaxed text-stone-600">
            {t.buyerSafetyIntro}
          </p>
        </div>

        {/* Report Listing Trigger (Requirement 7) */}
        <div className="pt-2 text-center">
          <button
            onClick={() => openReportPage('product', selectedProduct.id, selectedProduct.title)}
            className="inline-flex items-center gap-1.5 text-xs text-stone-500 hover:text-red-600 font-bold py-2 px-3 rounded-lg hover:bg-red-50 transition-colors"
          >
            <Flag className="w-3.5 h-3.5" />
            <span>{t.reportListing}</span>
          </button>
        </div>
      </div>

      {/* Fixed Bottom Action Bar */}
      <div className="fixed bottom-0 inset-x-0 z-30 bg-white border-t border-stone-200 p-3 shadow-lg max-w-2xl mx-auto">
        <div className="flex items-center gap-2">
          {/* Add to Cart button (Requirement 11) */}
          <button
            onClick={() => addToCart(selectedProduct)}
            className={`flex-1 py-3 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
              inCart
                ? 'bg-stone-100 text-stone-800 border border-stone-300'
                : 'bg-white border-2 border-[#3976A8] text-[#3976A8] hover:bg-blue-50/50'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            <span>{inCart ? t.inCart : t.addToCart}</span>
          </button>

          {/* Chat with Seller button */}
          <button
            onClick={() => startChatWithSeller(selectedProduct)}
            className="flex-1 py-3 px-4 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xs transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{t.chatWithSeller}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
