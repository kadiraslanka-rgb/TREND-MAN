import React from 'react';
import { ArrowRight, ArrowLeft, Heart } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../ProductCard';

export const FavoritesPage: React.FC = () => {
  const { products, favorites, navigateTo, goBack, t, language } = useApp();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const favProducts = products.filter((p) => favorites.includes(p.id));

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.menuFavorites}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {favProducts.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-3 shadow-xs my-8">
            <Heart className="w-12 h-12 text-stone-300 mx-auto" />
            <h2 className="text-base font-black text-stone-900">{t.noFavoritesYet}</h2>
            <p className="text-xs text-stone-500 max-w-xs mx-auto">
              {t.noFavoritesSub}
            </p>
            <div className="pt-2">
              <button
                onClick={() => navigateTo('home')}
                className="px-6 py-3 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-xs shadow-xs"
              >
                {t.browseCategories}
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {favProducts.map((prod) => (
              <ProductCard key={prod.id} product={prod} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
