import React, { useState } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  Scale,
  ShieldCheck,
  FileText,
  AlertTriangle,
  Truck,
  UserCheck,
  Building2,
  HelpCircle,
  Users
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { LegalDocumentType } from '../../types';
import { LEGAL_DOCS_CONTENT } from '../../data/legalDocsContent';

interface LegalPageProps {
  initialDoc?: LegalDocumentType;
}

export const LegalPage: React.FC<LegalPageProps> = ({ initialDoc }) => {
  const { selectedLegalDoc, goBack, t, language } = useApp();
  const [activeDoc, setActiveDoc] = useState<LegalDocumentType>(initialDoc || selectedLegalDoc || 'terms');

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const docTabs: { id: LegalDocumentType; title: string; icon: React.ElementType }[] = [
    { id: 'terms', title: t.menuTerms, icon: FileText },
    { id: 'privacy', title: t.menuPrivacy, icon: Scale },
    { id: 'marketplace_rules', title: t.menuRules, icon: Building2 },
    { id: 'prohibited_items', title: t.menuProhibited, icon: AlertTriangle },
    { id: 'buyer_safety', title: t.menuSafety, icon: ShieldCheck },
    { id: 'seller_rules', title: t.menuSellerRules, icon: UserCheck },
    { id: 'shipping_rules', title: t.menuShipping, icon: Truck },
    { id: 'refund_dispute', title: t.menuRefundDispute, icon: HelpCircle },
    { id: 'community_guidelines', title: t.menuCommunityGuidelines, icon: Users }
  ];

  const currentDoc =
    LEGAL_DOCS_CONTENT[language]?.[activeDoc] ||
    LEGAL_DOCS_CONTENT['en']?.[activeDoc] ||
    LEGAL_DOCS_CONTENT['ar']['terms'];

  const isProhibited = activeDoc === 'prohibited_items';

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.legalSectionTitle}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Important Statutory Legal Disclaimer Banner (Requirement 4 & 8) */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-[#3976A8] font-black text-sm">
            <Scale className="w-5 h-5 shrink-0" />
            <span>{t.legalDisclaimerTitle}</span>
          </div>
          <p className="text-xs text-stone-600 leading-relaxed font-medium">
            {t.legalDisclaimerBody}
          </p>
        </div>

        {/* Tab Selector Buttons */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {docTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeDoc === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveDoc(tab.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-2xl text-xs font-bold shrink-0 transition-colors ${
                  isActive
                    ? 'bg-[#3976A8] text-white shadow-xs'
                    : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{tab.title}</span>
              </button>
            );
          })}
        </div>

        {/* Legal Text Content Card */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs space-y-5 text-xs leading-relaxed text-stone-700 font-normal">
          {/* Document Header */}
          <div className="border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              {isProhibited && <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />}
              <h2 className={`text-base font-black ${isProhibited ? 'text-red-700' : 'text-stone-900'}`}>
                {currentDoc.title}
              </h2>
            </div>
            {currentDoc.subtitle && (
              <p className="text-stone-500 font-medium text-xs mt-1">
                {currentDoc.subtitle}
              </p>
            )}
          </div>

          {/* Document Sections */}
          <div className="space-y-4">
            {currentDoc.sections.map((section, sIdx) => (
              <div key={sIdx} className="space-y-2">
                <h3 className={`text-xs font-black ${isProhibited ? 'text-red-800' : 'text-stone-900'}`}>
                  {section.title}
                </h3>
                {section.paragraphs.map((p, pIdx) => (
                  <p key={pIdx} className="leading-relaxed">
                    {p}
                  </p>
                ))}
                {section.listItems && section.listItems.length > 0 && (
                  <ul className={`list-disc list-inside space-y-1.5 pt-1 font-medium ${isProhibited ? 'text-stone-900 bg-red-50/60 p-3 rounded-2xl border border-red-200/80' : 'text-stone-700'}`}>
                    {section.listItems.map((item, lIdx) => (
                      <li key={lIdx} className="leading-relaxed">
                        {item}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
