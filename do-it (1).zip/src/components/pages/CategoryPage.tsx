import React, { useState } from 'react';
import { ArrowRight, ArrowLeft, Filter, Tag } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../ProductCard';

export const CategoryPage: React.FC = () => {
  const { selectedCategory, products, openProductDetail, goBack, t, language } = useApp();
  const [selectedSubId, setSelectedSubId] = useState<string>('all');

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  if (!selectedCategory) {
    return (
      <div className="min-h-screen bg-[#FAF8F5] p-6 text-center flex flex-col items-center justify-center">
        <p className="text-stone-500 font-bold mb-4">{t.noProductsFound}</p>
        <button onClick={goBack} className="px-6 py-2.5 rounded-xl bg-[#3976A8] text-white font-bold text-sm">
          {t.back}
        </button>
      </div>
    );
  }

  const categoryProducts = products.filter((p) => {
    if (p.categoryId !== selectedCategory.id) return false;
    if (selectedSubId !== 'all' && p.subcategoryId !== selectedSubId) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900 truncate">
          {selectedCategory.name[language === 'en' ? 'en' : language === 'tr' ? 'tr' : 'ar']}
        </h1>

        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Subcategories Horizontal Scroll */}
        {selectedCategory.subcategories.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            <button
              onClick={() => setSelectedSubId('all')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-colors ${
                selectedSubId === 'all'
                  ? 'bg-[#3976A8] text-white shadow-xs'
                  : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
              }`}
            >
              {t.tabAll} ({products.filter((p) => p.categoryId === selectedCategory.id).length})
            </button>

            {selectedCategory.subcategories.map((sub) => {
              const count = products.filter(
                (p) => p.categoryId === selectedCategory.id && p.subcategoryId === sub.id
              ).length;

              return (
                <button
                  key={sub.id}
                  onClick={() => setSelectedSubId(sub.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-colors ${
                    selectedSubId === sub.id
                      ? 'bg-[#3976A8] text-white shadow-xs'
                      : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  {sub.name[language === 'en' ? 'en' : language === 'tr' ? 'tr' : 'ar']} ({count})
                </button>
              );
            })}
          </div>
        )}

        {/* Products Grid */}
        {categoryProducts.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-2 my-6">
            <Tag className="w-10 h-10 text-stone-300 mx-auto" />
            <h2 className="text-sm font-bold text-stone-700">{t.noProductsFound}</h2>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {categoryProducts.map((prod) => (
              <ProductCard key={prod.id} product={prod} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
