import React, { useState } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  Headphones,
  HelpCircle,
  Send,
  ChevronDown
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const HelpSupportPage: React.FC = () => {
  const { goBack, t, language } = useApp();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'support'; text: string }>>([
    {
      sender: 'support',
      text: t.supportChatGreeting
    }
  ]);

  const faqs = [
    { q: t.faq1Q, a: t.faq1A },
    { q: t.faq2Q, a: t.faq2A },
    { q: t.faq3Q, a: t.faq3A },
    { q: t.faq4Q, a: t.faq4A }
  ];

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userText = chatInput.trim();
    setChatMessages((prev) => [...prev, { sender: 'user', text: userText }]);
    setChatInput('');

    setTimeout(() => {
      let reply = t.supportAutoReplyGeneric;
      const lower = userText.toLowerCase();
      if (lower.includes('شحن') || lower.includes('توصيل') || lower.includes('ship') || lower.includes('kargo')) {
        reply = t.supportAutoReplyShipping;
      } else if (lower.includes('دفع') || lower.includes('فلوس') || lower.includes('pay') || lower.includes('ödeme')) {
        reply = t.supportAutoReplyPayment;
      } else if (lower.includes('حظر') || lower.includes('ممنوع') || lower.includes('prohibit') || lower.includes('yasak')) {
        reply = t.supportAutoReplyProhibited;
      }
      setChatMessages((prev) => [...prev, { sender: 'support', text: reply }]);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.liveSupportTitle}</h1>
        <div className="w-12" />
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Support Agent Card */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#3976A8] flex items-center justify-center font-bold text-lg shrink-0">
              <Headphones className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-sm font-black text-stone-900">{t.supportAssistantName}</h2>
              <div className="flex items-center gap-1 text-xs text-emerald-600 font-bold mt-0.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>{t.supportOnlineBadge}</span>
              </div>
            </div>
          </div>

          {/* Mini Interactive Assistant Chat */}
          <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-100 space-y-2.5 max-h-60 overflow-y-auto">
            {chatMessages.map((m, idx) => (
              <div
                key={idx}
                className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3 rounded-2xl text-xs font-medium leading-relaxed ${
                    m.sender === 'user'
                      ? 'bg-[#3976A8] text-white rounded-br-none'
                      : 'bg-white text-stone-800 border border-stone-200 rounded-bl-none shadow-2xs'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
          </div>

          {/* Chat Form */}
          <form onSubmit={handleSendChat} className="flex gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder={t.supportChatPlaceholder}
              className="flex-1 px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs font-medium outline-hidden focus:border-[#3976A8]"
            />
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-xs shadow-xs"
            >
              <Send className={`w-3.5 h-3.5 ${isRtl ? 'rotate-180' : ''}`} />
            </button>
          </form>
        </div>

        {/* FAQs Section */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-stone-900 font-black text-sm pb-1 border-b border-stone-100">
            <HelpCircle className="w-4 h-4 text-[#3976A8]" />
            <span>{t.faqTitle}</span>
          </div>

          <div className="space-y-2">
            {faqs.map((faq, idx) => {
              const isExpanded = expandedFaq === idx;
              return (
                <div key={idx} className="border border-stone-100 rounded-2xl overflow-hidden">
                  <button
                    onClick={() => setExpandedFaq(isExpanded ? null : idx)}
                    className="w-full flex items-center justify-between p-3.5 bg-stone-50/70 hover:bg-stone-100/70 transition-colors text-start"
                  >
                    <span className="text-xs font-bold text-stone-800">{faq.q}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-stone-400 transition-transform ${
                        isExpanded ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {isExpanded && (
                    <div className="p-3.5 bg-white text-xs text-stone-600 leading-relaxed border-t border-stone-100">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
