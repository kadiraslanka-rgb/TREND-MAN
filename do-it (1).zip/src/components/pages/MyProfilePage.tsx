import React from 'react';
import {
  ArrowRight,
  ArrowLeft,
  MapPin,
  CheckCircle2,
  Package,
  Heart,
  PlusCircle,
  Settings,
  ShieldCheck,
  Star,
  LogOut,
  Mail,
  Phone
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { ProductCard } from '../ProductCard';

export const MyProfilePage: React.FC = () => {
  const { products, favorites, navigateTo, goBack, t, language } = useApp();
  const { currentUser, logout } = useAuth();

  const isRtl = language === 'ar';
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#FAF8F5] p-6 text-center flex flex-col items-center justify-center">
        <p className="text-stone-500 font-bold mb-4">{t.welcomeSubtitle}</p>
        <button
          onClick={() => navigateTo('welcome_auth')}
          className="px-6 py-2.5 rounded-xl bg-[#3976A8] text-white font-bold text-sm shadow-xs"
        >
          {t.loginAccount}
        </button>
      </div>
    );
  }

  const myListings = products.filter((p) => p.seller.id === currentUser.id);

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between shadow-xs">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-colors"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t.back}</span>
        </button>

        <h1 className="text-sm font-black text-stone-900">{t.menuProfile}</h1>

        <button
          onClick={() => navigateTo('account_settings')}
          className="w-9 h-9 rounded-xl border border-stone-200 flex items-center justify-center text-stone-600 hover:bg-stone-50"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Profile Card */}
        <div className="bg-white rounded-3xl p-5 border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-16 h-16 rounded-2xl object-cover ring-2 ring-[#3976A8]/20 shrink-0"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <h2 className="text-base font-black text-stone-900 truncate">
                  {currentUser.name}
                </h2>
                {currentUser.verified && (
                  <CheckCircle2 className="w-4 h-4 text-[#3976A8] shrink-0" />
                )}
              </div>

              <div className="flex items-center gap-1 text-stone-500 text-xs mt-0.5">
                <MapPin className="w-3.5 h-3.5 text-stone-400" />
                <span>{currentUser.city}، {currentUser.governorate}</span>
              </div>

              <div className="flex items-center gap-2 mt-1 text-xs">
                <span className="text-amber-600 font-bold flex items-center gap-0.5">
                  <Star className="w-3.5 h-3.5 fill-amber-500" />
                  {currentUser.rating} ({currentUser.reviewCount})
                </span>
                <span>•</span>
                <span className="text-stone-400">{currentUser.memberSince}</span>
              </div>
            </div>
          </div>

          {/* User Stats Row */}
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-stone-100 text-center">
            <div
              onClick={() => navigateTo('my_listings')}
              className="p-2.5 bg-stone-50 rounded-2xl cursor-pointer hover:bg-stone-100 transition-colors"
            >
              <span className="text-stone-400 block text-[10px] mb-0.5">{t.activeAds}</span>
              <span className="font-black text-stone-900 text-sm">{myListings.length}</span>
            </div>

            <div
              onClick={() => navigateTo('favorites')}
              className="p-2.5 bg-stone-50 rounded-2xl cursor-pointer hover:bg-stone-100 transition-colors"
            >
              <span className="text-stone-400 block text-[10px] mb-0.5">{t.menuFavorites}</span>
              <span className="font-black text-stone-900 text-sm">{favorites.length}</span>
            </div>

            <div className="p-2.5 bg-stone-50 rounded-2xl">
              <span className="text-stone-400 block text-[10px] mb-0.5">{t.soldItems}</span>
              <span className="font-black text-[#3976A8] text-sm">{currentUser.soldCount}</span>
            </div>
          </div>

          {/* Sell Button CTA */}
          <button
            onClick={() => navigateTo('add_product')}
            className="w-full py-3 rounded-2xl bg-[#3976A8] hover:bg-[#2F6490] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xs transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.publishAd}</span>
          </button>
        </div>

        {/* User Listings Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-sm font-black text-stone-900">{t.menuMyListings}</h3>
            {myListings.length > 0 && (
              <span className="text-xs text-stone-500 font-bold">{myListings.length} {t.itemsCount}</span>
            )}
          </div>

          {myListings.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-2">
              <Package className="w-10 h-10 text-stone-300 mx-auto" />
              <p className="text-xs font-bold text-stone-600">{t.noProductsFound}</p>
              <button
                onClick={() => navigateTo('add_product')}
                className="mt-2 px-5 py-2.5 rounded-xl bg-[#3976A8] text-white font-bold text-xs"
              >
                {t.publishAd}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {myListings.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
