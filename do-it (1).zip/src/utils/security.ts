/**
 * Security utilities for Doolab Masr marketplace
 * Adheres to secure client-side practices: hashing, file validation, XSS prevention.
 */

// Hash password with SHA-256
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'doolab_masr_salt_2026');
  
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    try {
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    } catch {
      // Fallback below
    }
  }

  // Simple deterministic fallback hash if crypto.subtle is unavailable
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return 'hashed_' + Math.abs(hash).toString(16);
}

// Generate 6-digit numeric verification code
export function generateVerificationCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Image File Validation (Type and Size limit)
export interface FileValidationResult {
  valid: boolean;
  errorKey?: 'invalid_type' | 'file_too_large';
}

const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB

export function validateImageFile(file: File): FileValidationResult {
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    return { valid: false, errorKey: 'invalid_type' };
  }
  if (file.size > MAX_IMAGE_SIZE_BYTES) {
    return { valid: false, errorKey: 'file_too_large' };
  }
  return { valid: true };
}

// Sanitization for visible user inputs (prevents basic XSS)
export function sanitizeInput(text: string): string {
  return text
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}

// Rate Limiter for Login Attempts
const loginAttempts: Record<string, { count: number; lockedUntil: number }> = {};

export function checkLoginRateLimit(email: string): { allowed: boolean; remainingLockSeconds?: number } {
  const normalizedEmail = email.toLowerCase().trim();
  const record = loginAttempts[normalizedEmail];
  const now = Date.now();

  if (record && record.lockedUntil > now) {
    const remaining = Math.ceil((record.lockedUntil - now) / 1000);
    return { allowed: false, remainingLockSeconds: remaining };
  }

  return { allowed: true };
}

export function recordFailedLogin(email: string): void {
  const normalizedEmail = email.toLowerCase().trim();
  const now = Date.now();
  const record = loginAttempts[normalizedEmail] || { count: 0, lockedUntil: 0 };
  
  record.count += 1;
  if (record.count >= 5) {
    record.lockedUntil = now + 60 * 1000; // 60 seconds lock
    record.count = 0;
  }
  loginAttempts[normalizedEmail] = record;
}

export function resetLoginAttempts(email: string): void {
  const normalizedEmail = email.toLowerCase().trim();
  delete loginAttempts[normalizedEmail];
}
