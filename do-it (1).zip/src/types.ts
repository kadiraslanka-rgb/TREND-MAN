export type Language = 'ar' | 'en' | 'tr';

export type ProductCondition =
  | 'new_with_tags'
  | 'new'
  | 'like_new'
  | 'lightly_used'
  | 'heavily_used';

export type DeliveryMethod = 'face_to_face' | 'shipping' | 'both';

export type ShippingPayer = 'buyer' | 'seller';

export interface Category {
  id: string;
  name: { ar: string; en: string; tr: string };
  icon: string;
  subcategories: { id: string; name: { ar: string; en: string; tr: string } }[];
  popularBrands?: string[];
}

export interface Brand {
  id: string;
  name: string;
  categoryIds: string[];
  isPopularInEgypt?: boolean;
}

export interface EgyptianCity {
  id: string;
  name: { ar: string; en: string };
}

export interface Governorate {
  id: string;
  name: { ar: string; en: string };
  cities: EgyptianCity[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  whatsapp?: string;
  governorate: string;
  city: string;
  avatar: string;
  passwordHash?: string;
  isEmailVerified: boolean;
  verificationCode?: string;
  memberSince: string;
  rating: number;
  reviewCount: number;
  activeListingsCount: number;
  soldCount: number;
  responseRate: string;
  verified: boolean;
}

export type Seller = User;

export interface Product {
  id: string;
  title: string;
  price: number; // in EGP
  originalPrice?: number;
  categoryId: string;
  subcategoryId?: string;
  brand: string;
  customBrandName?: string;
  condition: ProductCondition;
  
  // Defect Information (Required)
  hasDefects: boolean;
  defectDescription?: string;
  defectImages?: string[];

  // Delivery & Shipping (Required)
  deliveryMethod: DeliveryMethod;
  estimatedShippingCost?: number; // Optional estimated cost in EGP
  shippingFee?: number;
  shippingPayer?: ShippingPayer;
  estimatedDeliveryDays?: string;
  shippingStatus?: 'pending' | 'shipped' | 'delivered';
  trackingNumber?: string;

  // Prohibited Policy Confirmation
  acceptedProhibitedPolicy?: boolean;

  description: string;
  images: string[];
  location: {
    governorate: string;
    city: string;
  };
  seller: Seller;
  createdAt: string;
  views: number;
  isFeatured?: boolean;
  negotiable?: boolean;
}

export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  addedAt: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  isOffer?: boolean;
  offerAmount?: number;
  offerStatus?: 'pending' | 'accepted' | 'rejected';
  isShippingUpdate?: boolean;
  trackingNumber?: string;
}

export interface Conversation {
  id: string;
  productId: string;
  product: Product;
  otherUser: Seller;
  messages: ChatMessage[];
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
}

export interface FilterState {
  categoryId?: string;
  subcategoryId?: string;
  brand?: string;
  governorate?: string;
  city?: string;
  minPrice?: number;
  maxPrice?: number;
  condition?: ProductCondition[];
  deliveryMethod?: DeliveryMethod;
  hasDefects?: boolean;
  sortBy: 'newest' | 'price_low' | 'price_high' | 'popular';
  searchQuery: string;
}

export type LegalDocumentType =
  | 'terms'
  | 'privacy'
  | 'marketplace_rules'
  | 'prohibited_items'
  | 'buyer_safety'
  | 'seller_rules'
  | 'shipping_rules'
  | 'refund_dispute'
  | 'community_guidelines';

export type ReportReason =
  | 'prohibited_product'
  | 'counterfeit'
  | 'scam_fraud'
  | 'misleading_description'
  | 'dangerous_product'
  | 'stolen_product'
  | 'inappropriate_content'
  | 'other';

export interface ReportTicket {
  id: string;
  targetType: 'product' | 'user';
  targetId: string;
  targetTitle: string;
  reason: ReportReason;
  details: string;
  reporterEmail: string;
  createdAt: string;
  status: 'submitted' | 'under_review' | 'resolved';
}

export type ScreenType =
  | 'home'
  | 'messages'
  | 'cart'
  | 'add_product'
  | 'menu'
  | 'product_detail'
  | 'conversation'
  | 'category'
  | 'seller_profile'
  | 'my_profile'
  | 'my_listings'
  | 'favorites'
  | 'orders'
  | 'shipping_rules'
  | 'account_settings'
  | 'language_settings'
  | 'notifications'
  | 'help_support'
  | 'safety_guide'
  | 'terms'
  | 'privacy'
  | 'marketplace_rules'
  | 'prohibited_items'
  | 'buyer_safety'
  | 'seller_rules'
  | 'refund_dispute'
  | 'community_guidelines'
  | 'report_problem'
  | 'welcome_auth';
