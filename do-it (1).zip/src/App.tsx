/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AuthProvider } from './context/AuthContext';
import { AppProvider, useApp } from './context/AppContext';
import { BottomNav } from './components/BottomNav';

// Full Screen Pages (Requirement 1 - Full Separate Pages, No Popups/Modals)
import { WelcomeAuthPage } from './components/pages/WelcomeAuthPage';
import { HomePage } from './components/pages/HomePage';
import { ProductDetailPage } from './components/pages/ProductDetailPage';
import { AddProductPage } from './components/pages/AddProductPage';
import { CartPage } from './components/pages/CartPage';
import { MessagesPage } from './components/pages/MessagesPage';
import { ConversationPage } from './components/pages/ConversationPage';
import { CategoryPage } from './components/pages/CategoryPage';
import { SellerProfilePage } from './components/pages/SellerProfilePage';
import { MenuPage } from './components/pages/MenuPage';
import { MyProfilePage } from './components/pages/MyProfilePage';
import { MyListingsPage } from './components/pages/MyListingsPage';
import { FavoritesPage } from './components/pages/FavoritesPage';
import { OrdersPage } from './components/pages/OrdersPage';
import { LegalPage } from './components/pages/LegalPage';
import { ReportPage } from './components/pages/ReportPage';
import { AccountSettingsPage } from './components/pages/AccountSettingsPage';
import { LanguageSettingsPage } from './components/pages/LanguageSettingsPage';
import { NotificationsPage } from './components/pages/NotificationsPage';
import { HelpSupportPage } from './components/pages/HelpSupportPage';

const AppContent: React.FC = () => {
  const { currentScreen } = useApp();

  const isLegalDoc = [
    'terms',
    'privacy',
    'marketplace_rules',
    'prohibited_items',
    'buyer_safety',
    'seller_rules',
    'shipping_rules',
    'refund_dispute',
    'community_guidelines'
  ].includes(currentScreen);

  return (
    <div className="min-h-screen bg-[#FAF8F5] flex justify-center text-stone-900 font-sans">
      {/* Mobile-first Android/iOS Container */}
      <div className="w-full max-w-2xl min-h-screen bg-[#FAF8F5] shadow-xl flex flex-col relative border-x border-stone-200/80">
        <main className="flex-1">
          {currentScreen === 'welcome_auth' && <WelcomeAuthPage />}
          {currentScreen === 'home' && <HomePage />}
          {currentScreen === 'product_detail' && <ProductDetailPage />}
          {currentScreen === 'add_product' && <AddProductPage />}
          {currentScreen === 'cart' && <CartPage />}
          {currentScreen === 'messages' && <MessagesPage />}
          {currentScreen === 'conversation' && <ConversationPage />}
          {currentScreen === 'category' && <CategoryPage />}
          {currentScreen === 'seller_profile' && <SellerProfilePage />}
          {currentScreen === 'menu' && <MenuPage />}
          {currentScreen === 'my_profile' && <MyProfilePage />}
          {currentScreen === 'my_listings' && <MyListingsPage />}
          {currentScreen === 'favorites' && <FavoritesPage />}
          {currentScreen === 'orders' && <OrdersPage />}
          {isLegalDoc && <LegalPage initialDoc={currentScreen as any} />}
          {currentScreen === 'safety_guide' && <LegalPage initialDoc="buyer_safety" />}
          {currentScreen === 'report_problem' && <ReportPage />}
          {currentScreen === 'account_settings' && <AccountSettingsPage />}
          {currentScreen === 'language_settings' && <LanguageSettingsPage />}
          {currentScreen === 'notifications' && <NotificationsPage />}
          {currentScreen === 'help_support' && <HelpSupportPage />}
        </main>

        {/* Bottom Navigation is displayed across standard marketplace screens */}
        {currentScreen !== 'welcome_auth' && currentScreen !== 'conversation' && <BottomNav />}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </AuthProvider>
  );
}
