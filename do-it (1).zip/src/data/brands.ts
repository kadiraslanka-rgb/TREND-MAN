import { Brand } from '../types';

export const BRANDS: Brand[] = [
  // Mobile & Tech
  { id: 'apple', name: 'Apple', categoryIds: ['phones-electronics', 'computers-laptops', 'watches-accessories'], isPopularInEgypt: true },
  { id: 'samsung', name: 'Samsung', categoryIds: ['phones-electronics', 'home-appliances', 'tvs'], isPopularInEgypt: true },
  { id: 'xiaomi', name: 'Xiaomi', categoryIds: ['phones-electronics', 'home-appliances'], isPopularInEgypt: true },
  { id: 'oppo', name: 'Oppo', categoryIds: ['phones-electronics'], isPopularInEgypt: true },
  { id: 'realme', name: 'Realme', categoryIds: ['phones-electronics'], isPopularInEgypt: true },
  { id: 'huawei', name: 'Huawei', categoryIds: ['phones-electronics', 'computers-laptops'], isPopularInEgypt: true },
  { id: 'infinix', name: 'Infinix', categoryIds: ['phones-electronics'], isPopularInEgypt: true },
  { id: 'vivo', name: 'Vivo', categoryIds: ['phones-electronics'], isPopularInEgypt: true },
  { id: 'sony', name: 'Sony', categoryIds: ['phones-electronics', 'games-consoles', 'home-appliances'], isPopularInEgypt: true },
  { id: 'oneplus', name: 'OnePlus', categoryIds: ['phones-electronics'] },
  { id: 'google', name: 'Google Pixel', categoryIds: ['phones-electronics'] },
  { id: 'nokia', name: 'Nokia', categoryIds: ['phones-electronics'] },

  // Computers & Laptops
  { id: 'dell', name: 'Dell', categoryIds: ['computers-laptops'], isPopularInEgypt: true },
  { id: 'hp', name: 'HP', categoryIds: ['computers-laptops'], isPopularInEgypt: true },
  { id: 'lenovo', name: 'Lenovo', categoryIds: ['computers-laptops'], isPopularInEgypt: true },
  { id: 'asus', name: 'Asus', categoryIds: ['computers-laptops'], isPopularInEgypt: true },
  { id: 'acer', name: 'Acer', categoryIds: ['computers-laptops'] },
  { id: 'msi', name: 'MSI', categoryIds: ['computers-laptops'] },
  { id: 'razer', name: 'Razer', categoryIds: ['computers-laptops', 'games-consoles'] },
  { id: 'logitech', name: 'Logitech', categoryIds: ['computers-laptops', 'games-consoles'], isPopularInEgypt: true },

  // Home Appliances (Egypt Favorites)
  { id: 'tornado', name: 'Tornado', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'fresh', name: 'Fresh', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'unionaire', name: 'Unionaire', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'sharp', name: 'Sharp', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'toshiba', name: 'Toshiba', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'beko', name: 'Beko', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'lg', name: 'LG', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'carrier', name: 'Carrier', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'kiriazi', name: 'Kiriazi', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'zanussi', name: 'Zanussi', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'kenwood', name: 'Kenwood', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'philips', name: 'Philips', categoryIds: ['home-appliances', 'phones-electronics'], isPopularInEgypt: true },
  { id: 'braun', name: 'Braun', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'moulinex', name: 'Moulinex', categoryIds: ['home-appliances'], isPopularInEgypt: true },
  { id: 'tefal', name: 'Tefal', categoryIds: ['home-appliances'], isPopularInEgypt: true },

  // Fashion & Shoes
  { id: 'nike', name: 'Nike', categoryIds: ['fashion-clothes', 'shoes-footwear', 'sports-fitness'], isPopularInEgypt: true },
  { id: 'adidas', name: 'Adidas', categoryIds: ['fashion-clothes', 'shoes-footwear', 'sports-fitness'], isPopularInEgypt: true },
  { id: 'zara', name: 'Zara', categoryIds: ['fashion-clothes', 'shoes-footwear', 'watches-accessories'], isPopularInEgypt: true },
  { id: 'hm', name: 'H&M', categoryIds: ['fashion-clothes'], isPopularInEgypt: true },
  { id: 'defacto', name: 'Defacto', categoryIds: ['fashion-clothes'], isPopularInEgypt: true },
  { id: 'lc-waikiki', name: 'LC Waikiki', categoryIds: ['fashion-clothes'], isPopularInEgypt: true },
  { id: 'town-team', name: 'Town Team', categoryIds: ['fashion-clothes'], isPopularInEgypt: true },
  { id: 'concrete', name: 'Concrete', categoryIds: ['fashion-clothes'], isPopularInEgypt: true },
  { id: 'mobaco', name: 'Mobaco Cottons', categoryIds: ['fashion-clothes'], isPopularInEgypt: true },
  { id: 'pull-bear', name: 'Pull & Bear', categoryIds: ['fashion-clothes'], isPopularInEgypt: true },
  { id: 'bershka', name: 'Bershka', categoryIds: ['fashion-clothes'], isPopularInEgypt: true },
  { id: 'stradivarius', name: 'Stradivarius', categoryIds: ['fashion-clothes'] },
  { id: 'mango', name: 'Mango', categoryIds: ['fashion-clothes'] },
  { id: 'tommy-hilfiger', name: 'Tommy Hilfiger', categoryIds: ['fashion-clothes', 'watches-accessories'], isPopularInEgypt: true },
  { id: 'polo', name: 'Polo Ralph Lauren', categoryIds: ['fashion-clothes'], isPopularInEgypt: true },
  { id: 'puma', name: 'Puma', categoryIds: ['fashion-clothes', 'shoes-footwear'], isPopularInEgypt: true },
  { id: 'skechers', name: 'Skechers', categoryIds: ['shoes-footwear'], isPopularInEgypt: true },
  { id: 'new-balance', name: 'New Balance', categoryIds: ['shoes-footwear'], isPopularInEgypt: true },
  { id: 'timberland', name: 'Timberland', categoryIds: ['shoes-footwear', 'fashion-clothes'], isPopularInEgypt: true },
  { id: 'clarks', name: 'Clarks', categoryIds: ['shoes-footwear'] },

  // Watches & Accessories
  { id: 'casio', name: 'Casio (G-Shock / Edifice)', categoryIds: ['watches-accessories'], isPopularInEgypt: true },
  { id: 'rolex', name: 'Rolex', categoryIds: ['watches-accessories'] },
  { id: 'seiko', name: 'Seiko', categoryIds: ['watches-accessories'], isPopularInEgypt: true },
  { id: 'citizen', name: 'Citizen', categoryIds: ['watches-accessories'], isPopularInEgypt: true },
  { id: 'fossil', name: 'Fossil', categoryIds: ['watches-accessories'], isPopularInEgypt: true },
  { id: 'tissot', name: 'Tissot', categoryIds: ['watches-accessories'], isPopularInEgypt: true },
  { id: 'swatch', name: 'Swatch', categoryIds: ['watches-accessories'], isPopularInEgypt: true },
  { id: 'michael-kors', name: 'Michael Kors', categoryIds: ['watches-accessories'], isPopularInEgypt: true },
  { id: 'ray-ban', name: 'Ray-Ban', categoryIds: ['watches-accessories'], isPopularInEgypt: true },

  // Cars & Vehicles
  { id: 'toyota', name: 'Toyota', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'hyundai', name: 'Hyundai', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'kia', name: 'Kia', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'nissan', name: 'Nissan', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'chevrolet', name: 'Chevrolet', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'fiat', name: 'Fiat', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'renault', name: 'Renault', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'mercedes', name: 'Mercedes-Benz', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'bmw', name: 'BMW', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'mitsubishi', name: 'Mitsubishi', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'suzuki', name: 'Suzuki', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'mg', name: 'MG', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'chery', name: 'Chery', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'dayun', name: 'Dayun', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'haojiang', name: 'Haojiang', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },
  { id: 'benelli', name: 'Benelli', categoryIds: ['cars-motorcycles'], isPopularInEgypt: true },

  // Gaming
  { id: 'playstation', name: 'PlayStation', categoryIds: ['games-consoles'], isPopularInEgypt: true },
  { id: 'xbox', name: 'Xbox', categoryIds: ['games-consoles'], isPopularInEgypt: true },
  { id: 'nintendo', name: 'Nintendo', categoryIds: ['games-consoles'] },

  // Furniture & Home
  { id: 'ikea', name: 'IKEA', categoryIds: ['home-furniture'], isPopularInEgypt: true },
  { id: 'kabbani', name: 'Kabbani Furniture', categoryIds: ['home-furniture'], isPopularInEgypt: true },
  { id: 'hub-furniture', name: 'Hub Furniture', categoryIds: ['home-furniture'], isPopularInEgypt: true },
  { id: 'local-damietta', name: 'Damietta Wood (أثاث دمياطي)', categoryIds: ['home-furniture'], isPopularInEgypt: true },

  // Tools & Hardware
  { id: 'bosch', name: 'Bosch', categoryIds: ['tools-hardware'], isPopularInEgypt: true },
  { id: 'dewalt', name: 'DeWalt', categoryIds: ['tools-hardware'], isPopularInEgypt: true },
  { id: 'makita', name: 'Makita', categoryIds: ['tools-hardware'], isPopularInEgypt: true },
  { id: 'total', name: 'Total Tools', categoryIds: ['tools-hardware'], isPopularInEgypt: true },
  { id: 'ingco', name: 'Ingco', categoryIds: ['tools-hardware'], isPopularInEgypt: true },

  // Baby & Kids
  { id: 'chicco', name: 'Chicco', categoryIds: ['baby-kids'], isPopularInEgypt: true },

  // Requirement 7: Keep ONLY 'Other' (No 'Unbranded').
  { id: 'other', name: 'Other', categoryIds: [] }
];
