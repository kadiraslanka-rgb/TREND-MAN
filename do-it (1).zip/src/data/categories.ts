import { Category } from '../types';

export const CATEGORIES: Category[] = [
  {
    id: 'phones-electronics',
    name: {
      ar: 'الموبايلات والإلكترونيات',
      en: 'Phones & Electronics',
      tr: 'Telefon ve Elektronik'
    },
    icon: 'Smartphone',
    popularBrands: ['Apple', 'Samsung', 'Xiaomi', 'Oppo', 'Realme', 'Huawei', 'Infinix', 'Sony'],
    subcategories: [
      { id: 'mobile-phones', name: { ar: 'موبايلات هواتف', en: 'Mobile Phones', tr: 'Akıllı Telefonlar' } },
      { id: 'tablets', name: { ar: 'أجهزة تابلت وآيباد', en: 'Tablets & iPads', tr: 'Tabletler' } },
      { id: 'audio-headphones', name: { ar: 'سماعات وصوتيات', en: 'Headphones & Audio', tr: 'Kulaklık ve Ses' } },
      { id: 'smart-watches', name: { ar: 'ساعات ذكية وأساور', en: 'Smart Watches', tr: 'Akıllı Saatler' } },
      { id: 'cameras', name: { ar: 'كاميرات ومعدات تصوير', en: 'Cameras & Photography', tr: 'Kameralar' } },
      { id: 'phone-accessories', name: { ar: 'شواحن وإكسسوارات', en: 'Chargers & Accessories', tr: 'Aksesuarlar' } }
    ]
  },
  {
    id: 'computers-laptops',
    name: {
      ar: 'الكمبيوتر واللابتوب',
      en: 'Computers & Laptops',
      tr: 'Bilgisayar ve Laptop'
    },
    icon: 'Laptop',
    popularBrands: ['Dell', 'HP', 'Lenovo', 'Apple', 'Asus', 'Acer', 'MSI'],
    subcategories: [
      { id: 'laptops', name: { ar: 'أجهزة لابتوب', en: 'Laptops', tr: 'Dizüstü Bilgisayar' } },
      { id: 'desktop-pcs', name: { ar: 'كمبيوتر مكتبي وشاشات', en: 'Desktop & Monitors', tr: 'Masaüstü ve Monitör' } },
      { id: 'pc-components', name: { ar: 'كروت شاشة ومعالجات', en: 'PC Components', tr: 'Bileşenler' } },
      { id: 'storage-ram', name: { ar: 'هاردات ورامات', en: 'Storage & RAM', tr: 'Depolama ve RAM' } },
      { id: 'pc-accessories', name: { ar: 'كيبورد وماوس وملحقات', en: 'Keyboards & Mice', tr: 'Klavye ve Fare' } }
    ]
  },
  {
    id: 'home-appliances',
    name: {
      ar: 'الأجهزة المنزلية',
      en: 'Home Appliances',
      tr: 'Ev Aletleri'
    },
    icon: 'Tv',
    popularBrands: ['Tornado', 'Fresh', 'Unionaire', 'Sharp', 'Toshiba', 'Beko', 'LG', 'Samsung', 'Carrier', 'Zanussi'],
    subcategories: [
      { id: 'refrigerators', name: { ar: 'ثلاجات وديب فريزر', en: 'Refrigerators & Freezers', tr: 'Buzdolabı' } },
      { id: 'washing-machines', name: { ar: 'غسالات أوتوماتيك', en: 'Washing Machines', tr: 'Çamaşır Makinesi' } },
      { id: 'air-conditioners', name: { ar: 'تكييفات ومراوح', en: 'Air Conditioners & Fans', tr: 'Klimalar' } },
      { id: 'tvs', name: { ar: 'شاشات وتلفزيونات', en: 'TVs & Screens', tr: 'Televizyonlar' } },
      { id: 'microwaves-ovens', name: { ar: 'أفران وميكروويف وبوتاجاز', en: 'Ovens & Stoves', tr: 'Fırın ve Ocaklar' } },
      { id: 'small-appliances', name: { ar: 'خلاطات وأجهزة مطبخ صغيرة', en: 'Small Kitchen Appliances', tr: 'Küçük Mutfak Aletleri' } },
      { id: 'vacuums', name: { ar: 'مكانس كهربائية ومكاوي', en: 'Vacuums & Irons', tr: 'Süpürge ve Ütüler' } }
    ]
  },
  {
    id: 'home-furniture',
    name: {
      ar: 'المنزل والأثاث',
      en: 'Home & Furniture',
      tr: 'Ev ve Mobilya'
    },
    icon: 'Armchair',
    popularBrands: ['IKEA', 'Hub Furniture', 'In & Out', 'Local Artisans', 'Kabbani'],
    subcategories: [
      { id: 'living-room', name: { ar: 'أنتريهات وصالونات', en: 'Living Room Sets', tr: 'Oturma Odası' } },
      { id: 'bedroom', name: { ar: 'غرف نوم ودواليب ومراتب', en: 'Bedrooms & Mattresses', tr: 'Yatak Odası' } },
      { id: 'dining-room', name: { ar: 'سفرة وترابيزات', en: 'Dining Tables', tr: 'Yemek Masaları' } },
      { id: 'office-furniture', name: { ar: 'مكاتب وكراسي مكتب', en: 'Office Furniture', tr: 'Ofis Mobilyası' } },
      { id: 'home-decor', name: { ar: 'ديكور وسجاد ونجف', en: 'Decor, Rugs & Lighting', tr: 'Dekorasyon ve Halı' } }
    ]
  },
  {
    id: 'fashion-clothes',
    name: {
      ar: 'الملابس والأزياء',
      en: 'Fashion & Clothes',
      tr: 'Moda ve Giyim'
    },
    icon: 'Shirt',
    popularBrands: ['Zara', 'H&M', 'Defacto', 'LC Waikiki', 'Town Team', 'Concrete', 'Mobaco', 'Pull&Bear'],
    subcategories: [
      { id: 'mens-clothing', name: { ar: 'ملابس رجالي وبدل', en: "Men's Clothing", tr: 'Erkek Giyim' } },
      { id: 'womens-clothing', name: { ar: 'ملابس نسائية وفساتين', en: "Women's Clothing", tr: 'Kadın Giyim' } },
      { id: 'abayas-veils', name: { ar: 'عبايات وإسدالات وطرح', en: 'Abayas & Modest Wear', tr: 'Abaya ve Başörtüsü' } },
      { id: 'jackets-coats', name: { ar: 'جواكت ومعاطف شتوية', en: 'Jackets & Coats', tr: 'Mont ve Kabanlar' } },
      { id: 'sportswear', name: { ar: 'ترنجات وملابس رياضية', en: 'Sportswear & Tracksuits', tr: 'Spor Giyim' } }
    ]
  },
  {
    id: 'shoes-footwear',
    name: {
      ar: 'الأحذية والكوتشيات',
      en: 'Shoes & Footwear',
      tr: 'Ayakkabılar'
    },
    icon: 'Footprints',
    popularBrands: ['Nike', 'Adidas', 'Puma', 'New Balance', 'Skechers', 'Timberland', 'Zara'],
    subcategories: [
      { id: 'sneakers', name: { ar: 'سنيكرز وأحذية رياضية', en: 'Sneakers', tr: 'Spor Ayakkabı' } },
      { id: 'formal-shoes', name: { ar: 'أحذية كلاسيك وجلد طبيعي', en: 'Formal & Leather Shoes', tr: 'Klasik Ayakkabı' } },
      { id: 'boots', name: { ar: 'بوت وهاف بوت', en: 'Boots', tr: 'Botlar' } },
      { id: 'sandals', name: { ar: 'صنادل وسليبرز', en: 'Sandals & Slides', tr: 'Sandalet ve Terlik' } }
    ]
  },
  {
    id: 'watches-accessories',
    name: {
      ar: 'الساعات والإكسسوارات',
      en: 'Watches & Accessories',
      tr: 'Saat ve Aksesuar'
    },
    icon: 'Watch',
    popularBrands: ['Casio', 'Rolex', 'Seiko', 'Fossil', 'Tissot', 'Citizen', 'Apple', 'Michael Kors'],
    subcategories: [
      { id: 'luxury-watches', name: { ar: 'ساعات يد رجالي وحريمي', en: 'Wristwatches', tr: 'Kol Saatleri' } },
      { id: 'sunglasses', name: { ar: 'نظارات شمسية وماركات', en: 'Sunglasses', tr: 'Güneş Gözlükleri' } },
      { id: 'bags-wallets', name: { ar: 'شنط يد ومحافظ حريمي ورجالي', en: 'Bags & Wallets', tr: 'Çanta ve Cüzdanlar' } },
      { id: 'jewelry-silver', name: { ar: 'فضة وإكسسوارات حريمي', en: 'Jewelry & Silver', tr: 'Takı ve Gümüş' } }
    ]
  },
  {
    id: 'cars-motorcycles',
    name: {
      ar: 'السيارات والموتوسيكلات',
      en: 'Cars & Motorcycles',
      tr: 'Araba ve Motosiklet'
    },
    icon: 'Car',
    popularBrands: ['Toyota', 'Hyundai', 'Kia', 'Nissan', 'Chevrolet', 'Fiat', 'Dayun', 'Haojiang', 'Benelli'],
    subcategories: [
      { id: 'cars', name: { ar: 'سيارات مستعملة للبيع', en: 'Cars for Sale', tr: 'Satılık Arabalar' } },
      { id: 'motorcycles-scooters', name: { ar: 'موتوسيكلات وسكوترز', en: 'Motorcycles & Scooters', tr: 'Motosikletler' } },
      { id: 'car-parts', name: { ar: 'قطع غيار سيارات', en: 'Car Spare Parts', tr: 'Yedek Parça' } },
      { id: 'car-accessories', name: { ar: 'كماليات وإطارات وبطاريات', en: 'Tires, Batteries & Audio', tr: 'Aksesuarlar' } }
    ]
  },
  {
    id: 'games-consoles',
    name: {
      ar: 'ألعاب الفيديو والأجهزة',
      en: 'Games & Consoles',
      tr: 'Oyun ve Konsol'
    },
    icon: 'Gamepad2',
    popularBrands: ['Sony PlayStation', 'Microsoft Xbox', 'Nintendo', 'Logitech', 'Razer'],
    subcategories: [
      { id: 'playstation', name: { ar: 'بلايستيشن وأجهزة PS5/PS4', en: 'PlayStation Consoles', tr: 'PlayStation' } },
      { id: 'xbox', name: { ar: 'أجهزة إكس بوكس Xbox', en: 'Xbox Consoles', tr: 'Xbox' } },
      { id: 'console-games', name: { ar: 'إسطوانات وأشرطة ألعاب', en: 'Games Discs', tr: 'Oyunlar' } },
      { id: 'gaming-accessories', name: { ar: 'دراعات وتحكم وسماعات جيمنج', en: 'Controllers & Gear', tr: 'Oyun Aksesuarları' } }
    ]
  },
  {
    id: 'baby-kids',
    name: {
      ar: 'مستلزمات الأطفال',
      en: 'Baby & Kids',
      tr: 'Bebek ve Çocuk'
    },
    icon: 'Baby',
    popularBrands: ['Chicco', 'Mothercare', 'Graco', 'Pampers', 'Junior'],
    subcategories: [
      { id: 'strollers-car-seats', name: { ar: 'عربات أطفال وكراسي سيارة', en: 'Strollers & Car Seats', tr: 'Bebek Arabaları' } },
      { id: 'baby-clothes', name: { ar: 'ملابس أطفال ورضع', en: 'Baby & Kids Clothes', tr: 'Çocuk Kıyafetleri' } },
      { id: 'toys', name: { ar: 'ألعاب أطفال وسيارات شحن', en: 'Toys & Electric Cars', tr: 'Oyuncaklar' } },
      { id: 'baby-beds', name: { ar: 'أسرّة ومستلزمات نوم للرضع', en: 'Cribs & Nurseries', tr: 'Bebek Yatakları' } }
    ]
  },
  {
    id: 'sports-fitness',
    name: {
      ar: 'الرياضة واللياقة',
      en: 'Sports & Fitness',
      tr: 'Spor ve Fitness'
    },
    icon: 'Dumbbell',
    popularBrands: ['Decathlon', 'Trinfat', 'Everlast', 'Spalding', 'Phoenix Bicycles'],
    subcategories: [
      { id: 'gym-equipment', name: { ar: 'مشايات وأجهزة جيم ودامبلز', en: 'Treadmills & Weights', tr: 'Koşu Bandı ve Ağırlık' } },
      { id: 'bicycles', name: { ar: 'دراجات وعجلات هوائية', en: 'Bicycles', tr: 'Bisikletler' } },
      { id: 'sports-gear', name: { ar: 'كرات وأدوات رياضية', en: 'Sports Equipment', tr: 'Spor Malzemeleri' } }
    ]
  },
  {
    id: 'books-hobbies',
    name: {
      ar: 'الكتب والهوايات',
      en: 'Books & Hobbies',
      tr: 'Kitap ve Hobi'
    },
    icon: 'BookOpen',
    popularBrands: ['Yamaha', 'Roland', 'Casio', 'Fender'],
    subcategories: [
      { id: 'novels-books', name: { ar: 'روايات وكتب فكرية ودينية', en: 'Novels & Books', tr: 'Kitap ve Romanlar' } },
      { id: 'academic-books', name: { ar: 'كتب جامعية ومدرسية', en: 'Academic & School Books', tr: 'Ders Kitapları' } },
      { id: 'musical-instruments', name: { ar: 'آلات موسيقية (عود، جيتار، أورج)', en: 'Musical Instruments', tr: 'Müzik Aletleri' } },
      { id: 'antiques', name: { ar: 'أنتيكات وتحف وعملات قديمة', en: 'Antiques & Collectibles', tr: 'Antika ve Koleksiyon' } }
    ]
  },
  {
    id: 'tools-hardware',
    name: {
      ar: 'العدد والأدوات',
      en: 'Tools & Hardware',
      tr: 'Alet ve Hırdavat'
    },
    icon: 'Wrench',
    popularBrands: ['Bosch', 'DeWalt', 'Makita', 'Total', 'Ingco', 'Crown'],
    subcategories: [
      { id: 'power-tools', name: { ar: 'شنيور وصاروخ ومعدات كهرباء', en: 'Drills & Power Tools', tr: 'Elektrikli Aletler' } },
      { id: 'hand-tools', name: { ar: 'عدد يدوية ومفكات ومفاتيح', en: 'Hand Tools', tr: 'El Aletleri' } },
      { id: 'commercial-gear', name: { ar: 'معدات محلات ومطاعم ومشاريع', en: 'Commercial Equipment', tr: 'Ticari Ekipman' } }
    ]
  },
  {
    id: 'other',
    name: {
      ar: 'أخرى ومتنوعات',
      en: 'Other Items',
      tr: 'Diğer'
    },
    icon: 'Package',
    popularBrands: [],
    subcategories: [
      { id: 'pets-supplies', name: { ar: 'حيوانات أليفة ومستلزماتها', en: 'Pets & Supplies', tr: 'Evcil Hayvanlar' } },
      { id: 'miscellaneous', name: { ar: 'أشياء متنوعة', en: 'General Miscellaneous', tr: 'Çeşitli Eşyalar' } }
    ]
  }
];
