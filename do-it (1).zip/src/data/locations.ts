import { Governorate } from '../types';

export const EGYPT_GOVERNORATES: Governorate[] = [
  {
    id: 'cairo',
    name: { ar: 'القاهرة', en: 'Cairo' },
    cities: [
      { id: 'nasr-city', name: { ar: 'مدينة نصر', en: 'Nasr City' } },
      { id: 'heliopolis', name: { ar: 'مصر الجديدة', en: 'Heliopolis' } },
      { id: 'new-cairo', name: { ar: 'القاهرة الجديدة (التجمع)', en: 'New Cairo (Tagamoa)' } },
      { id: 'maadi', name: { ar: 'المعادي', en: 'Maadi' } },
      { id: 'zamalek', name: { ar: 'الزمالك', en: 'Zamalek' } },
      { id: 'downtown', name: { ar: 'وسط البلد', en: 'Downtown Cairo' } },
      { id: 'shoubra', name: { ar: 'شبرا', en: 'Shoubra' } },
      { id: 'mokattam', name: { ar: 'المقطم', en: 'Mokattam' } },
      { id: 'rehab', name: { ar: 'الرحاب', en: 'Al Rehab' } },
      { id: 'madinaty', name: { ar: 'مدينتي', en: 'Madinaty' } },
      { id: 'shorouk', name: { ar: 'الشروق', en: 'Al Shorouk' } },
      { id: 'ain-shams', name: { ar: 'عين شمس', en: 'Ain Shams' } },
      { id: 'helwan', name: { ar: 'حلوان', en: 'Helwan' } },
      { id: 'hadaiq-qobba', name: { ar: 'حدائق القبة', en: 'Hadaiq El Qobba' } },
      { id: 'badr-city', name: { ar: 'مدينة بدر', en: 'Badr City' } }
    ]
  },
  {
    id: 'giza',
    name: { ar: 'الجيزة', en: 'Giza' },
    cities: [
      { id: 'dokki', name: { ar: 'الدقي', en: 'Dokki' } },
      { id: 'mohandessin', name: { ar: 'المهندسين', en: 'Mohandessin' } },
      { id: 'october-6', name: { ar: '6 أكتوبر', en: '6th of October' } },
      { id: 'sheikh-zayed', name: { ar: 'الشيخ زايد', en: 'Sheikh Zayed' } },
      { id: 'haram', name: { ar: 'الهرم', en: 'Al Haram' } },
      { id: 'faisal', name: { ar: 'فيصل', en: 'Faisal' } },
      { id: 'agouza', name: { ar: 'العجوزة', en: 'Agouza' } },
      { id: 'imbaba', name: { ar: 'إمبابة', en: 'Imbaba' } },
      { id: 'omraneya', name: { ar: 'العمرانية', en: 'Al Omraneya' } },
      { id: 'warraq', name: { ar: 'الوراق', en: 'Al Warraq' } },
      { id: 'hawamdeya', name: { ar: 'الحوامدية', en: 'Al Hawamdeya' } }
    ]
  },
  {
    id: 'alexandria',
    name: { ar: 'الإسكندرية', en: 'Alexandria' },
    cities: [
      { id: 'smouha', name: { ar: 'سموحة', en: 'Smouha' } },
      { id: 'miami', name: { ar: 'ميامي', en: 'Miami' } },
      { id: 'sidi-gaber', name: { ar: 'سيدي جابر', en: 'Sidi Gaber' } },
      { id: 'sidi-bishr', name: { ar: 'سيدي بشر', en: 'Sidi Bishr' } },
      { id: 'loran', name: { ar: 'لوران', en: 'Loran' } },
      { id: 'roushdy', name: { ar: 'رشدي', en: 'Roushdy' } },
      { id: 'gleem', name: { ar: 'جليم', en: 'Gleem' } },
      { id: 'stanly', name: { ar: 'ستانلي', en: 'Stanly' } },
      { id: 'montaza', name: { ar: 'المنتزه', en: 'Al Montaza' } },
      { id: 'agami', name: { ar: 'العجمي', en: 'Al Agami' } },
      { id: 'moharam-bek', name: { ar: 'محرم بك', en: 'Moharam Bek' } },
      { id: 'ibrahimia', name: { ar: 'الإبراهيمية', en: 'Al Ibrahimia' } },
      { id: 'borg-elarab', name: { ar: 'برج العرب', en: 'Borg El Arab' } }
    ]
  },
  {
    id: 'qalyubia',
    name: { ar: 'القليوبية', en: 'Qalyubia' },
    cities: [
      { id: 'banha', name: { ar: 'بنها', en: 'Banha' } },
      { id: 'shubra-kheima', name: { ar: 'شبرا الخيمة', en: 'Shubra El Kheima' } },
      { id: 'obour', name: { ar: 'مدينة العبور', en: 'Obour City' } },
      { id: 'qalyub', name: { ar: 'قليوب', en: 'Qalyub' } },
      { id: 'khanka', name: { ar: 'الخانكة', en: 'Al Khanka' } }
    ]
  },
  {
    id: 'sharqia',
    name: { ar: 'الشرقية', en: 'Sharqia' },
    cities: [
      { id: 'zagazig', name: { ar: 'الزقازيق', en: 'Zagazig' } },
      { id: 'ramadan-10', name: { ar: 'العاشر من رمضان', en: '10th of Ramadan' } },
      { id: 'belbeis', name: { ar: 'بلبيس', en: 'Belbeis' } },
      { id: 'faqous', name: { ar: 'فاقوس', en: 'Faqous' } },
      { id: 'minya-qamh', name: { ar: 'منيا القمح', en: 'Minya El Qamh' } }
    ]
  },
  {
    id: 'dakahlia',
    name: { ar: 'الدقهلية', en: 'Dakahlia' },
    cities: [
      { id: 'mansoura', name: { ar: 'المنصورة', en: 'Mansoura' } },
      { id: 'mit-ghamr', name: { ar: 'ميت غمر', en: 'Mit Ghamr' } },
      { id: 'senbellawin', name: { ar: 'السنبلاوين', en: 'Senbellawin' } },
      { id: 'talkha', name: { ar: 'طلخا', en: 'Talkha' } },
      { id: 'dekernes', name: { ar: 'دكرنس', en: 'Dekernes' } }
    ]
  },
  {
    id: 'gharbia',
    name: { ar: 'الغربية', en: 'Gharbia' },
    cities: [
      { id: 'tanta', name: { ar: 'طنطا', en: 'Tanta' } },
      { id: 'el-mahalla', name: { ar: 'المحلة الكبرى', en: 'El Mahalla El Kubra' } },
      { id: 'kafr-zayat', name: { ar: 'كفر الزيات', en: 'Kafr El Zayat' } },
      { id: 'zefta', name: { ar: 'زفتى', en: 'Zefta' } }
    ]
  },
  {
    id: 'monufia',
    name: { ar: 'المنوفية', en: 'Monufia' },
    cities: [
      { id: 'shebin-koum', name: { ar: 'شبين الكوم', en: 'Shebin El Koum' } },
      { id: 'sadat-city', name: { ar: 'مدينة السادات', en: 'Sadat City' } },
      { id: 'menouf', name: { ar: 'منوف', en: 'Menouf' } },
      { id: 'ashmoun', name: { ar: 'أشمون', en: 'Ashmoun' } },
      { id: 'quesna', name: { ar: 'قويسنا', en: 'Quesna' } }
    ]
  },
  {
    id: 'beheira',
    name: { ar: 'البحيرة', en: 'Beheira' },
    cities: [
      { id: 'damanhour', name: { ar: 'دمنهور', en: 'Damanhour' } },
      { id: 'kafr-el-dawar', name: { ar: 'كفر الدوار', en: 'Kafr El Dawar' } },
      { id: 'etay-baroud', name: { ar: 'إيتاي البارود', en: 'Etay El Baroud' } },
      { id: 'rosetta', name: { ar: 'رشيد', en: 'Rosetta (Rashid)' } }
    ]
  },
  {
    id: 'damietta',
    name: { ar: 'دمياط', en: 'Damietta' },
    cities: [
      { id: 'damietta-city', name: { ar: 'دمياط القديمة', en: 'Damietta City' } },
      { id: 'new-damietta', name: { ar: 'دمياط الجديدة', en: 'New Damietta' } },
      { id: 'ras-el-bar', name: { ar: 'رأس البر', en: 'Ras El Bar' } }
    ]
  },
  {
    id: 'port-said',
    name: { ar: 'بورسعيد', en: 'Port Said' },
    cities: [
      { id: 'port-said-city', name: { ar: 'حي الشرق والمناخ', en: 'Port Said City' } },
      { id: 'port-fouad', name: { ar: 'بورفؤاد', en: 'Port Fouad' } },
      { id: 'al-zohour', name: { ar: 'حي الزهور', en: 'Al Zohour' } }
    ]
  },
  {
    id: 'ismailia',
    name: { ar: 'الإسماعيلية', en: 'Ismailia' },
    cities: [
      { id: 'ismailia-city', name: { ar: 'مدينة الإسماعيلية', en: 'Ismailia City' } },
      { id: 'fayed', name: { ar: 'فايد', en: 'Fayed' } },
      { id: 'qantara', name: { ar: 'القنطرة', en: 'Al Qantara' } }
    ]
  },
  {
    id: 'suez',
    name: { ar: 'السويس', en: 'Suez' },
    cities: [
      { id: 'suez-city', name: { ar: 'مدينة السويس', en: 'Suez City' } },
      { id: 'arbaeen', name: { ar: 'حي الأربعين', en: 'Al Arbaeen' } },
      { id: 'ain-sokhna', name: { ar: 'العين السخنة', en: 'Ain Sokhna' } }
    ]
  },
  {
    id: 'kafr-el-sheikh',
    name: { ar: 'كفر الشيخ', en: 'Kafr El Sheikh' },
    cities: [
      { id: 'kafr-city', name: { ar: 'كفر الشيخ', en: 'Kafr El Sheikh City' } },
      { id: 'desouk', name: { ar: 'دسوق', en: 'Desouk' } },
      { id: 'balteem', name: { ar: 'بلطيم', en: 'Balteem' } }
    ]
  },
  {
    id: 'faiyum',
    name: { ar: 'الفيوم', en: 'Faiyum' },
    cities: [
      { id: 'faiyum-city', name: { ar: 'مدينة الفيوم', en: 'Faiyum City' } },
      { id: 'tamya', name: { ar: 'طامية', en: 'Tamya' } },
      { id: 'senouris', name: { ar: 'سنورس', en: 'Senouris' } }
    ]
  },
  {
    id: 'beni-suef',
    name: { ar: 'بني سويف', en: 'Beni Suef' },
    cities: [
      { id: 'beni-suef-city', name: { ar: 'بني سويف', en: 'Beni Suef City' } },
      { id: 'new-beni-suef', name: { ar: 'بني سويف الجديدة', en: 'New Beni Suef' } },
      { id: 'beba', name: { ar: 'ببا', en: 'Beba' } }
    ]
  },
  {
    id: 'minya',
    name: { ar: 'المنيا', en: 'Minya' },
    cities: [
      { id: 'minya-city', name: { ar: 'مدينة المنيا', en: 'Minya City' } },
      { id: 'new-minya', name: { ar: 'المنيا الجديدة', en: 'New Minya' } },
      { id: 'mallawi', name: { ar: 'ملوي', en: 'Mallawi' } },
      { id: 'samalut', name: { ar: 'سمالوط', en: 'Samalut' } }
    ]
  },
  {
    id: 'asyut',
    name: { ar: 'أسيوط', en: 'Asyut' },
    cities: [
      { id: 'asyut-city', name: { ar: 'مدينة أسيوط', en: 'Asyut City' } },
      { id: 'new-asyut', name: { ar: 'أسيوط الجديدة', en: 'New Asyut' } },
      { id: 'dairut', name: { ar: 'ديروط', en: 'Dairut' } }
    ]
  },
  {
    id: 'sohag',
    name: { ar: 'سوهاج', en: 'Sohag' },
    cities: [
      { id: 'sohag-city', name: { ar: 'مدينة سوهاج', en: 'Sohag City' } },
      { id: 'tahta', name: { ar: 'طهطا', en: 'Tahta' } },
      { id: 'girga', name: { ar: 'جرجا', en: 'Girga' } },
      { id: 'akhmeem', name: { ar: 'أخميم', en: 'Akhmeem' } }
    ]
  },
  {
    id: 'qena',
    name: { ar: 'قنا', en: 'Qena' },
    cities: [
      { id: 'qena-city', name: { ar: 'مدينة قنا', en: 'Qena City' } },
      { id: 'nag-hammadi', name: { ar: 'نجع حمادي', en: 'Nag Hammadi' } },
      { id: 'qous', name: { ar: 'قوص', en: 'Qous' } }
    ]
  },
  {
    id: 'luxor',
    name: { ar: 'الأقصر', en: 'Luxor' },
    cities: [
      { id: 'luxor-city', name: { ar: 'مدينة الأقصر', en: 'Luxor City' } },
      { id: 'esna', name: { ar: 'إسنا', en: 'Esna' } },
      { id: 'armant', name: { ar: 'أرمنت', en: 'Armant' } }
    ]
  },
  {
    id: 'aswan',
    name: { ar: 'أسوان', en: 'Aswan' },
    cities: [
      { id: 'aswan-city', name: { ar: 'مدينة أسوان', en: 'Aswan City' } },
      { id: 'kom-ombo', name: { ar: 'كوم أمبو', en: 'Kom Ombo' } },
      { id: 'edfu', name: { ar: 'إدفو', en: 'Edfu' } }
    ]
  },
  {
    id: 'red-sea',
    name: { ar: 'البحر الأحمر', en: 'Red Sea' },
    cities: [
      { id: 'hurghada', name: { ar: 'الغردقة', en: 'Hurghada' } },
      { id: 'el-gouna', name: { ar: 'الجونة', en: 'El Gouna' } },
      { id: 'safaga', name: { ar: 'سفاجا', en: 'Safaga' } },
      { id: 'marsa-alam', name: { ar: 'مرسى علم', en: 'Marsa Alam' } }
    ]
  },
  {
    id: 'south-sinai',
    name: { ar: 'جنوب سيناء', en: 'South Sinai' },
    cities: [
      { id: 'sharm', name: { ar: 'شرم الشيخ', en: 'Sharm El Sheikh' } },
      { id: 'dahab', name: { ar: 'دهب', en: 'Dahab' } },
      { id: 'nuweiba', name: { ar: 'نويبع', en: 'Nuweiba' } },
      { id: 'ras-sedr', name: { ar: 'رأس سدر', en: 'Ras Sedr' } }
    ]
  },
  {
    id: 'north-sinai',
    name: { ar: 'شمال سيناء', en: 'North Sinai' },
    cities: [
      { id: 'arish', name: { ar: 'العريش', en: 'Arish' } },
      { id: 'beer-abd', name: { ar: 'بئر العبد', en: 'Beer El Abd' } }
    ]
  },
  {
    id: 'matruh',
    name: { ar: 'مطروح والساحل الشمالي', en: 'Matruh & North Coast' },
    cities: [
      { id: 'marsa-matruh', name: { ar: 'مرسى مطروح', en: 'Marsa Matruh' } },
      { id: 'north-coast', name: { ar: 'الساحل الشمالي', en: 'North Coast (Sahel)' } },
      { id: 'new-alamein', name: { ar: 'العلمين الجديدة', en: 'New Alamein' } },
      { id: 'siwa', name: { ar: 'سيوة', en: 'Siwa' } }
    ]
  },
  {
    id: 'new-valley',
    name: { ar: 'الوادي الجديد', en: 'New Valley' },
    cities: [
      { id: 'kharga', name: { ar: 'الخارجة', en: 'Al Kharga' } },
      { id: 'dakhla', name: { ar: 'الداخلة', en: 'Al Dakhla' } }
    ]
  }
];

export const POPULAR_LOCATIONS = [
  { governorate: 'القاهرة', city: 'مدينة نصر' },
  { governorate: 'القاهرة', city: 'القاهرة الجديدة (التجمع)' },
  { governorate: 'القاهرة', city: 'المعادي' },
  { governorate: 'الجيزة', city: 'الدقي' },
  { governorate: 'الجيزة', city: 'الشيخ زايد' },
  { governorate: 'الجيزة', city: '6 أكتوبر' },
  { governorate: 'الإسكندرية', city: 'سموحة' },
  { governorate: 'الإسكندرية', city: 'ميامي' },
  { governorate: 'الدقهلية', city: 'المنصورة' }
];
