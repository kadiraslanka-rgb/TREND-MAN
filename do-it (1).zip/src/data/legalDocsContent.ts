import { Language, LegalDocumentType } from '../types';

export interface LegalSection {
  title: string;
  paragraphs: string[];
  listItems?: string[];
}

export interface LegalDocument {
  id: LegalDocumentType;
  title: string;
  subtitle: string;
  sections: LegalSection[];
}

export const LEGAL_DOCS_CONTENT: Record<Language, Record<LegalDocumentType, LegalDocument>> = {
  ar: {
    terms: {
      id: 'terms',
      title: 'شروط الخدمة والاستخدام',
      subtitle: 'جمهورية مصر العربية - اتفاقية مستخدمي دولاب مصر',
      sections: [
        {
          title: '1. طبيعة المنصة ودورها التقني',
          paragraphs: [
            'تعمل منصة "دولاب مصر" كسوق إلكتروني وسيط مستقل يهدف إلى تمكين الأفراد والمستخدمين داخل جمهورية مصر العربية من عرض وشراء السلع المستعملة والجديدة والتواصل المباشر فيما بينهم.',
            'لا تعتبر المنصة بائعاً أو مشترياً أو وكيلاً أو شريكاً تجارياً لأي من مستخدميها، ولا تتدخل في تحديد الأسعار أو فحص السلع على أرض الواقع إلا بالقدر المحدد صراحة في شروط الاستخدام.'
          ]
        },
        {
          title: '2. أهلية الاستخدام والتسجيل',
          paragraphs: [
            'يجب ألا يقل عمر المستخدم عن 18 عاماً قانونياً، أو أن يتم استخدام المنصة بموافقة وإشراف مباشر من الولي الطبيعي وفقاً لأحكام القانون المدني المصري.',
            'يلتزم المستخدم بتقديم بيانات تسجيل صحيحة ودقيقة (الاسم، البريد الإلكتروني، المحافظة، والمدينة) والامتناع عن انتحال شخصية أي فرد أو جهة أخرى.'
          ]
        },
        {
          title: '3. مسؤوليات البائع القانونية والمدنية',
          paragraphs: [
            'يتحمل كل بائع المسؤولية القانونية الكاملة عن صحة إعلانه، وملكيته القانونية للمنتج، وأصالته، وخلوه من أي موانع قانونية أو تزوير، ومطابقته التامة للوصف المعلن.',
            'يقر البائع صراحة بملكيته الخالصة للسلعة أو حيازته القانونية المصرح بها للبيع، ويتحمل أي مسؤولية مدنية أو جنائية تنشأ عن مخالفة ذلك دون أدنى مسؤولية على المنصة.'
          ]
        },
        {
          title: '4. الامتثال للتشريعات المصرية وحماية المستهلك',
          paragraphs: [
            'تخضع المعاملات لأحكام قانون حماية المستهلك المصري رقم 181 لسنة 2018، وقانون مكافحة جرائم تقنية المعلومات رقم 175 لسنة 2018.',
            'لا تتنصل المنصة من أي مسؤوليات أو التزامات قانونية لا يجوز التنازل عنها بموجب التشريعات السارية في جمهورية مصر العربية.'
          ]
        },
        {
          title: '5. الاختصاص القضائي وفض المنازعات',
          paragraphs: [
            'تخضع هذه الشروط وتفسر وفقاً للقوانين السارية في جمهورية مصر العربية، وتختص المحاكم المصرية بالفصل في أي نزاع ينشأ عن استخدام المنصة.'
          ]
        }
      ]
    },
    privacy: {
      id: 'privacy',
      title: 'سياسة الخصوصية وحماية البيانات',
      subtitle: 'وفقاً لقانون حماية البيانات الشخصية المصري رقم 151 لسنة 2020',
      sections: [
        {
          title: '1. البيانات التي نجمعها',
          paragraphs: [
            'نجمع البيانات الضرورية لتقديم الخدمة: الاسم الكامل، عنوان البريد الإلكتروني، رقم الهاتف، المحافظة والمدينة، والبيانات والصور المرفوعة في الإعلانات.',
            'يتم تشفير كلمات المرور باستخدام تجزئة SHA-256 مشددة ولا يمكن لأي موظف الاطلاع على كلمات المرور الأصلية.'
          ]
        },
        {
          title: '2. أغراض استخدام البيانات',
          paragraphs: [
            'تُستخدم البيانات فقط لتمكين التواصل بين البائعين والمشترين، وتحسين تجربة البحث، ومكافحة الاحتيال والجرائم الإلكترونية، والرد على استفسارات الدعم الفني.',
            'لا نقوم ببيع أو تأجير بيانات المستخدمين الشخصية لأي طرف ثالث لأغراض التسويق.'
          ]
        },
        {
          title: '3. حق المستخدم في حذف الحساب والبيانات',
          paragraphs: [
            'يحق للمستخدم في أي وقت طلب حذف حسابه نهائياً عبر زر "حذف الحساب" المتاح في إعدادات التطبيق، حيث يتم مسح كافة إعلاناته ورسائله وسجلاته نهائياً من خوادم المنصة.'
          ]
        }
      ]
    },
    marketplace_rules: {
      id: 'marketplace_rules',
      title: 'قواعد السوق والمعاملات',
      subtitle: 'إرشادات النزاهة والتعامل العادل بين البائعين والمشترين',
      sections: [
        {
          title: '1. الشفافية والمصداقية في الإعلان',
          paragraphs: [
            'يجب أن يحدد الإعلان السعر الحقيقي المطلوب بالجنيه المصري، وحالة السلعة بدقة، مع صور فعلية وحقيقية للسلعة المعروضة وليست صوراً مأخوذة من الإنترنت.'
          ]
        },
        {
          title: '2. حظر التكرار والإعلانات المضللة',
          paragraphs: [
            'يُمنع منعاً باتاً نشر إعلانات مكررة لنفس السلعة، أو استخدام كلمات مفتاحية مضللة لا تمت بصلة للسلعة المعروضة.'
          ]
        },
        {
          title: '3. المعاينة المباشرة قبل إتمام الدفع',
          paragraphs: [
            'القاعدة الأساسية في المنصة هي حق المشتري الكامل في فحص السلعة واختبارها بدقة قبل إتمام الدفع سواء في المقابلة الشخصية أو عند الاستلام من مندوب الشحن.'
          ]
        }
      ]
    },
    prohibited_items: {
      id: 'prohibited_items',
      title: 'سياسة السلع المحظورة تماماً',
      subtitle: 'قائمة المواد والسلع الممنوع عرضها أو تداولها في دولاب مصر',
      sections: [
        {
          title: 'حظر بيع الأغذية والمشروبات والأدوية',
          paragraphs: [
            'يُحظر تماماً بيع الأطعمة والمشروبات والمكملات الغذائية للأكل، كما يُحظر بيع كافة أنواع الأدوية والعقاقير الطبية الموصوفة وغير الموصوفة والمستلزمات الطبية.'
          ],
          listItems: [
            'الأطعمة والمشروبات الطازجة والمطبوخة والمعلبة.',
            'الأدوية والعقاقير والمستحضرات الصيدلانية بجميع أشكالها.',
            'المكملات الغذائية والمنتجات الصحية غير المصرح بها.',
            'المواد المخدرة والمهدئة والمسكرات والمواد الخاضعة للرقابة.',
            'الأسلحة النارية والذخائر والأسلحة البيضاء المحظورة ومعدات الصعق.',
            'المواد الكيميائية السامة والمتفجرات والألعاب النارية.',
            'الأعضاء والأنسجة وسوائل الجسم البشري.',
            'السلع المسروقة والسلع المقلدة والماركات المزيفة.',
            'أي سلعة أو نشاط يخالف القوانين السارية في جمهورية مصر العربية.'
          ]
        }
      ]
    },
    buyer_safety: {
      id: 'buyer_safety',
      title: 'دليل أمان المشتري',
      subtitle: 'نصائح المعاينة والمقابلة والشراء الآمن في مصر',
      sections: [
        {
          title: '1. اختيار مكان المقابلة',
          paragraphs: [
            'حدد دائماً مكان المقابلة في موقع عام ومأهول ومضاء في وضح النهار (مثل المولات التجارية، محطات المترو، أو المقاهي المعروفة). لا تذهب لمناطق منعزلة أو بيوت أشخاص مجهولين.'
          ]
        },
        {
          title: '2. فحص السلعة واختبارها',
          paragraphs: [
            'افحص السلعة بدقة قبل الدفع. في الأجهزة الإلكترونية والهواتف، تأكد من تجربة الشحن، الشاشة، الكاميرا، وقم بإزالة وتسجيل الخروج من أي حسابات سابقة (iCloud / Google).'
          ]
        },
        {
          title: '3. طرق الدفع الآمنة',
          paragraphs: [
            'لا تقم أبداً بتحويل أي مبالغ مقدمة أو عربون مسبق قبل رؤية السلعة والتأكد منها يداً بيد. الدفع كاش أو عبر التحويل اللحظي InstaPay أثناء الاستلام هو الخيار الأكثر أماناً.'
          ]
        }
      ]
    },
    seller_rules: {
      id: 'seller_rules',
      title: 'قواعد والتزامات البائع',
      subtitle: 'واجبات البائع القانونية لضمان معاملة نزيهة وموثوقة',
      sections: [
        {
          title: '1. إقرار الملكية والأصالة',
          paragraphs: [
            'يقر البائع بأنه المالك الحقيقي للسلعة وله كامل الحق القانوني في بيعها، وأن السلعة أصلية وغير مقلدة وخالية من أي حظر أو نزاع قانوني.'
          ]
        },
        {
          title: '2. الإفصاح الصريح عن العيوب',
          paragraphs: [
            'يلتزم البائع بالإفصاح الكامل والصادق عن أي عيب أو خدش أو عطل في السلعة ضمن قسم "عيوب المنتج"، وإرفاق صور واضحة توضح العيب بدقة للمشتري.'
          ]
        },
        {
          title: '3. السعر النهائي وتكلفة الشحن التقديرية',
          paragraphs: [
            'يجب أن يكون السعر المطلوب واضحاً، وتعتبر أي تكلفة شحن مذكورة تكلفة تقديرية وليست سعراً مضموناً نهائياً إلا بعد الاتفاق مع شركة الشحن.'
          ]
        }
      ]
    },
    shipping_rules: {
      id: 'shipping_rules',
      title: 'قواعد الشحن والتوصيل',
      subtitle: 'تنظيم عمليات الشحن بين المحافظات المصرية',
      sections: [
        {
          title: '1. طبيعة تكلفة الشحن التقديرية',
          paragraphs: [
            'تكلفة الشحن المعروضة في الإعلانات هي تكلفة تقديرية مبدئية يقدرها البائع ولا تمثل سعراً نهائياً ملزماً. يتم تأكيد السعر النهائي مع شركة الشحن المعتمدة.'
          ]
        },
        {
          title: '2. فحص الشحنة عند الاستلام',
          paragraphs: [
            'يحق للمشتري التحقق من محتويات الشحنة قبل إتمام الاستلام وفقاً لسياسات شركة الشحن المتفق عليها لضمان مطابقة المنتج للوصف.'
          ]
        }
      ]
    },
    refund_dispute: {
      id: 'refund_dispute',
      title: 'سياسة النزاعات والاسترجاع',
      subtitle: 'إجراءات حل الخلافات والنزاعات بين المتعاملين',
      sections: [
        {
          title: '1. معاملات السلع المستعملة الفردية',
          paragraphs: [
            'نظراً لأن السلع مستعملة وتُباع من أفراد مستقلين، فإن المعاينة الشخصية قبل إتمام الدفع هي الضمانة الأساسية، ولا يسري حق الاسترجاع التلقائي ما لم يتفق الطرفان صراحة على ذلك.'
          ]
        },
        {
          title: '2. حالات الغش والتدليس القانوني',
          paragraphs: [
            'في حال ثبوت إخفاء البائع لعيب جسيم متعمداً أو تسليم سلعة مقلدة أو مسروقة، يحق للمشتري الرجوع القانوني الكامل على البائع بموجب أحكام القانون المدني وقانون حماية المستهلك المصري.'
          ]
        }
      ]
    },
    community_guidelines: {
      id: 'community_guidelines',
      title: 'إرشادات المجتمع والاحترام',
      subtitle: 'معايير السلوك والتواصل بين أعضاء دولاب مصر',
      sections: [
        {
          title: '1. اللباقة والاحترام المتبادل',
          paragraphs: [
            'يلتزم جميع المستخدمين بالاحترام الكامل في المحادثات والتعليقات والامتناع التام عن أي ألفاظ غير لائقة أو تمييز أو مضايقة.'
          ]
        },
        {
          title: '2. الالتزام بالمواعيد والجدية',
          paragraphs: [
            'احرص على تقديم عروض أسعار جدية والالتزام بالمواعيد المتفق عليها للمقابلة احترماً لوقت الطرف الآخر وللحفاظ على سمعتك في المنصة.'
          ]
        }
      ]
    }
  },

  en: {
    terms: {
      id: 'terms',
      title: 'Terms of Service',
      subtitle: 'Arab Republic of Egypt - Doolab Masr User Agreement',
      sections: [
        {
          title: '1. Nature of the Platform',
          paragraphs: [
            'Doolab Masr operates as an independent technical marketplace platform connecting buyers and sellers across Egypt to list and trade second-hand and new goods directly.',
            'The platform is not a party to direct sales agreements between users and does not act as an agent, broker, or guarantor of transactions.'
          ]
        },
        {
          title: '2. User Eligibility and Registration',
          paragraphs: [
            'Users must be at least 18 years of age or act under parental/guardian supervision pursuant to the Egyptian Civil Code.',
            'Users must register using accurate credentials (name, email, governorate, and city) and refrain from impersonating any person or entity.'
          ]
        },
        {
          title: '3. Legal Responsibility of the Seller',
          paragraphs: [
            'Sellers bear full legal responsibility for ownership, authenticity, condition, defects, description, and statutory legality of their listings.',
            'Sellers represent and warrant that they possess legal title to listed items free of third-party encumbrances.'
          ]
        },
        {
          title: '4. Statutory Egyptian Compliance & Consumer Protection',
          paragraphs: [
            'Transactions are subject to Egyptian Consumer Protection Law No. 181/2018 and Cybercrime Law No. 175/2018.',
            'The platform does not waive any statutory obligations that cannot be lawfully waived under Egyptian legislation.'
          ]
        },
        {
          title: '5. Governing Law and Jurisdiction',
          paragraphs: [
            'These terms are governed by and construed in accordance with the laws of the Arab Republic of Egypt, and Egyptian courts possess exclusive jurisdiction.'
          ]
        }
      ]
    },
    privacy: {
      id: 'privacy',
      title: 'Privacy Policy',
      subtitle: 'Compliant with Egyptian Personal Data Protection Law No. 151/2020',
      sections: [
        {
          title: '1. Data We Collect',
          paragraphs: [
            'We collect data strictly required to operate the service: full name, email address, phone number, governorate and city, and listing images.',
            'Passwords are encrypted with salted SHA-256 hashing and cannot be viewed in plain text.'
          ]
        },
        {
          title: '2. Purpose of Processing',
          paragraphs: [
            'Data is processed solely to enable communication between buyers and sellers, prevent cyber fraud, and provide customer support.',
            'We never sell or rent user personal data to third parties for marketing purposes.'
          ]
        },
        {
          title: '3. Right to Account Deletion',
          paragraphs: [
            'Users may permanently delete their account and all associated data at any time via the "Delete Account" button in account settings.'
          ]
        }
      ]
    },
    marketplace_rules: {
      id: 'marketplace_rules',
      title: 'Marketplace Rules',
      subtitle: 'Integrity and Fair Trading Standards',
      sections: [
        {
          title: '1. Transparency in Listings',
          paragraphs: [
            'Listings must state the real asking price in Egyptian Pounds, accurate condition, and genuine photos of the actual product.'
          ]
        },
        {
          title: '2. Duplicate and Misleading Listings Prohibited',
          paragraphs: [
            'Spamming identical listings across multiple categories or using unrelated keywords is strictly prohibited.'
          ]
        },
        {
          title: '3. Right to In-Person Inspection',
          paragraphs: [
            'Buyers have the full right to test and inspect items thoroughly before paying, whether meeting in person or inspecting upon delivery.'
          ]
        }
      ]
    },
    prohibited_items: {
      id: 'prohibited_items',
      title: 'Prohibited Items Policy',
      subtitle: 'Items and categories strictly prohibited from sale on Doolab Masr',
      sections: [
        {
          title: 'Complete Prohibition on Food, Drugs, and Dangerous Goods',
          paragraphs: [
            'The sale of food, beverages, prescription/non-prescription drugs, medical supplies, weapons, and counterfeit products is strictly prohibited.'
          ],
          listItems: [
            'Food and beverages of any kind (prepared, packaged, or raw).',
            'Prescription drugs, non-prescription drugs, and pharmaceutical medicines.',
            'Dietary supplements intended for ingestion.',
            'Narcotics, controlled substances, and intoxicants.',
            'Firearms, ammunition, illegal bladed weapons, and stun devices.',
            'Toxic chemicals, explosives, and fireworks.',
            'Human organs, blood, and body fluids.',
            'Stolen property, counterfeit items, and forged documents.',
            'Any product or service prohibited by applicable Egyptian laws.'
          ]
        }
      ]
    },
    buyer_safety: {
      id: 'buyer_safety',
      title: 'Buyer Safety Guide',
      subtitle: 'Guidelines for safe meetups and transactions in Egypt',
      sections: [
        {
          title: '1. Meet in Public Daytime Locations',
          paragraphs: [
            'Always arrange to meet in well-lit, busy public areas during daytime (e.g. shopping malls, metro stations, or popular cafes). Never meet in secluded places.'
          ]
        },
        {
          title: '2. Inspect and Test the Item',
          paragraphs: [
            'Thoroughly test electronics, cameras, and phones. Verify battery health, charging ports, cameras, and ensure the seller logs out of all iCloud/Google accounts.'
          ]
        },
        {
          title: '3. Safe Payment Methods',
          paragraphs: [
            'Never send advance payments or deposits before seeing and inspecting the item in person. Pay cash or transfer via InstaPay during the handover.'
          ]
        }
      ]
    },
    seller_rules: {
      id: 'seller_rules',
      title: 'Seller Rules & Obligations',
      subtitle: 'Legal duties of sellers on Doolab Masr',
      sections: [
        {
          title: '1. Proof of Ownership and Authenticity',
          paragraphs: [
            'Sellers affirm that they own the listed item, that it is authentic, and that it is legally authorized for sale without third-party claims.'
          ]
        },
        {
          title: '2. Mandatory Defect Disclosure',
          paragraphs: [
            'Sellers must honestly disclose any defects, damage, or repairs in the "Product Defect" section and attach clear photos showing the defect.'
          ]
        },
        {
          title: '3. Pricing and Estimated Shipping',
          paragraphs: [
            'The price must be clear. Any shipping cost entered is an estimate and not a guaranteed final price until confirmed with the courier.'
          ]
        }
      ]
    },
    shipping_rules: {
      id: 'shipping_rules',
      title: 'Shipping & Delivery Rules',
      subtitle: 'Governing parcel deliveries across Egyptian governorates',
      sections: [
        {
          title: '1. Nature of Estimated Shipping Cost',
          paragraphs: [
            'Estimated shipping costs in listings are optional approximations and do not constitute a guaranteed final price.'
          ]
        },
        {
          title: '2. Inspection Upon Delivery',
          paragraphs: [
            'Buyers have the right to verify parcel contents upon handover in accordance with courier company policies.'
          ]
        }
      ]
    },
    refund_dispute: {
      id: 'refund_dispute',
      title: 'Refund & Dispute Information',
      subtitle: 'Resolving disputes between individual users',
      sections: [
        {
          title: '1. Second-Hand Individual Transactions',
          paragraphs: [
            'Because listings are private sales between individuals, in-person inspection prior to payment is the primary guarantee.'
          ]
        },
        {
          title: '2. Remediation for Fraud or Hidden Defects',
          paragraphs: [
            'If a seller intentionally conceals a material defect or delivers counterfeit or stolen goods, the buyer retains full legal recourse under the Egyptian Civil Code and Consumer Protection Law.'
          ]
        }
      ]
    },
    community_guidelines: {
      id: 'community_guidelines',
      title: 'Community Guidelines',
      subtitle: 'Mutual respect and communication standards',
      sections: [
        {
          title: '1. Polite Communication',
          paragraphs: [
            'All users must maintain courtesy and mutual respect in chats and calls, refraining from abusive language or harassment.'
          ]
        },
        {
          title: '2. Punctuality and Serious Offers',
          paragraphs: [
            'Make serious offers and honor agreed appointment times to respect the other party’s time and maintain high credibility.'
          ]
        }
      ]
    }
  },

  tr: {
    terms: {
      id: 'terms',
      title: 'Kullanım Koşulları',
      subtitle: 'Mısır Arap Cumhuriyeti - Doolab Masr Kullanıcı Sözleşmesi',
      sections: [
        {
          title: '1. Platformun Rolü ve Niteliği',
          paragraphs: [
            'Doolab Masr, Mısır genelinde alıcı ve satıcıları doğrudan buluşturan bağımsız bir pazar yeri platformudur.',
            'Platform kullanıcılar arasındaki alım-satım sözleşmelerinin tarafı değildir; aracı, komisyoncu veya garantör sıfatı taşımaz.'
          ]
        },
        {
          title: '2. Kullanıcı Uygunluğu ve Kayıt',
          paragraphs: [
            'Kullanıcılar 18 yaşını doldurmuş olmalıdır. Kayıt sırasında doğru ve eksiksiz bilgiler verilmelidir.'
          ]
        },
        {
          title: '3. Satıcının Yasal Sorumluluğu',
          paragraphs: [
            'Satıcılar ilanlarının doğruluğu, ürünün mülkiyeti, orijinalliği, durumu, kusurları, açıklaması ve yasalara uygunluğu konusunda tek yetkili ve yasal sorumludur.'
          ]
        },
        {
          title: '4. Mısır Tüketici Hakları Uyumluluğu',
          paragraphs: [
            'İşlemler 181/2018 sayılı Mısır Tüketiciyi Koruma Kanunu hükümlerine tabidir. Kanunen feragat edilemeyecek yasal haklar saklıdır.'
          ]
        },
        {
          title: '5. Uygulanacak Hukuk ve Yetkili Mahkeme',
          paragraphs: [
            'Bu sözleşme Mısır kanunlarına tabidir ve uyuşmazlıklarda Mısır mahkemeleri münhasır yetkilidir.'
          ]
        }
      ]
    },
    privacy: {
      id: 'privacy',
      title: 'Gizlilik Politikası',
      subtitle: '151/2020 Sayılı Mısır Kişisel Verileri Koruma Kanununa Uygun',
      sections: [
        {
          title: '1. Toplanan Veriler',
          paragraphs: [
            'Hizmet için gerekli veriler toplanır: ad soyad, e-posta, telefon, şehir ve ilan fotoğrafları.',
            'Şifreler SHA-256 ile şifrelenir ve asla açık metin olarak saklanmaz.'
          ]
        },
        {
          title: '2. Veri Kullanım Amacı',
          paragraphs: [
            'Veriler alıcı ve satıcı arasındaki iletişimi sağlamak ve güvenliği temin etmek amacıyla kullanılır. Üçüncü taraflara satılmaz.'
          ]
        },
        {
          title: '3. Hesabı ve Verileri Silme Hakkı',
          paragraphs: [
            'Kullanıcılar diledikleri zaman hesap ayarlarından "Hesabı Sil" seçeneği ile hesaplarını ve verilerini kalıcı olarak silebilirler.'
          ]
        }
      ]
    },
    marketplace_rules: {
      id: 'marketplace_rules',
      title: 'Pazar Yeri Kuralları',
      subtitle: 'Dürüst ve Güvenli Alışveriş Standartları',
      sections: [
        {
          title: '1. İlanlarda Şeffaflık',
          paragraphs: [
            'İlanlarda gerçek fiyat, doğru durum ve ürüne ait gerçek fotoğraflar kullanılmalıdır.'
          ]
        },
        {
          title: '2. Mükerrer İlan Yasağı',
          paragraphs: [
            'Aynı ürünün birden fazla kez listelenmesi veya yanıltıcı etiketler kullanılması yasaktır.'
          ]
        },
        {
          title: '3. Elden İnceleme Hakkı',
          paragraphs: [
            'Alıcı, ödeme yapmadan önce ürünü detaylıca inceleme ve deneme hakkına sahiptir.'
          ]
        }
      ]
    },
    prohibited_items: {
      id: 'prohibited_items',
      title: 'Yasaklı Ürünler Politikası',
      subtitle: 'Doolab Masr üzerinde satışı kesinlikle yasak olan ürünler',
      sections: [
        {
          title: 'Gıda, İlaç ve Tehlikeli Maddelerin Kesin Yasağı',
          paragraphs: [
            'Gıda ürünleri, içecekler, reçeteli/reçetesiz ilaçlar, tıbbi malzemeler ve sahte ürünlerin satışı kesinlikle yasaktır.'
          ],
          listItems: [
            'Her türlü gıda, yemek ve içecek ürünleri.',
            'Reçeteli veya reçetesiz tüm ilaçlar ve tıbbi malzemeler.',
            'Gıda takviyeleri ve ruhsatsız sağlık ürünleri.',
            'Uyuşturucu, uyarıcı ve alkollü maddeler.',
            'Ateşli silahlar, mühimmat ve yasaklı kesici aletler.',
            'Zehirli kimyasallar, patlayıcılar ve havai fişekler.',
            'İnsan organları, kan ve vücut sıvıları.',
            'Çalıntı mallar ve sahte marka/taklit ürünler.',
            'Mısır yasalarınca yasaklanmış tüm ürün ve hizmetler.'
          ]
        }
      ]
    },
    buyer_safety: {
      id: 'buyer_safety',
      title: 'Güvenlik Rehberi',
      subtitle: 'Mısır’da güvenli buluşma ve alışveriş tavsiyeleri',
      sections: [
        {
          title: '1. Gündüz ve Kalabalık Yerlerde Buluşun',
          paragraphs: [
            'Buluşmalarınızı her zaman gündüz saatlerinde AVM, metro istasyonu gibi kalabalık kamuya açık alanlarda gerçekleştirin.'
          ]
        },
        {
          title: '2. Ürünü Detaylıca Test Edin',
          paragraphs: [
            'Özellikle telefon ve elektroniklerde şarj, kamera ve ekranı deneyin, iCloud ve Google hesaplarından çıkış yapıldığından emin olun.'
          ]
        },
        {
          title: '3. Güvenli Ödeme',
          paragraphs: [
            'Ürünü görüp teslim almadan asla ön ödeme veya kapora göndermeyin. Elden nakit veya InstaPay ile teslim anında ödeme yapın.'
          ]
        }
      ]
    },
    seller_rules: {
      id: 'seller_rules',
      title: 'Satıcı Kuralları ve Yükümlülükleri',
      subtitle: 'Dürüst ticaret için satıcı sorumlulukları',
      sections: [
        {
          title: '1. Mülkiyet ve Orijinallik Taahhüdü',
          paragraphs: [
            'Satıcı, ürünün gerçek sahibi olduğunu, ürünün orijinal ve yasal olduğunu taahhüt eder.'
          ]
        },
        {
          title: '2. Kusurların Açıkça Belirtilmesi',
          paragraphs: [
            'Üründeki her türlü kusur "Ürün Kusuru" bölümünde açıklanmalı ve kusur fotoğrafı eklenmelidir.'
          ]
        },
        {
          title: '3. Fiyatlandırma ve Tahmini Kargo',
          paragraphs: [
            'Kargo ücreti bilgisi isteğe bağlı ve tahminidir; kargo şirketiyle kesinleşene kadar bağlayıcı değildir.'
          ]
        }
      ]
    },
    shipping_rules: {
      id: 'shipping_rules',
      title: 'Kargo ve Teslimat Kuralları',
      subtitle: 'Mısır vilayetleri arası kargo süreçleri',
      sections: [
        {
          title: '1. Tahmini Kargo Ücretinin Niteliği',
          paragraphs: [
            'İlanda belirtilen kargo ücreti tahmini olup kesinleşmiş nihai fiyat değildir.'
          ]
        },
        {
          title: '2. Teslimatta Kontrol',
          paragraphs: [
            'Alıcı kargoyu teslim alırken paketi ve ürünün durumunu kontrol etme hakkına sahiptir.'
          ]
        }
      ]
    },
    refund_dispute: {
      id: 'refund_dispute',
      title: 'İade ve Uyuşmazlık Çözümü',
      subtitle: 'Kullanıcılar arası anlaşmazlıkların giderilmesi',
      sections: [
        {
          title: '1. İkinci El Şahıs Satışları',
          paragraphs: [
            'Ürünler şahıslar arası ikinci el satış olduğundan teslim alma anındaki kontrol esastır.'
          ]
        },
        {
          title: '2. Hile ve Ayıplı Mal Durumları',
          paragraphs: [
            'Kusurun kasten gizlenmesi veya sahte ürün verilmesi durumunda alıcının Mısır kanunları çerçevesinde yasal başvuru hakkı saklıdır.'
          ]
        }
      ]
    },
    community_guidelines: {
      id: 'community_guidelines',
      title: 'Topluluk Kuralları',
      subtitle: 'Karşılıklı saygı ve nezaket ilkeleri',
      sections: [
        {
          title: '1. Saygılı İletişim',
          paragraphs: [
            'Tüm kullanıcılar mesajlaşma ve aramalarda saygılı ve nazik bir dil kullanmalıdır.'
          ]
        },
        {
          title: '2. Randevulara Sadakat',
          paragraphs: [
            'Verilen tekliflere ve belirlenen buluşma saatlerine özen göstermek güvenilirlik açısından zorunludur.'
          ]
        }
      ]
    }
  }
};
