package com.trendscanner.bybit;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
