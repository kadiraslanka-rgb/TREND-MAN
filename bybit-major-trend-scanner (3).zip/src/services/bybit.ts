import { BybitTicker, KlineCandle, SymbolInfo, Timeframe } from '../types/scanner';

// Bybit API endpoints
const PRIMARY_BYBIT_API = 'https://api.bybit.com';
const BACKUP_BYBIT_PROXY = '/bybit-api';

// Map timeframes to Bybit interval parameters
export const TIMEFRAME_MAP: Record<Timeframe, string> = {
  '4H': '240',
  '6H': '360',
  '1D': 'D',
  '3D': '3D',
  '1W': 'W',
  '1M': 'M',
};

// Calculate approximate bar duration in seconds
export const TIMEFRAME_SECONDS: Record<Timeframe, number> = {
  '4H': 4 * 3600,
  '6H': 6 * 3600,
  '1D': 24 * 3600,
  '3D': 3 * 24 * 3600,
  '1W': 7 * 24 * 3600,
  '1M': 30 * 24 * 3600,
};

let preferredBaseUrl = PRIMARY_BYBIT_API;

/**
 * Universal fetch with automatic failover between direct Bybit and proxy
 */
async function fetchBybit<T>(path: string): Promise<T> {
  const tryFetch = async (baseUrl: string) => {
    const res = await fetch(`${baseUrl}${path}`, {
      headers: {
        'Accept': 'application/json',
      },
    });
    if (!res.ok) {
      throw new Error(`Bybit HTTP error: ${res.status}`);
    }
    return res.json();
  };

  try {
    const data = await tryFetch(preferredBaseUrl);
    return data as T;
  } catch {
    // If primary failed, try the fallback
    const altBase = preferredBaseUrl === PRIMARY_BYBIT_API ? BACKUP_BYBIT_PROXY : PRIMARY_BYBIT_API;
    try {
      const data = await tryFetch(altBase);
      preferredBaseUrl = altBase; // switch to working URL
      return data as T;
    } catch (err2) {
      throw new Error(`Failed to fetch from Bybit: ${err2 instanceof Error ? err2.message : String(err2)}`);
    }
  }
}

/**
 * Fetch all active USDT Linear Perpetual symbols and their 24h ticker metrics
 */
export async function fetchAllActiveUsdtPerpetuals(): Promise<SymbolInfo[]> {
  try {
    // 1. Fetch all linear tickers in a single call to get prices, 24h changes and volume
    const tickersRes = await fetchBybit<{
      retCode: number;
      result: { list: BybitTicker[] };
    }>('/v5/market/tickers?category=linear');

    const tickerMap = new Map<string, BybitTicker>();
    if (tickersRes?.result?.list) {
      for (const t of tickersRes.result.list) {
        if (t.symbol.endsWith('USDT')) {
          tickerMap.set(t.symbol, t);
        }
      }
    }

    // 2. Fetch instruments to confirm trading status and details
    const instrumentsRes = await fetchBybit<{
      retCode: number;
      result: { list: Array<{ symbol: string; status: string; baseCoin: string }> };
    }>('/v5/market/instruments-info?category=linear&status=Trading&limit=1000');

    const symbols: SymbolInfo[] = [];

    if (instrumentsRes?.result?.list) {
      for (const inst of instrumentsRes.result.list) {
        if (inst.symbol.endsWith('USDT') && inst.status === 'Trading') {
          const ticker = tickerMap.get(inst.symbol);
          const lastPrice = ticker ? parseFloat(ticker.lastPrice) || 0 : 0;
          const change24h = ticker ? (parseFloat(ticker.price24hPcnt) || 0) * 100 : 0;
          const volume24hUsd = ticker ? parseFloat(ticker.turnover24h) || 0 : 0;

          symbols.push({
            symbol: inst.symbol,
            baseCoin: inst.baseCoin || inst.symbol.replace('USDT', ''),
            lastPrice,
            change24h,
            volume24hUsd,
          });
        }
      }
    } else {
      // Fallback to tickers directly if instruments returned empty
      for (const [symbol, ticker] of tickerMap.entries()) {
        symbols.push({
          symbol,
          baseCoin: symbol.replace('USDT', ''),
          lastPrice: parseFloat(ticker.lastPrice) || 0,
          change24h: (parseFloat(ticker.price24hPcnt) || 0) * 100,
          volume24hUsd: parseFloat(ticker.turnover24h) || 0,
        });
      }
    }

    // Sort symbols by 24h volume descending by default
    symbols.sort((a, b) => b.volume24hUsd - a.volume24hUsd);
    return symbols;
  } catch (err) {
    console.error('Error fetching Bybit USDT perpetuals:', err);
    throw err;
  }
}

/**
 * Fetch kline candlestick history for a symbol and timeframe
 * Max limit is 200 candles in Bybit v5
 */
export async function fetchKlines(
  symbol: string,
  timeframe: Timeframe,
  limit: number = 200
): Promise<KlineCandle[]> {
  const interval = TIMEFRAME_MAP[timeframe];
  const url = `/v5/market/kline?category=linear&symbol=${symbol}&interval=${interval}&limit=${limit}`;

  const res = await fetchBybit<{
    retCode: number;
    retMsg: string;
    result: {
      symbol: string;
      category: string;
      list: string[][]; // [startTime, openPrice, highPrice, lowPrice, closePrice, volume, turnover]
    };
  }>(url);

  if (!res?.result?.list || res.result.list.length === 0) {
    return [];
  }

  // Bybit returns newest candles first; reverse to get chronological order (oldest to newest)
  const list = res.result.list.slice().reverse();

  return list.map((item) => {
    const rawTime = parseInt(item[0], 10);
    return {
      time: Math.floor(rawTime / 1000), // seconds
      rawTime,
      open: parseFloat(item[1]),
      high: parseFloat(item[2]),
      low: parseFloat(item[3]),
      close: parseFloat(item[4]),
      volume: parseFloat(item[5]),
    };
  });
}

/**
 * Rate-limited concurrent executor to scan multiple symbols cleanly without 429
 */
export async function runWithConcurrency<T, R>(
  items: T[],
  workerFn: (item: T, index: number) => Promise<R>,
  concurrency: number = 10,
  onProgress?: (completed: number, total: number, lastResult: R | null) => void,
  shouldStop?: () => boolean
): Promise<R[]> {
  const results: R[] = [];
  let currentIndex = 0;
  let completedCount = 0;

  const total = items.length;

  const worker = async () => {
    while (currentIndex < total) {
      if (shouldStop && shouldStop()) {
        break;
      }
      const index = currentIndex++;
      const item = items[index];

      try {
        const res = await workerFn(item, index);
        results.push(res);
        completedCount++;
        if (onProgress) {
          onProgress(completedCount, total, res);
        }
      } catch (err) {
        completedCount++;
        if (onProgress) {
          onProgress(completedCount, total, null);
        }
      }

      // Small jitter delay between requests in each worker thread to smooth out API calls
      await new Promise((resolve) => setTimeout(resolve, 35));
    }
  };

  const pool = Array.from({ length: Math.min(concurrency, items.length) }, () => worker());
  await Promise.all(pool);

  return results;
}
