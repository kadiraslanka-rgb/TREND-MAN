import { Language } from '../types';

export interface FilterResult {
  hasViolation: boolean;
  reason?: string;
  matchedText?: string;
}

export const CONTACT_WARNINGS: Record<Language, string> = {
  tr: "İletişim güvenlik nedeniyle yalnızca uygulama içinden yapılabilir.",
  en: "For security reasons, communication can only be conducted inside the app.",
  ar: "لأسباب تتعلق بالأمان، يجب أن يتم التواصل داخل التطبيق فقط.",
};

export const CONTACT_WARNING_DETAILS: Record<Language, string> = {
  tr: "Telefon numarası, WhatsApp, e-posta veya sosyal medya gibi harici iletişim bilgileri paylaşmak kurallarımıza aykırıdır. Alıcı ve satıcı güvenliği için tüm görüşmeler LUQTA üzerinden yürütülmelidir.",
  en: "Sharing external contact details such as phone numbers, WhatsApp, emails or social media is prohibited. To protect buyers and sellers, all chats must stay inside LUQTA.",
  ar: "يُحظر مشاركة أرقام الهواتف أو واتساب أو البريد الإلكتروني أو حسابات التواصل الاجتماعي. لحماية المشترين والبائعين، يجب أن تتم جميع المحادثات والمعاملات داخل لقطة.",
};

/**
 * Validates text against external contact sharing rules.
 * Blocks:
 * - Egyptian phone numbers (010..., 011..., 012..., 015...)
 * - International numbers (+20..., +90..., etc.)
 * - Numbers with spaces, dashes, dots
 * - WhatsApp / واتساب keywords and links
 * - Telegram / تلجرام keywords and links
 * - Email addresses
 * - Instagram handles or phrases redirecting outside the app
 */
export function validateContactInfo(input: string): FilterResult {
  if (!input || !input.trim()) {
    return { hasViolation: false };
  }

  const raw = input.trim();
  const lower = raw.toLowerCase();

  // 1. Prohibited protocols
  const protocolRegex = /(tel:|sms:|mailto:|wa\.me|whatsapp:|tg:|viber:|callto:)/i;
  const protocolMatch = raw.match(protocolRegex);
  if (protocolMatch) {
    return {
      hasViolation: true,
      reason: 'Prohibited protocol or contact link',
      matchedText: protocolMatch[0],
    };
  }

  // 2. WhatsApp variants (Latin & Arabic)
  const whatsappRegex = /\b(whatsapp|watshap|watsapp|wtsap|whattsapp|wa\.me|w\.me)\b|واتساب|واتس\s*اب|واتس|واتسب/i;
  const waMatch = raw.match(whatsappRegex);
  if (waMatch) {
    return {
      hasViolation: true,
      reason: 'WhatsApp reference detected',
      matchedText: waMatch[0],
    };
  }

  // 3. Telegram variants (Latin & Arabic)
  const telegramRegex = /\b(telegram|t\.me|teleg)\b|تلجرام|تليجرام|تليغرام|تلغرام/i;
  const tgMatch = raw.match(telegramRegex);
  if (tgMatch) {
    return {
      hasViolation: true,
      reason: 'Telegram reference detected',
      matchedText: tgMatch[0],
    };
  }

  // 4. Email addresses
  const emailRegex = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})|(@(gmail|yahoo|hotmail|outlook|icloud)\.)/i;
  const emailMatch = raw.match(emailRegex);
  if (emailMatch) {
    return {
      hasViolation: true,
      reason: 'Email address detected',
      matchedText: emailMatch[0],
    };
  }

  // 5. Instagram / Social handles / Off-platform prompt phrases
  const instagramRegex = /\b(instagram|insta|ig\s*:)\b|انستغرام|انستقرام|انستا|@[a-zA-Z0-9_.]{3,}/i;
  const igMatch = raw.match(instagramRegex);
  if (igMatch) {
    return {
      hasViolation: true,
      reason: 'Instagram or social handle detected',
      matchedText: igMatch[0],
    };
  }

  // 6. External call / off-platform invitation phrases
  const offPlatformPhrases = [
    /\b(ara beni|beni ara|özelden yaz|özelden görüşelim|dm at|numaramı kaydet|telefon numaram)\b/i,
    /\b(call me|text me on|call my number|reach me at|my number is|dm me on)\b/i,
    /(كلمني فون|كلمني واتس|اتصل بيا|اتصل بي|تواصل فون|رقمي هو|ابعثلي خاص|تواصل خاص)/i,
  ];
  for (const phraseRegex of offPlatformPhrases) {
    const pMatch = raw.match(phraseRegex);
    if (pMatch) {
      return {
        hasViolation: true,
        reason: 'Off-platform invitation detected',
        matchedText: pMatch[0],
      };
    }
  }

  // 7. Phone numbers:
  // Convert Eastern Arabic numerals (٠-٩) to Western (0-9) for strict Egyptian detection
  const normalizedDigits = raw.replace(/[٠-٩]/g, (d) =>
    '٠١٢٣٤٥٦٧٨٩'.indexOf(d).toString()
  );

  // Strip common separators between digits (spaces, dots, dashes, parentheses, slashes)
  // Check for Egyptian mobile patterns (010, 011, 012, 015 followed by 8 digits)
  // Example matches: 01012345678, 010 1234 5678, 010-1234-5678, 010.1234.5678
  const egyptianMobileRegex = /(?:(?:\+|00)20\s*|0)?1[0125][\s.\-_/\\]*(?:\d[\s.\-_/\\]*){8}\b/;
  const egMatch = normalizedDigits.match(egyptianMobileRegex);
  if (egMatch) {
    return {
      hasViolation: true,
      reason: 'Egyptian phone number detected',
      matchedText: egMatch[0].trim(),
    };
  }

  // International numbers (+20..., +90..., +1...)
  const intlPhoneRegex = /(?:\+|00)(?:20|90|966|971|965|1|44)[\s.\-_/\\]*(?:\d[\s.\-_/\\]*){7,12}\b/;
  const intlMatch = normalizedDigits.match(intlPhoneRegex);
  if (intlMatch) {
    return {
      hasViolation: true,
      reason: 'International phone number detected',
      matchedText: intlMatch[0].trim(),
    };
  }

  // Turkish mobile patterns (05xx..., 5xx...)
  const trPhoneRegex = /(?:(?:\+|00)90\s*|0)?5[0-9]{2}[\s.\-_/\\]*(?:\d[\s.\-_/\\]*){7}\b/;
  const trMatch = normalizedDigits.match(trPhoneRegex);
  if (trMatch) {
    return {
      hasViolation: true,
      reason: 'Phone number detected',
      matchedText: trMatch[0].trim(),
    };
  }

  // Generic consecutive/spaced phone number detection:
  // Find sequences where extracting only digits yields 8 to 15 digits
  // But ensure we do not false-positive single prices like "450 EGP" or dates "2024"
  const digitChunks = normalizedDigits.match(/(?:\+?\d[\s.\-_/()]{0,3}){7,15}\d/g);
  if (digitChunks) {
    for (const chunk of digitChunks) {
      const onlyDigits = chunk.replace(/\D/g, '');
      // If 8+ digits, almost certainly a phone number
      if (onlyDigits.length >= 8 && onlyDigits.length <= 15) {
        return {
          hasViolation: true,
          reason: 'Phone number sequence detected',
          matchedText: chunk.trim(),
        };
      }
    }
  }

  return { hasViolation: false };
}
