import { BillingProduct, PurchaseRecord } from '../types';

/**
 * Google Play Billing Product Catalog for LUQTA
 * Separated strictly into Subscriptions and In-App One-Time Purchases.
 */
export const PLAY_BILLING_PRODUCTS: BillingProduct[] = [
  // 1. Super Seller Subscriptions
  {
    productId: 'luqta_sub_super_seller_monthly',
    type: 'SUBSCRIPTION',
    title: {
      tr: 'Süper Satıcı - Aylık',
      en: 'Super Seller - Monthly',
      ar: 'بائع مميز - شهري',
    },
    description: {
      tr: 'Profilinizde altın yıldız rozeti, güvenilir satıcı önceliği ve aramalarda %150 daha fazla görüntülenme.',
      en: 'Gold star badge on profile, trusted seller priority, and 150% more listing visibility.',
      ar: 'شارة النجمة الذهبية للملف الشخصي، وأولوية الثقة، وظهور أعلى بنسبة 150% في عمليات البحث.',
    },
    priceEgp: 199,
    formattedPrice: '199 EGP',
    periodLabel: {
      tr: 'Aylık Otomatik Yenilenir',
      en: 'Auto-renews monthly',
      ar: 'يتجدد شهرياً تلقائياً',
    },
    badgeText: {
      tr: 'EN POPÜLER',
      en: 'MOST POPULAR',
      ar: 'الأكثر طلباً',
    },
    benefits: {
      tr: [
        'Profil ve ilanlarda özel Altın "Süper Satıcı" rozeti',
        'Arama sonuçlarında ve filtrelerde üst sıralarda yer alma',
        'Alıcıların güvenini artırarak 3 kat daha hızlı satış yapma',
        'Google Play Güvenli Ödeme ve dilediğiniz an iptal imkanı',
      ],
      en: [
        'Exclusive Gold "Super Seller" badge on profile & items',
        'Top rank placement in search results and category feeds',
        'Earn buyer trust to sell items up to 3x faster',
        'Google Play secure billing with anytime cancellation',
      ],
      ar: [
        'شارة "بائع مميز" الذهبية الحصرية على الحساب والمعروضات',
        'أولوية الظهور في نتائج البحث وتصنيفات المنتجات',
        'كسب ثقة المشترين والبيع أسرع بما يصل إلى 3 أضعاف',
        'اشتراك آمن عبر Google Play مع إمكانية الإلغاء في أي وقت',
      ],
    },
  },
  {
    productId: 'luqta_sub_super_seller_quarterly',
    type: 'SUBSCRIPTION',
    title: {
      tr: 'Süper Satıcı - 3 Aylık Avantaj Paketi',
      en: 'Super Seller - 3 Months Plan',
      ar: 'بائع مميز - باقة 3 أشهر',
    },
    description: {
      tr: '3 aylık kesintisiz Süper Satıcı ayrıcalıkları ile %20 tasarruf edin.',
      en: 'Save 20% with uninterrupted 3-month Super Seller privileges.',
      ar: 'وفّر 20% مع امتيازات البائع المميز المتواصلة لمدة 3 أشهر.',
    },
    priceEgp: 479,
    formattedPrice: '479 EGP',
    periodLabel: {
      tr: '3 Ayda Bir Yenilenir (%20 İndirimli)',
      en: 'Renews every 3 months (20% off)',
      ar: 'يتجدد كل 3 أشهر (خصم 20%)',
    },
    badgeText: {
      tr: 'AVANTAJLI',
      en: 'BEST VALUE',
      ar: 'أفضل توفير',
    },
    benefits: {
      tr: [
        'Tüm Süper Satıcı avantajları 3 ay boyunca aktif',
        'Ayda 3 ücretsiz İlan Öne Çıkarma hediyesi',
        'Aylık plana kıyasla %20 doğrudan tasarruf',
        'Özel VIP satıcı desteği ve öncelikli onay',
      ],
      en: [
        'All Super Seller perks active for full 3 months',
        'Includes 3 free Product Boosts per month',
        'Save 20% compared to monthly plan',
        'VIP priority seller support',
      ],
      ar: [
        'جميع مزايا البائع المميز مفعّلة لمدة 3 أشهر كاملة',
        'يشمل 3 إعلانات مميزة مجانية كل شهر',
        'توفير 20% مقارنة بالاشتراك الشهري',
        'دعم فني خاص ذو أولوية للبائعين',
      ],
    },
  },

  // 2. Product Boost In-App Purchases (One-Time)
  {
    productId: 'luqta_inapp_boost_3d',
    type: 'INAPP',
    title: {
      tr: '3 Günlük İlan Öne Çıkarma',
      en: '3-Day Listing Boost',
      ar: 'تمييز الإعلان لمدة 3 أيام',
    },
    description: {
      tr: 'İlanınız ana sayfada ve arama sonuçlarında 3 gün boyunca üst sırada listelenir.',
      en: 'Your listing is featured at top of homepage and search feeds for 3 days.',
      ar: 'يظهر إعلانك في أعلى الصفحة الرئيسية ونتائج البحث لمدة 3 أيام.',
    },
    priceEgp: 49,
    formattedPrice: '49 EGP',
    badgeText: {
      tr: 'HIZLI SATIŞ',
      en: 'QUICK SALE',
      ar: 'بيع سريع',
    },
    benefits: {
      tr: [
        '3 gün boyunca kategori ve aramalarda en üst sırada görünme',
        'İlan üzerinde parlayan "Öne Çıkan" altın rozet',
        'Ortalama 3 kat daha fazla mesaj ve teklif alma',
      ],
      en: [
        'Pinned to top of search results and category feed for 3 days',
        'Glowing "Featured" gold badge on product card',
        'Up to 3x more messages and buyer offers',
      ],
      ar: [
        'تثبيت في صدارة نتائج البحث والتصنيف لمدة 3 أيام',
        'شارة ذهبية مميزة لامعة على بطاقة المنتج',
        'تلقي رسائل وعروض أكثر بثلاثة أضعاف في المتوسط',
      ],
    },
  },
  {
    productId: 'luqta_inapp_boost_7d',
    type: 'INAPP',
    title: {
      tr: '7 Günlük Mega Öne Çıkarma',
      en: '7-Day Mega Boost',
      ar: 'تمييز أسبوعي شامل (7 أيام)',
    },
    description: {
      tr: 'İlanınız 1 hafta boyunca vitrinde ve arama başlarında tutulur.',
      en: 'Keep your product in top showcase and search spotlight for a full week.',
      ar: 'إبقاء منتجك في واجهة التطبيق المميزة وأعلى البحث لمدة أسبوع كامل.',
    },
    priceEgp: 89,
    formattedPrice: '89 EGP',
    badgeText: {
      tr: 'MAKSİMUM ERİŞİM',
      en: 'MAX REACH',
      ar: 'أقصى انتشار',
    },
    benefits: {
      tr: [
        'Tam 7 gün boyunca kesintisiz vitrin ve arama zirvesi',
        'Mobil bildirim önerilerinde yer alma fırsatı',
        'Alıcıların gözünden kaçmayan prestijli altın çerçeve',
      ],
      en: [
        'Full 7 days of prime showcase placement',
        'Featured in recommendations and suggested finds',
        'Prestige gold border on card catching all eyes',
      ],
      ar: [
        'صدارة كاملة ومستمرة لمدة 7 أيام متتالية',
        'الظهور في اقتراحات المعروضات المختارة للمشترين',
        'إطار ذهبي فاخر يبرز المنتج بين جميع الإعلانات',
      ],
    },
  },
];

const PURCHASES_STORAGE_KEY = 'luqta_play_purchases_v1';

/**
 * Play Billing Storage and Helper
 */
export const PlayBillingService = {
  getPurchases(): PurchaseRecord[] {
    try {
      const data = localStorage.getItem(PURCHASES_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  savePurchases(records: PurchaseRecord[]): void {
    try {
      localStorage.setItem(PURCHASES_STORAGE_KEY, JSON.stringify(records));
    } catch (e) {
      console.error('Failed to save Play Billing purchases', e);
    }
  },

  isSuperSellerActive(): boolean {
    const purchases = this.getPurchases();
    return purchases.some(
      (p) =>
        p.productId.startsWith('luqta_sub_super_seller') &&
        (!p.expiryDate || new Date(p.expiryDate) > new Date())
    );
  },

  isItemBoosted(itemId: string): boolean {
    const purchases = this.getPurchases();
    return purchases.some(
      (p) =>
        p.targetItemId === itemId &&
        p.productId.includes('boost') &&
        (!p.expiryDate || new Date(p.expiryDate) > new Date())
    );
  },

  async simulatePlayPurchase(
    product: BillingProduct,
    targetItemId?: string,
    targetItemTitle?: string
  ): Promise<PurchaseRecord> {
    // Simulated realistic network delay for Google Play Billing sheet
    await new Promise((resolve) => setTimeout(resolve, 800));

    const daysValid = product.productId.includes('7d')
      ? 7
      : product.productId.includes('3d')
      ? 3
      : product.productId.includes('quarterly')
      ? 90
      : 30;

    const expiry = new Date();
    expiry.setDate(expiry.getDate() + daysValid);

    const newRecord: PurchaseRecord = {
      orderId: `GPA.${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(
        1000 + Math.random() * 9000
      )}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(
        10000 + Math.random() * 90000
      )}`,
      productId: product.productId,
      productTitle: product.title.tr,
      type: product.type,
      amountEgp: product.priceEgp,
      purchaseTime: new Date().toISOString(),
      acknowledged: true,
      targetItemId,
      targetItemTitle,
      expiryDate: expiry.toISOString(),
    };

    const current = this.getPurchases();
    const updated = [newRecord, ...current];
    this.savePurchases(updated);
    return newRecord;
  },
};
