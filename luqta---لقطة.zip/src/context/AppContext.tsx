import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Category,
  CategoryId,
  Conversation,
  CartItem,
  Order,
  Language,
  Seller,
  ChatMessage,
  ThemeMode,
} from '../types';
import {
  INITIAL_PRODUCTS,
  INITIAL_CONVERSATIONS,
  INITIAL_ORDERS,
  INITIAL_SELLERS,
  I18N,
} from '../data/mockData';
import { validateContactInfo } from '../utils/filter';
import { PlayBillingService } from '../services/billingService';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  themeMode: ThemeMode;
  setThemeMode: (theme: ThemeMode) => void;
  activeTab: 'home' | 'messages' | 'cart' | 'add' | 'menu';
  setActiveTab: (tab: 'home' | 'messages' | 'cart' | 'add' | 'menu') => void;
  products: Product[];
  selectedCategory: CategoryId;
  setSelectedCategory: (cat: CategoryId) => void;
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  
  // Modals & Navigation Views
  activeProductId: string | null;
  setActiveProductId: (id: string | null) => void;
  activeSeller: Seller | null;
  setActiveSeller: (seller: Seller | null) => void;
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;

  // Cart & Orders
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  orders: Order[];
  createOrderFromCart: () => void;

  // Favorites
  favorites: string[];
  toggleFavorite: (productId: string) => void;

  // In-app chat & messaging
  conversations: Conversation[];
  startChatWithSeller: (product: Product) => void;
  sendMessage: (conversationId: string, text: string) => { success: boolean; violation?: string };
  makeOffer: (conversationId: string, amount: number) => void;
  acceptOffer: (conversationId: string, messageId: string) => void;

  // Product submission
  addNewProduct: (productData: Omit<Product, 'id' | 'seller' | 'likesCount' | 'viewsCount' | 'createdAt'>) => {
    success: boolean;
    violation?: string;
  };

  // Monetization & Google Play In-App Purchases
  isUserSuperSeller: boolean;
  isSuperSellerModalOpen: boolean;
  setIsSuperSellerModalOpen: (open: boolean) => void;
  isPromoteModalOpen: boolean;
  setIsPromoteModalOpen: (open: boolean) => void;
  promoteTargetProduct: Product | null;
  openPromoteModal: (product?: Product | null) => void;
  isRevenueModalOpen: boolean;
  setIsRevenueModalOpen: (open: boolean) => void;
  boostProduct: (productId: string) => void;
  refreshMonetizationState: () => void;

  // Contact Filter Warning Modal State
  contactWarning: {
    isOpen: boolean;
    matchedText?: string;
    contextType: 'chat' | 'listing';
  };
  closeContactWarning: () => void;
  showContactWarning: (matchedText?: string, contextType?: 'chat' | 'listing') => void;

  // Localization helper
  t: (key: keyof typeof I18N['tr']) => string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('tr');

  // Theme Management (Light, Dark, System)
  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('luqta_theme_mode');
    return (saved as ThemeMode) || 'dark'; // Dark mode default matches premium anthracite branding
  });

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
    localStorage.setItem('luqta_theme_mode', mode);
  };

  // Sync dark class on document root
  useEffect(() => {
    const root = document.documentElement;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const applyTheme = () => {
      let isDark = false;
      if (themeMode === 'dark') {
        isDark = true;
      } else if (themeMode === 'light') {
        isDark = false;
      } else {
        isDark = mediaQuery.matches;
      }

      if (isDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };

    applyTheme();

    const listener = () => {
      if (themeMode === 'system') applyTheme();
    };

    mediaQuery.addEventListener('change', listener);
    return () => mediaQuery.removeEventListener('change', listener);
  }, [themeMode]);

  const [activeTab, setActiveTab] = useState<'home' | 'messages' | 'cart' | 'add' | 'menu'>('home');
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [activeProductId, setActiveProductId] = useState<string | null>(null);
  const [activeSeller, setActiveSeller] = useState<Seller | null>(null);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);

  const [cart, setCart] = useState<CartItem[]>([
    { product: INITIAL_PRODUCTS[0], addedAt: new Date().toISOString() },
  ]);
  const [favorites, setFavorites] = useState<string[]>(['prod_1', 'prod_3']);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);

  // Monetization States
  const [isUserSuperSeller, setIsUserSuperSeller] = useState<boolean>(() => {
    return PlayBillingService.isSuperSellerActive();
  });
  const [isSuperSellerModalOpen, setIsSuperSellerModalOpen] = useState(false);
  const [isPromoteModalOpen, setIsPromoteModalOpen] = useState(false);
  const [promoteTargetProduct, setPromoteTargetProduct] = useState<Product | null>(null);
  const [isRevenueModalOpen, setIsRevenueModalOpen] = useState(false);

  const refreshMonetizationState = () => {
    const isSuper = PlayBillingService.isSuperSellerActive();
    setIsUserSuperSeller(isSuper);

    // Refresh boosted products
    setProducts((prev) =>
      prev.map((p) => {
        const isBoosted = p.isBoosted || PlayBillingService.isItemBoosted(p.id);
        return { ...p, isBoosted };
      })
    );
  };

  const openPromoteModal = (product?: Product | null) => {
    setPromoteTargetProduct(product || null);
    setIsPromoteModalOpen(true);
  };

  const boostProduct = (productId: string) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          return {
            ...p,
            isBoosted: true,
            boostExpiresAt: new Date(Date.now() + 7 * 86400000).toISOString(),
          };
        }
        return p;
      })
    );
    refreshMonetizationState();
  };

  // Warning modal
  const [contactWarning, setContactWarning] = useState<{
    isOpen: boolean;
    matchedText?: string;
    contextType: 'chat' | 'listing';
  }>({
    isOpen: false,
    matchedText: undefined,
    contextType: 'chat',
  });

  const showContactWarning = (matchedText?: string, contextType: 'chat' | 'listing' = 'chat') => {
    setContactWarning({
      isOpen: true,
      matchedText,
      contextType,
    });
  };

  const closeContactWarning = () => {
    setContactWarning((prev) => ({ ...prev, isOpen: false }));
  };

  // Set RTL direction attribute on root element if Arabic
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const t = (key: keyof typeof I18N['tr']): string => {
    return I18N[language]?.[key] || I18N.tr[key] || '';
  };

  const addToCart = (product: Product) => {
    if (!cart.some((item) => item.product.id === product.id)) {
      setCart((prev) => [...prev, { product, addedAt: new Date().toISOString() }]);
    }
    setActiveTab('cart');
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const createOrderFromCart = () => {
    if (cart.length === 0) return;
    const newOrders: Order[] = cart.map((item) => ({
      id: `ORD-${Math.floor(10000 + Math.random() * 90000)}`,
      product: item.product,
      amount: item.product.price,
      buyerProtectionFee: Math.max(25, Math.round(item.product.price * 0.04)),
      date: new Date().toLocaleDateString(),
      status: 'meeting_arranged',
      deliveryMethod: 'hand_delivery',
      meetingCity: item.product.city,
    }));
    setOrders((prev) => [...newOrders, ...prev]);
    clearCart();
    setActiveTab('menu');
  };

  const toggleFavorite = (productId: string) => {
    setFavorites((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const startChatWithSeller = (product: Product) => {
    const existing = conversations.find(
      (c) => c.productId === product.id || (c.sellerId === product.seller.id && c.productId === product.id)
    );

    if (existing) {
      setActiveConversationId(existing.id);
      setActiveTab('messages');
      return;
    }

    const newConvId = `conv_${Date.now()}`;
    const newConv: Conversation = {
      id: newConvId,
      productId: product.id,
      product: product,
      buyerId: 'current_user',
      sellerId: product.seller.id,
      seller: product.seller,
      lastMessage: `Merhaba, "${product.title}" hakkında bilgi almak istiyorum.`,
      lastMessageTime: 'Şimdi',
      unreadCount: 0,
      messages: [
        {
          id: `msg_${Date.now()}`,
          conversationId: newConvId,
          senderId: 'current_user',
          text: `Merhaba, "${product.title}" hakkında bilgi almak istiyorum.`,
          timestamp: 'Şimdi',
        },
      ],
    };

    setConversations((prev) => [newConv, ...prev]);
    setActiveConversationId(newConvId);
    setActiveTab('messages');
  };

  const sendMessage = (conversationId: string, text: string) => {
    const filterResult = validateContactInfo(text);
    if (filterResult.hasViolation) {
      showContactWarning(filterResult.matchedText, 'chat');
      return { success: false, violation: filterResult.matchedText };
    }

    const trimmed = text.trim();
    if (!trimmed) return { success: false };

    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      conversationId,
      senderId: 'current_user',
      text: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          return {
            ...c,
            lastMessage: trimmed,
            lastMessageTime: 'Şimdi',
            messages: [...c.messages, newMsg],
          };
        }
        return c;
      })
    );

    setTimeout(() => {
      const conv = conversations.find((c) => c.id === conversationId);
      const sellerReplies = [
        'Harika, ürün dolabımda temiz ve özenle saklandı. Sipariş sonrası mesajlaşarak ortak bir noktada elden teslim yapabiliriz!',
        'Sorunuz için teşekkürler! Beden tam kalıptır, LUQTA güvencesiyle satın alabilir ve elden teslimde inceleyebilirsiniz.',
        'Anlaştık! Sistem üzerinden güvenli ödeme yaparak siparişi oluşturabilir, mesajla buluşma yerini belirleyebiliriz.',
      ];
      const randomReply = sellerReplies[Math.floor(Math.random() * sellerReplies.length)];

      const sellerMsg: ChatMessage = {
        id: `msg_reply_${Date.now()}`,
        conversationId,
        senderId: conv?.sellerId || 'seller_1',
        text: randomReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setConversations((prev) =>
        prev.map((c) => {
          if (c.id === conversationId) {
            return {
              ...c,
              lastMessage: randomReply,
              lastMessageTime: 'Şimdi',
              messages: [...c.messages, sellerMsg],
            };
          }
          return c;
        })
      );
    }, 1800);

    return { success: true };
  };

  const makeOffer = (conversationId: string, amount: number) => {
    const offerMsg: ChatMessage = {
      id: `offer_${Date.now()}`,
      conversationId,
      senderId: 'current_user',
      text: `${amount} EGP tutarında fiyat teklifi gönderildi`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isOffer: true,
      offerAmount: amount,
      offerStatus: 'pending',
    };

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          return {
            ...c,
            lastMessage: `${amount} EGP teklifi yapıldı`,
            lastMessageTime: 'Şimdi',
            messages: [...c.messages, offerMsg],
          };
        }
        return c;
      })
    );

    setTimeout(() => {
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id === conversationId) {
            return {
              ...c,
              messages: c.messages.map((m) =>
                m.id === offerMsg.id ? { ...m, offerStatus: 'accepted' } : m
              ),
            };
          }
          return c;
        })
      );
    }, 2500);
  };

  const acceptOffer = (conversationId: string, messageId: string) => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          return {
            ...c,
            messages: c.messages.map((m) =>
              m.id === messageId ? { ...m, offerStatus: 'accepted' } : m
            ),
          };
        }
        return c;
      })
    );
  };

  const addNewProduct = (
    productData: Omit<Product, 'id' | 'seller' | 'likesCount' | 'viewsCount' | 'createdAt'>
  ) => {
    const titleCheck = validateContactInfo(productData.title);
    if (titleCheck.hasViolation) {
      showContactWarning(titleCheck.matchedText, 'listing');
      return { success: false, violation: titleCheck.matchedText };
    }

    const descCheck = validateContactInfo(productData.description);
    if (descCheck.hasViolation) {
      showContactWarning(descCheck.matchedText, 'listing');
      return { success: false, violation: descCheck.matchedText };
    }

    const currentUserSeller: Seller = {
      id: 'current_user',
      name: 'Kadir Aslan',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop&crop=faces',
      city: productData.city || 'Cairo (New Cairo)',
      rating: 5.0,
      ratingCount: 12,
      listingCount: 3,
      joinedYear: 2024,
      verified: true,
      isSuperSeller: isUserSuperSeller,
      responseRate: '10 dk içinde',
      bio: 'Temiz ve az kullanılmış gardırop parçaları. Güvenli elden teslim.',
    };

    const newProd: Product = {
      ...productData,
      id: `prod_${Date.now()}`,
      seller: currentUserSeller,
      likesCount: 0,
      viewsCount: 1,
      createdAt: 'Yeni eklendi',
    };

    setProducts((prev) => [newProd, ...prev]);
    setActiveTab('home');
    return { success: true };
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        themeMode,
        setThemeMode,
        activeTab,
        setActiveTab,
        products,
        selectedCategory,
        setSelectedCategory,
        selectedCity,
        setSelectedCity,
        searchQuery,
        setSearchQuery,
        activeProductId,
        setActiveProductId,
        activeSeller,
        setActiveSeller,
        activeConversationId,
        setActiveConversationId,
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        orders,
        createOrderFromCart,
        favorites,
        toggleFavorite,
        conversations,
        startChatWithSeller,
        sendMessage,
        makeOffer,
        acceptOffer,
        addNewProduct,
        isUserSuperSeller,
        isSuperSellerModalOpen,
        setIsSuperSellerModalOpen,
        isPromoteModalOpen,
        setIsPromoteModalOpen,
        promoteTargetProduct,
        openPromoteModal,
        isRevenueModalOpen,
        setIsRevenueModalOpen,
        boostProduct,
        refreshMonetizationState,
        contactWarning,
        closeContactWarning,
        showContactWarning,
        t,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
