/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { ContactWarningModal } from './components/ContactWarningModal';
import { SuperSellerModal } from './components/SuperSellerModal';
import { PromoteProductModal } from './components/PromoteProductModal';
import { PlatformRevenueModal } from './components/PlatformRevenueModal';
import { HomeView } from './views/HomeView';
import { ChatView } from './views/ChatView';
import { AddProductView } from './views/AddProductView';
import { CartView } from './views/CartView';
import { MenuView } from './views/MenuView';
import { ProductDetailView } from './views/ProductDetailView';
import { ProfileModal } from './views/ProfileModal';

const AppContent: React.FC = () => {
  const {
    activeTab,
    activeProductId,
    activeSeller,
    isSuperSellerModalOpen,
    setIsSuperSellerModalOpen,
    isPromoteModalOpen,
    setIsPromoteModalOpen,
    promoteTargetProduct,
    isRevenueModalOpen,
    setIsRevenueModalOpen,
  } = useApp();

  return (
    <div className="min-h-screen bg-zinc-100 dark:bg-zinc-950 flex justify-center text-zinc-900 dark:text-zinc-100 selection:bg-amber-500/20 selection:text-amber-600 dark:selection:text-amber-300 transition-colors">
      {/* Mobile Frame Container: Maximum width for authentic Android/Capacitor mobile experience */}
      <div className="w-full max-w-md min-h-screen bg-white dark:bg-zinc-900 shadow-xl relative flex flex-col transition-colors border-x border-zinc-200/50 dark:border-zinc-800/50">
        {/* Global Safe Area Top Header */}
        <Header />

        {/* Main Content Area */}
        <main className="flex-1 px-4 pt-3 overflow-x-hidden">
          {activeTab === 'home' && <HomeView />}
          {activeTab === 'messages' && <ChatView />}
          {activeTab === 'add' && <AddProductView />}
          {activeTab === 'cart' && <CartView />}
          {activeTab === 'menu' && <MenuView />}
        </main>

        {/* Global Safe Area Bottom Navigation */}
        <BottomNav />

        {/* Product & Profile Modals */}
        {activeProductId && <ProductDetailView />}
        {activeSeller && <ProfileModal />}
        <ContactWarningModal />

        {/* Google Play Monetization Modals */}
        <SuperSellerModal
          isOpen={isSuperSellerModalOpen}
          onClose={() => setIsSuperSellerModalOpen(false)}
        />
        <PromoteProductModal
          isOpen={isPromoteModalOpen}
          onClose={() => setIsPromoteModalOpen(false)}
          targetProduct={promoteTargetProduct}
        />
        <PlatformRevenueModal
          isOpen={isRevenueModalOpen}
          onClose={() => setIsRevenueModalOpen(false)}
        />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
