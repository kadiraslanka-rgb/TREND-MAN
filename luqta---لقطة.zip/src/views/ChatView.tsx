import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  ArrowLeft,
  Send,
  ShieldAlert,
  ShieldCheck,
  Tag,
  CheckCheck,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

export const ChatView: React.FC = () => {
  const {
    conversations,
    activeConversationId,
    setActiveConversationId,
    sendMessage,
    makeOffer,
    language,
    t,
  } = useApp();

  const [inputMessage, setInputMessage] = useState('');
  const [offerInput, setOfferInput] = useState('');
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [localInputWarning, setLocalInputWarning] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentConv = conversations.find((c) => c.id === activeConversationId);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentConv?.messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeConversationId || !inputMessage.trim()) return;

    const res = sendMessage(activeConversationId, inputMessage);
    if (res.success) {
      setInputMessage('');
      setLocalInputWarning(null);
    } else {
      // Violation was caught by filter
      setLocalInputWarning(t('warningExternalBlocked'));
    }
  };

  const handleMakeOfferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(offerInput);
    if (!amount || isNaN(amount) || !activeConversationId) return;

    makeOffer(activeConversationId, amount);
    setShowOfferModal(false);
    setOfferInput('');
  };

  // 1. If NO conversation is actively selected, show Conversation List
  if (!activeConversationId || !currentConv) {
    return (
      <div className="space-y-3 pb-24 text-zinc-900 dark:text-zinc-100">
        {/* Page Title with Top Safe Area */}
        <div className="flex items-center justify-between pb-1">
          <div>
            <h1 className="text-base font-extrabold text-zinc-900 dark:text-zinc-100 tracking-tight">
              {t('tabMessages')}
            </h1>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              {language === 'ar'
                ? 'محادثاتك المباشرة مع البائعين داخل التطبيق'
                : language === 'en'
                ? 'Your direct in-app seller conversations'
                : 'Satıcılarla güvenli uygulama içi mesajlaşmalarınız'}
            </p>
          </div>
          <div className="flex items-center space-x-1 rtl:space-x-reverse bg-amber-500/15 text-amber-700 dark:text-amber-400 text-[11px] font-bold px-2 py-1 rounded-full border border-amber-500/30">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
            <span>{language === 'ar' ? 'تواصل محمي' : language === 'en' ? 'Protected' : 'Korumalı'}</span>
          </div>
        </div>

        {/* Safety Reminder Banner */}
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 flex items-start space-x-2.5 rtl:space-x-reverse text-xs">
          <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="text-zinc-800 dark:text-zinc-200 leading-relaxed">
            <span className="font-bold block text-zinc-900 dark:text-zinc-100">
              {t('warningExternalBlocked')}
            </span>
            <span className="text-[11px] text-zinc-600 dark:text-zinc-400">
              {language === 'ar'
                ? 'لحمايتك من الاحتيال، يُحظر تبادل أرقام الهواتف أو واتساب خارج لقطة.'
                : language === 'en'
                ? 'To prevent scams, exchanging phone numbers or WhatsApp outside LUQTA is strictly blocked.'
                : 'Dolandırıcılıktan korunmanız için telefon veya WhatsApp paylaşımı engellenmektedir.'}
            </span>
          </div>
        </div>

        {/* Conversation List */}
        {conversations.length === 0 ? (
          <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-8 text-center space-y-2">
            <p className="text-sm font-semibold text-zinc-700 dark:text-zinc-300">{t('emptyMessages')}</p>
          </div>
        ) : (
          <div className="space-y-2">
            {conversations.map((conv) => (
              <div
                key={conv.id}
                onClick={() => setActiveConversationId(conv.id)}
                className="bg-white dark:bg-zinc-900 hover:bg-zinc-50 dark:hover:bg-zinc-800/60 rounded-2xl p-3.5 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs flex items-center space-x-3 rtl:space-x-reverse cursor-pointer transition-all"
              >
                <div className="relative shrink-0">
                  <img
                    src={conv.seller.avatar}
                    alt={conv.seller.name}
                    className="w-12 h-12 rounded-full object-cover border border-zinc-200 dark:border-zinc-700"
                  />
                  <div className="w-3 h-3 bg-amber-500 rounded-full border-2 border-white dark:border-zinc-900 absolute bottom-0 right-0" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-zinc-900 dark:text-zinc-100 truncate">
                      {conv.seller.name}
                    </h3>
                    <span className="text-[10px] text-zinc-400 shrink-0">
                      {conv.lastMessageTime}
                    </span>
                  </div>

                  <p className="text-[11px] font-semibold text-amber-700 dark:text-amber-400 truncate mt-0.5">
                    {conv.product.title}
                  </p>

                  <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate mt-0.5">
                    {conv.lastMessage}
                  </p>
                </div>

                <img
                  src={conv.product.images[0]}
                  alt={conv.product.title}
                  className="w-11 h-11 rounded-lg object-cover border border-zinc-200 dark:border-zinc-800 shrink-0"
                />
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // 2. ACTIVE CHAT WINDOW (Buyer <-> Seller)
  return (
    <div className="fixed inset-0 z-50 bg-zinc-50 dark:bg-zinc-950 flex flex-col overflow-hidden animate-slide-up text-zinc-900 dark:text-zinc-100 transition-colors">
      {/* Chat Header with Global Safe Area padding */}
      <div
        className="sticky top-0 z-20 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md border-b border-zinc-200/80 dark:border-zinc-800/80 px-4 pb-2.5 flex items-center justify-between"
        style={{
          paddingTop: 'max(env(safe-area-inset-top, 0px), 12px)',
        }}
      >
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
          <button
            onClick={() => setActiveConversationId(null)}
            className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors cursor-pointer"
            aria-label="Geri"
          >
            <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          </button>

          <img
            src={currentConv.seller.avatar}
            alt={currentConv.seller.name}
            className="w-9 h-9 rounded-full object-cover border border-zinc-200 dark:border-zinc-700"
          />

          <div>
            <h2 className="text-xs font-bold text-zinc-900 dark:text-zinc-100 leading-tight">
              {currentConv.seller.name}
            </h2>
            <div className="flex items-center space-x-1 rtl:space-x-reverse text-[10px] text-zinc-500 dark:text-zinc-400">
              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse" />
              <span>{language === 'ar' ? 'متصل الآن' : language === 'en' ? 'Online' : 'Çevrimiçi'}</span>
              <span>•</span>
              <span>{currentConv.seller.city}</span>
            </div>
          </div>
        </div>

        {/* In-app secure badge */}
        <div className="flex items-center space-x-1 rtl:space-x-reverse bg-amber-500/15 text-amber-700 dark:text-amber-400 text-[10px] font-bold px-2 py-1 rounded-full border border-amber-500/30">
          <ShieldCheck className="w-3 h-3 text-amber-500" />
          <span>{language === 'ar' ? 'حماية لقطة' : language === 'en' ? 'Protected' : 'Güvenli Sohbet'}</span>
        </div>
      </div>

      {/* Pinned Product Preview Banner inside Chat */}
      <div className="bg-white dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 px-4 py-2 flex items-center justify-between shadow-2xs">
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse truncate max-w-[70%]">
          <img
            src={currentConv.product.images[0]}
            alt={currentConv.product.title}
            className="w-10 h-10 rounded-lg object-cover border border-zinc-200 dark:border-zinc-800 shrink-0"
          />
          <div className="truncate">
            <h3 className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 truncate">
              {currentConv.product.title}
            </h3>
            <span className="text-xs font-extrabold text-amber-600 dark:text-amber-400">
              {currentConv.product.price} EGP
            </span>
          </div>
        </div>

        <button
          onClick={() => setShowOfferModal(true)}
          className="px-2.5 py-1.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-800 dark:text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold flex items-center space-x-1 rtl:space-x-reverse transition-colors cursor-pointer"
        >
          <Tag className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          <span>{t('makeOffer')}</span>
        </button>
      </div>

      {/* Security Tip Banner */}
      <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-1.5 flex items-center space-x-2 rtl:space-x-reverse text-[11px] text-zinc-800 dark:text-zinc-200">
        <ShieldAlert className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
        <span className="truncate">
          <strong>{t('warningExternalBlocked')}</strong>
        </span>
      </div>

      {/* Messages Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {currentConv.messages.map((msg) => {
          const isMe = msg.senderId === 'current_user';

          if (msg.isOffer) {
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div className="bg-white dark:bg-zinc-900 border-2 border-amber-400/80 dark:border-amber-500/70 rounded-2xl p-3 shadow-2xs max-w-xs space-y-2">
                  <div className="flex items-center space-x-1.5 rtl:space-x-reverse text-amber-700 dark:text-amber-400 font-bold text-xs">
                    <Tag className="w-4 h-4" />
                    <span>
                      {language === 'ar' ? 'عرض سعر خاص' : language === 'en' ? 'Price Offer' : 'Fiyat Teklifi'}
                    </span>
                  </div>
                  <div className="text-lg font-black text-zinc-950 dark:text-zinc-50">
                    {msg.offerAmount} EGP
                  </div>
                  <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                    {msg.offerStatus === 'accepted' ? (
                      <span className="text-amber-600 dark:text-amber-400 font-bold flex items-center space-x-1 rtl:space-x-reverse">
                        <CheckCheck className="w-3.5 h-3.5" />
                        <span>
                          {language === 'ar' ? 'تم قبول العرض!' : language === 'en' ? 'Offer Accepted!' : 'Teklif Kabul Edildi!'}
                        </span>
                      </span>
                    ) : (
                      <span className="text-zinc-600 dark:text-zinc-400 font-medium">
                        {language === 'ar' ? 'في انتظار رد البائع' : language === 'en' ? 'Pending seller approval' : 'Satıcı onayı bekleniyor'}
                      </span>
                    )}
                  </div>
                </div>
                <span className="text-[9px] text-zinc-400 mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            );
          }

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[78%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed shadow-2xs ${
                  isMe
                    ? 'bg-zinc-900 text-white dark:bg-amber-500 dark:text-zinc-950 rounded-br-xs font-medium'
                    : 'bg-white dark:bg-zinc-900 text-zinc-800 dark:text-zinc-200 border border-zinc-200/80 dark:border-zinc-800 rounded-bl-xs'
                }`}
              >
                <p>{msg.text}</p>
              </div>
              <span className="text-[9px] text-zinc-400 mt-0.5 px-1 flex items-center space-x-0.5 rtl:space-x-reverse">
                <span>{msg.timestamp}</span>
                {isMe && <CheckCheck className="w-3 h-3 text-amber-500 inline" />}
              </span>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Inline Warning Notice if triggered */}
      {localInputWarning && (
        <div className="bg-rose-50 dark:bg-rose-950/40 border-t border-rose-200 dark:border-rose-800 px-4 py-2 flex items-center justify-between text-xs text-rose-800 dark:text-rose-200 animate-shake">
          <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
            <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            <span className="font-semibold">{localInputWarning}</span>
          </div>
          <button
            onClick={() => setLocalInputWarning(null)}
            className="text-rose-500 hover:text-rose-800 font-bold ml-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Input Bar with Bottom Safe Area */}
      <form
        onSubmit={handleSend}
        className="bg-white dark:bg-zinc-900 border-t border-zinc-200 dark:border-zinc-800 px-3 pt-2.5 shadow-lg"
        style={{
          paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 10px)',
        }}
      >
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => {
              setInputMessage(e.target.value);
              if (localInputWarning) setLocalInputWarning(null);
            }}
            placeholder={
              language === 'ar'
                ? 'اكتب رسالتك داخل لقطة فقط...'
                : language === 'en'
                ? 'Type in-app message only...'
                : 'Uygulama içi güvenli mesajınızı yazın...'
            }
            className="flex-1 bg-zinc-100 hover:bg-zinc-100/80 focus:bg-white dark:bg-zinc-800 dark:focus:bg-zinc-800 text-zinc-900 dark:text-zinc-100 text-xs rounded-xl px-3.5 py-2.5 border border-transparent dark:border-zinc-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/10 transition-all outline-hidden placeholder:text-zinc-400 dark:placeholder:text-zinc-500"
          />

          <button
            type="submit"
            disabled={!inputMessage.trim()}
            className="w-10 h-10 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-amber-500 dark:hover:bg-amber-400 disabled:bg-zinc-200 dark:disabled:bg-zinc-800 disabled:text-zinc-400 text-white dark:text-zinc-950 flex items-center justify-center transition-colors cursor-pointer shrink-0 shadow-2xs"
            aria-label="Gönder"
          >
            <Send className="w-4 h-4 rtl:-rotate-90" />
          </button>
        </div>

        {/* Safety Quick Helper / Filter demonstration triggers */}
        <div className="flex items-center justify-between mt-1.5 text-[10px] text-zinc-400 px-1">
          <span>{t('inAppOnlyNotice')}</span>
          <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
            <button
              type="button"
              onClick={() => setInputMessage('01012345678')}
              className="text-amber-600 dark:text-amber-400 hover:underline cursor-pointer font-medium"
              title="Güvenlik filtresini sına"
            >
              [Test No]
            </button>
            <button
              type="button"
              onClick={() => setInputMessage('whatsapp: 01100000000')}
              className="text-amber-600 dark:text-amber-400 hover:underline cursor-pointer font-medium"
              title="WhatsApp filtresini sına"
            >
              [Test WA]
            </button>
          </div>
        </div>
      </form>

      {/* Make Offer Modal */}
      {showOfferModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/60 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white dark:bg-zinc-900 rounded-2xl p-5 shadow-2xl border border-zinc-200 dark:border-zinc-800 space-y-3">
            <h3 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">
              {t('makeOffer')}
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              {language === 'ar'
                ? `السعر الحالي: ${currentConv.product.price} ج.م`
                : language === 'en'
                ? `Current price: ${currentConv.product.price} EGP`
                : `Mevcut fiyat: ${currentConv.product.price} EGP`}
            </p>
            <form onSubmit={handleMakeOfferSubmit} className="space-y-3">
              <div className="relative">
                <input
                  type="number"
                  min="1"
                  max={currentConv.product.price}
                  value={offerInput}
                  onChange={(e) => setOfferInput(e.target.value)}
                  placeholder="Teklif tutarı (EGP)"
                  className="w-full text-base font-bold text-zinc-900 dark:text-zinc-100 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2 outline-hidden focus:border-amber-500 focus:ring-2 focus:ring-amber-500/10"
                  autoFocus
                />
                <span className="absolute right-3 rtl:right-auto rtl:left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-zinc-400">
                  EGP
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setShowOfferModal(false)}
                  className="py-2 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-300 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 cursor-pointer"
                >
                  {language === 'ar' ? 'إلغاء' : language === 'en' ? 'Cancel' : 'Vazgeç'}
                </button>
                <button
                  type="submit"
                  disabled={!offerInput}
                  className="py-2 rounded-xl text-xs font-bold text-white dark:text-zinc-950 bg-zinc-900 dark:bg-amber-500 hover:bg-zinc-800 dark:hover:bg-amber-400 disabled:bg-zinc-200 dark:disabled:bg-zinc-800 cursor-pointer"
                >
                  {language === 'ar' ? 'إرسال العرض' : language === 'en' ? 'Send Offer' : 'Gönder'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
