import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Star, MapPin, CheckCircle, ShieldCheck, MessageSquare, Crown } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';

export const ProfileModal: React.FC = () => {
  const {
    activeSeller,
    setActiveSeller,
    products,
    startChatWithSeller,
    language,
    t,
  } = useApp();

  if (!activeSeller) return null;

  // Filter products belonging to this seller
  const sellerProducts = products.filter((p) => p.seller.id === activeSeller.id);

  return (
    <div className="fixed inset-0 z-50 bg-white dark:bg-zinc-950 flex flex-col overflow-hidden animate-slide-up text-zinc-900 dark:text-zinc-100 transition-colors">
      {/* Top Header with Safe Area handling */}
      <div
        className="sticky top-0 z-20 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md border-b border-zinc-200/80 dark:border-zinc-800/80 flex items-center justify-between px-4 pb-3"
        style={{
          paddingTop: 'max(env(safe-area-inset-top, 0px), 12px)',
        }}
      >
        <button
          onClick={() => setActiveSeller(null)}
          className="w-9 h-9 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors cursor-pointer"
          aria-label="Geri"
        >
          <ArrowLeft className="w-5 h-5 rtl:rotate-180" />
        </button>

        <h1 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">
          {activeSeller.name}
        </h1>

        <div className="w-9" />
      </div>

      {/* Profile Body */}
      <div 
        className="flex-1 overflow-y-auto p-4 space-y-4"
        style={{
          paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 24px)',
        }}
      >
        {/* Profile Card (Strict Privacy: Only display name, photo, city, rating, listing count) */}
        <div className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl p-4 text-center space-y-3">
          <div className="relative inline-block">
            <img
              src={activeSeller.avatar}
              alt={activeSeller.name}
              className="w-20 h-20 rounded-full object-cover mx-auto border-3 border-white dark:border-zinc-800 shadow-sm"
            />
            {activeSeller.isSuperSeller ? (
              <div className="absolute bottom-0 right-0 bg-amber-500 text-zinc-950 p-1 rounded-full border-2 border-white dark:border-zinc-900 shadow-xs" title="Süper Satıcı">
                <Crown className="w-3.5 h-3.5" />
              </div>
            ) : activeSeller.verified ? (
              <div className="absolute bottom-0 right-0 bg-zinc-800 text-amber-400 p-1 rounded-full border-2 border-white dark:border-zinc-900">
                <CheckCircle className="w-3.5 h-3.5" />
              </div>
            ) : null}
          </div>

          <div>
            <div className="flex items-center justify-center space-x-1.5 rtl:space-x-reverse">
              <h2 className="text-base font-bold text-zinc-900 dark:text-zinc-100">{activeSeller.name}</h2>
              {activeSeller.isSuperSeller && (
                <span className="bg-amber-500/20 text-amber-700 dark:text-amber-400 text-[10px] font-black px-1.5 py-0.5 rounded-sm">
                  {t('superSeller')}
                </span>
              )}
            </div>
            <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              <MapPin className="w-3.5 h-3.5 text-zinc-400" />
              <span>{activeSeller.city}</span>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-3 gap-2 bg-white dark:bg-zinc-800/60 p-3 rounded-xl border border-zinc-200/70 dark:border-zinc-750">
            <div>
              <span className="text-[10px] text-zinc-400 uppercase font-semibold block">
                {t('rating')}
              </span>
              <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse text-xs font-black text-amber-600 dark:text-amber-400 mt-0.5">
                <Star className="w-3.5 h-3.5 fill-amber-400 stroke-amber-400" />
                <span>{activeSeller.rating}</span>
              </div>
            </div>
            <div className="border-x border-zinc-200/70 dark:border-zinc-700">
              <span className="text-[10px] text-zinc-400 uppercase font-semibold block">
                {t('listings')}
              </span>
              <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 block mt-0.5">
                {activeSeller.listingCount}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-zinc-400 uppercase font-semibold block">
                {language === 'ar' ? 'عضو منذ' : language === 'en' ? 'Member' : 'Üyelik'}
              </span>
              <span className="text-xs font-black text-zinc-900 dark:text-zinc-100 block mt-0.5">
                {activeSeller.joinedYear}
              </span>
            </div>
          </div>

          {/* Seller Bio if present */}
          {activeSeller.bio && (
            <p className="text-xs text-zinc-600 dark:text-zinc-300 italic bg-white/60 dark:bg-zinc-800/40 p-2.5 rounded-xl border border-zinc-200/60 dark:border-zinc-800 leading-relaxed text-left rtl:text-right">
              "{activeSeller.bio}"
            </p>
          )}

          {/* In-app Message Button (Safe direct communication) */}
          {sellerProducts.length > 0 && (
            <button
              onClick={() => {
                setActiveSeller(null);
                startChatWithSeller(sellerProducts[0]);
              }}
              className="w-full py-2.5 bg-zinc-900 hover:bg-zinc-800 dark:bg-amber-500 dark:hover:bg-amber-400 text-white dark:text-zinc-950 rounded-xl text-xs font-bold flex items-center justify-center space-x-2 rtl:space-x-reverse transition-colors shadow-xs cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>{t('sendMessage')}</span>
            </button>
          )}

          {/* Strict Privacy Protection Notice */}
          <div className="flex items-center justify-center space-x-1.5 rtl:space-x-reverse text-[11px] text-zinc-400">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
            <span>{t('privacyNotice')}</span>
          </div>
        </div>

        {/* Seller's Products Grid */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
            {language === 'ar' ? 'معروضات البائع' : language === 'en' ? "Seller's Closet" : 'Satıcının Gardırobu'} ({sellerProducts.length})
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {sellerProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
