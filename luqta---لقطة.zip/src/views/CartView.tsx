import React from 'react';
import { useApp } from '../context/AppContext';
import { Trash2, ShieldCheck, ArrowRight, ShoppingBag, Users, MessageSquare } from 'lucide-react';

export const CartView: React.FC = () => {
  const { cart, removeFromCart, createOrderFromCart, setActiveTab, language, t } = useApp();

  const subtotal = cart.reduce((sum, item) => sum + item.product.price, 0);
  const buyerProtectionFee = cart.length > 0 ? Math.max(30, Math.round(subtotal * 0.04)) : 0;
  const total = subtotal + buyerProtectionFee;

  if (cart.length === 0) {
    return (
      <div className="space-y-4 pb-24 text-center py-12">
        <div className="w-16 h-16 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mx-auto text-zinc-400">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <div className="space-y-1">
          <h2 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">{t('emptyCart')}</h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400">
            {language === 'ar'
              ? 'تصفح تشكيلة الملابس المتنوعة وأضف ما يعجبك إلى السلة'
              : language === 'en'
              ? 'Explore thousands of pre-loved items and add to your bag'
              : 'Gardıroptan beğendiğiniz ürünleri sepetinize ekleyin'}
          </p>
        </div>
        <button
          onClick={() => setActiveTab('home')}
          className="px-5 py-2.5 bg-zinc-950 dark:bg-amber-500 hover:bg-zinc-800 dark:hover:bg-amber-400 text-white dark:text-zinc-950 rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-xs"
        >
          {t('startBrowsing')}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-32">
      {/* Page Title */}
      <div className="pb-1">
        <h1 className="text-base font-extrabold text-zinc-900 dark:text-zinc-100 tracking-tight">
          {t('tabCart')} ({cart.length})
        </h1>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          {language === 'ar'
            ? 'مشترياتك المضمونة عبر نظام حماية المشتري مع التسليم يد بيد'
            : language === 'en'
            ? 'Your orders backed by Luqta Buyer Protection & local hand delivery'
            : 'Luqta Alıcı Koruması ve elden teslim güvencesiyle siparişiniz'}
        </p>
      </div>

      {/* Cart Items List */}
      <div className="space-y-2.5">
        {cart.map(({ product }) => (
          <div
            key={product.id}
            className="bg-white dark:bg-zinc-900 rounded-2xl p-3 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs flex space-x-3 rtl:space-x-reverse"
          >
            <img
              src={product.images[0]}
              alt={product.title}
              className="w-18 h-22 object-cover rounded-xl bg-zinc-100 dark:bg-zinc-800 shrink-0"
            />
            <div className="flex-1 min-w-0 flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between">
                  <span className="text-[10px] font-bold uppercase text-zinc-500 dark:text-zinc-400">
                    {product.brand}
                  </span>
                  <button
                    onClick={() => removeFromCart(product.id)}
                    className="text-zinc-400 hover:text-rose-500 p-0.5 cursor-pointer"
                    aria-label="Sil"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <h3 className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 line-clamp-1 mt-0.5">
                  {product.title}
                </h3>
                <div className="flex items-center space-x-2 rtl:space-x-reverse text-[10px] text-zinc-500 dark:text-zinc-400 mt-1">
                  <span>{t('size')}: <strong>{product.size}</strong></span>
                  <span>•</span>
                  <span>{product.city}</span>
                </div>
              </div>

              <div className="flex items-baseline justify-between pt-1">
                <span className="text-sm font-extrabold text-zinc-950 dark:text-zinc-50">
                  {product.price} <span className="text-[10px] text-amber-600 dark:text-amber-400">EGP</span>
                </span>
                <span className="text-[10px] text-zinc-600 dark:text-zinc-400 font-semibold bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded-md">
                  {product.seller.name}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Delivery Method Card (Only Hand Delivery / Local Pickup) */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs font-bold text-zinc-900 dark:text-zinc-100">
            <Users className="w-4 h-4 text-amber-500" />
            <span>{t('deliveryMethod')}</span>
          </div>
          <span className="bg-amber-500/15 text-amber-800 dark:text-amber-300 text-[11px] font-extrabold px-2.5 py-1 rounded-full border border-amber-500/30 shadow-2xs">
            {t('handDelivery')}
          </span>
        </div>

        <div className="bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/60 dark:border-zinc-700/60 rounded-xl p-3 text-xs space-y-1.5 text-zinc-800 dark:text-zinc-200">
          <div className="flex items-center space-x-1.5 rtl:space-x-reverse font-bold text-zinc-900 dark:text-zinc-100">
            <MessageSquare className="w-3.5 h-3.5 text-amber-500" />
            <span>
              {language === 'ar' ? 'الاتفاق عبر رسائل التطبيق' : language === 'en' ? 'Arranged via In-App Messages' : 'Uygulama İçi Mesajlaşma İle Buluşma'}
            </span>
          </div>
          <p className="text-[11px] leading-relaxed text-zinc-600 dark:text-zinc-300">
            {t('handDeliveryDesc')}
          </p>
          <p className="text-[10px] text-zinc-400 pt-1 border-t border-zinc-200 dark:border-zinc-700">
            {t('inAppOnlyNotice')}
          </p>
        </div>
      </div>

      {/* Order Summary & Escrow Protection */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/80 dark:border-zinc-800 space-y-2.5 text-xs">
        <h3 className="font-bold text-zinc-900 dark:text-zinc-100">
          {language === 'ar' ? 'ملخص الطلب' : language === 'en' ? 'Order Summary' : 'Sipariş Özeti'}
        </h3>

        <div className="space-y-1.5 border-b border-zinc-100 dark:border-zinc-800 pb-2 text-zinc-600 dark:text-zinc-300">
          <div className="flex justify-between">
            <span>{t('subtotal')}</span>
            <span className="font-medium text-zinc-900 dark:text-zinc-100">{subtotal} EGP</span>
          </div>
          <div className="flex justify-between items-center text-amber-600 dark:text-amber-400">
            <span className="flex items-center space-x-1 rtl:space-x-reverse">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{t('buyerProtectionTitle')}</span>
            </span>
            <span className="font-semibold">{buyerProtectionFee} EGP</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-zinc-600 dark:text-zinc-400">{t('deliveryMethod')}:</span>
            <span className="font-bold text-zinc-900 dark:text-zinc-100">{t('handDelivery')}</span>
          </div>
        </div>

        <div className="flex justify-between items-baseline pt-1">
          <span className="font-bold text-sm text-zinc-900 dark:text-zinc-100">
            {t('orderTotal')}
          </span>
          <span className="font-black text-base text-amber-600 dark:text-amber-400">
            {total} EGP
          </span>
        </div>

        {/* Guarantee Note */}
        <p className="text-[11px] text-zinc-500 dark:text-zinc-400 bg-zinc-50 dark:bg-zinc-800/40 p-2.5 rounded-xl leading-relaxed">
          {t('buyerProtectionDesc')}
        </p>
      </div>

      {/* Checkout Button */}
      <button
        onClick={createOrderFromCart}
        className="w-full py-3.5 bg-zinc-900 hover:bg-zinc-800 dark:bg-amber-500 dark:hover:bg-amber-400 text-white dark:text-zinc-950 rounded-xl font-bold text-xs shadow-md transition-colors flex items-center justify-center space-x-2 rtl:space-x-reverse cursor-pointer"
      >
        <span>{language === 'ar' ? 'تأكيد وإتمام الطلب' : language === 'en' ? 'Place Secure Order' : 'Güvenli Siparişi Tamamla'}</span>
        <ArrowRight className="w-4 h-4 rtl:rotate-180" />
      </button>
    </div>
  );
};
