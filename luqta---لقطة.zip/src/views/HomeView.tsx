import React from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from '../components/ProductCard';
import { CATEGORIES } from '../data/mockData';
import { ShieldCheck, Sparkles, Filter, MapPin } from 'lucide-react';
import { CategoryId } from '../types';

export const HomeView: React.FC = () => {
  const {
    products,
    selectedCategory,
    setSelectedCategory,
    selectedCity,
    setSelectedCity,
    searchQuery,
    language,
    t,
  } = useApp();

  const cities = [
    { id: 'all', name: { tr: 'Tüm Şehirler', en: 'All Egypt', ar: 'جميع المحافظات' } },
    { id: 'Cairo', name: { tr: 'Kahire (Cairo)', en: 'Cairo', ar: 'القاهرة' } },
    { id: 'New Cairo', name: { tr: 'Yeni Kahire (Tagamoa)', en: 'New Cairo', ar: 'القاهرة الجديدة' } },
    { id: 'Giza', name: { tr: 'Gize & Dokki', en: 'Giza & Dokki', ar: 'الجيزة والدقي' } },
    { id: 'Alexandria', name: { tr: 'İskenderiye', en: 'Alexandria', ar: 'الإسكندرية' } },
    { id: 'Mansoura', name: { tr: 'Mansure', en: 'Mansoura', ar: 'المنصورة' } },
  ];

  // Filter products by category, city, and search query
  const filteredProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesCity =
      selectedCity === 'all' || p.city.toLowerCase().includes(selectedCity.toLowerCase());
    const matchesSearch =
      !searchQuery.trim() ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesCity && matchesSearch;
  });

  return (
    <div className="space-y-4 pb-20">
      {/* Safety & In-App Guarantee Banner - Premium Anthracite & Warm Gold Tone */}
      <div className="bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 text-white rounded-2xl p-4 shadow-md border border-zinc-800/80 relative overflow-hidden">
        <div className="relative z-10 space-y-1.5">
          <div className="inline-flex items-center space-x-1.5 rtl:space-x-reverse bg-amber-500/15 backdrop-blur-xs px-2.5 py-1 rounded-full text-[11px] font-bold text-amber-300 border border-amber-400/30">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>{t('buyerProtectionTitle')}</span>
          </div>
          <h2 className="text-base font-extrabold tracking-tight text-zinc-50">
            {language === 'ar'
              ? 'تسوّق وبع ملابسك بأمان تام داخل مصر'
              : language === 'en'
              ? 'Buy & Sell Pre-loved Fashion Safely in Egypt'
              : 'Mısır’ın Güvenli Gardırop ve İkinci El Pazarı'}
          </h2>
          <p className="text-xs text-zinc-300 leading-relaxed max-w-sm">
            {t('inAppOnlyNotice')}
          </p>
        </div>
        {/* Subtle warm gold shimmer motif */}
        <div className="absolute -right-6 -bottom-8 w-28 h-28 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />
      </div>

      {/* City Governorates Filter Pills */}
      <div className="flex items-center space-x-1.5 rtl:space-x-reverse overflow-x-auto no-scrollbar py-0.5">
        <div className="flex items-center text-xs font-semibold text-zinc-400 pl-1 rtl:pl-0 rtl:pr-1 shrink-0">
          <MapPin className="w-3.5 h-3.5 mr-1 rtl:mr-0 rtl:ml-1 text-amber-500" />
        </div>
        {cities.map((city) => (
          <button
            key={city.id}
            onClick={() => setSelectedCity(city.id)}
            className={`px-3 py-1.5 text-xs font-medium rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              selectedCity === city.id
                ? 'bg-zinc-950 text-white dark:bg-amber-500 dark:text-zinc-950 font-bold shadow-2xs'
                : 'bg-white dark:bg-zinc-900 text-zinc-600 dark:text-zinc-300 border border-zinc-200/80 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800'
            }`}
          >
            {city.name[language] || city.name.tr}
          </button>
        ))}
      </div>

      {/* Category Pills Slider */}
      <div className="flex items-center space-x-2 rtl:space-x-reverse overflow-x-auto no-scrollbar py-1">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-full whitespace-nowrap transition-all flex items-center space-x-1.5 rtl:space-x-reverse cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-zinc-950 text-white dark:bg-amber-500 dark:text-zinc-950 shadow-xs font-bold'
                : 'bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 border border-zinc-200/90 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800'
            }`}
          >
            <span>{cat.name[language] || cat.name.tr}</span>
          </button>
        ))}
      </div>

      {/* Products Section Header */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">
            {language === 'ar' ? 'أحدث المعروضات' : language === 'en' ? 'Fresh Listings' : 'Öne Çıkan İlanlar'}
          </h2>
          <span className="text-xs text-zinc-500 dark:text-zinc-400 font-medium bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 rounded-full">
            {filteredProducts.length} {t('itemCount')}
          </span>
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-8 text-center space-y-3">
          <div className="w-12 h-12 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mx-auto text-zinc-400">
            <Filter className="w-6 h-6" />
          </div>
          <p className="text-sm font-semibold text-zinc-700 dark:text-zinc-300">
            {language === 'ar' ? 'لم نجد منتجات تطابق بحثك' : language === 'en' ? 'No items match your filter' : 'Aramanıza uygun ürün bulunamadı'}
          </p>
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSelectedCity('all');
            }}
            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline cursor-pointer"
          >
            {language === 'ar' ? 'إعادة ضبط الفلاتر' : language === 'en' ? 'Reset Filters' : 'Filtreleri Sıfırla'}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};
