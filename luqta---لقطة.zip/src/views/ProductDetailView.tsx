import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ArrowLeft,
  Heart,
  Share2,
  ShieldCheck,
  MapPin,
  Star,
  CheckCircle,
  MessageCircle,
  ShoppingBag,
  Info,
  Users,
  Crown,
  Zap,
  Sparkles,
} from 'lucide-react';

export const ProductDetailView: React.FC = () => {
  const {
    activeProductId,
    setActiveProductId,
    products,
    favorites,
    toggleFavorite,
    addToCart,
    startChatWithSeller,
    setActiveSeller,
    openPromoteModal,
    language,
    t,
  } = useApp();

  const [activeImageIdx, setActiveImageIdx] = useState(0);

  const product = products.find((p) => p.id === activeProductId);

  if (!product) return null;

  const isFav = favorites.includes(product.id);

  const getConditionLabel = (cond: typeof product.condition) => {
    switch (cond) {
      case 'new_with_tag':
        return language === 'ar' ? 'جديد بالتاغ الأصلي' : language === 'en' ? 'New with tag' : 'Etiketli Sıfır Ürün';
      case 'like_new':
        return language === 'ar' ? 'كالجديد تماماً (بلا عيوب)' : language === 'en' ? 'Like new (Flawless)' : 'Yeni Gibi (Kusursuz)';
      case 'good':
        return language === 'ar' ? 'حالة جيدة جداً' : language === 'en' ? 'Good condition' : 'İyi Durumda';
      default:
        return language === 'ar' ? 'مستعمل' : language === 'en' ? 'Pre-loved' : 'Kullanılmış';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-white dark:bg-zinc-950 flex flex-col overflow-hidden animate-slide-up text-zinc-900 dark:text-zinc-100 transition-colors">
      {/* Top Header with Global Safe Area padding */}
      <div
        className="sticky top-0 z-20 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md border-b border-zinc-200/80 dark:border-zinc-800/80 flex items-center justify-between px-4 pb-3"
        style={{
          paddingTop: 'max(env(safe-area-inset-top, 0px), 12px)',
        }}
      >
        <button
          onClick={() => setActiveProductId(null)}
          className="w-9 h-9 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors cursor-pointer"
          aria-label="Geri"
        >
          <ArrowLeft className="w-5 h-5 rtl:rotate-180" />
        </button>

        <h1 className="text-xs font-bold text-zinc-900 dark:text-zinc-100 truncate max-w-[200px]">
          {product.brand}
        </h1>

        <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
          <button
            onClick={() => toggleFavorite(product.id)}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
              isFav
                ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-500'
                : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:text-rose-500'
            }`}
            aria-label="Favori"
          >
            <Heart className={`w-5 h-5 ${isFav ? 'fill-rose-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto pb-28">
        {/* Product Images */}
        <div className="relative aspect-square w-full bg-zinc-100 dark:bg-zinc-900">
          <img
            src={product.images[activeImageIdx] || product.images[0]}
            alt={product.title}
            className="w-full h-full object-cover"
          />

          {/* Boosted / Featured badge on product detail */}
          {product.isBoosted && (
            <div className="absolute top-3 left-3 rtl:left-auto rtl:right-3">
              <span className="bg-gradient-to-r from-amber-500 to-amber-600 text-zinc-950 text-[10px] font-black px-2 py-0.5 rounded-md shadow-md flex items-center space-x-1 rtl:space-x-reverse">
                <Sparkles className="w-3 h-3" />
                <span>{t('boostedBadge')}</span>
              </span>
            </div>
          )}

          {/* Dots Indicator */}
          {product.images.length > 1 && (
            <div className="absolute bottom-3 left-0 right-0 flex justify-center space-x-1.5 rtl:space-x-reverse">
              {product.images.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`w-2 h-2 rounded-full transition-all cursor-pointer ${
                    activeImageIdx === idx ? 'bg-amber-500 w-5' : 'bg-white/80 dark:bg-zinc-700'
                  }`}
                />
              ))}
            </div>
          )}
        </div>

        {/* Details Section */}
        <div className="p-4 space-y-4">
          {/* Price & Title */}
          <div>
            <div className="flex items-baseline space-x-2 rtl:space-x-reverse">
              <span className="text-2xl font-black text-zinc-950 dark:text-zinc-50">
                {product.price}{' '}
                <span className="text-base font-bold text-amber-600 dark:text-amber-400">EGP</span>
              </span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-sm text-zinc-400 dark:text-zinc-500 line-through">
                  {product.originalPrice} EGP
                </span>
              )}
            </div>

            <h2 className="text-base font-semibold text-zinc-900 dark:text-zinc-100 mt-1 leading-snug">
              {product.title}
            </h2>

            <div className="flex items-center space-x-2 rtl:space-x-reverse mt-2 text-xs text-zinc-500 dark:text-zinc-400">
              <div className="flex items-center space-x-1 rtl:space-x-reverse">
                <MapPin className="w-3.5 h-3.5 text-zinc-400" />
                <span>{product.city}</span>
              </div>
              <span>•</span>
              <span>{product.createdAt}</span>
            </div>
          </div>

          {/* Key Attribute Badges */}
          <div className="grid grid-cols-3 gap-2 bg-zinc-50 dark:bg-zinc-900 p-3 rounded-2xl border border-zinc-200/80 dark:border-zinc-800 text-center">
            <div className="space-y-0.5">
              <span className="text-[10px] text-zinc-400 uppercase font-medium tracking-wider">
                {t('brand')}
              </span>
              <p className="text-xs font-bold text-zinc-900 dark:text-zinc-100 truncate">{product.brand}</p>
            </div>
            <div className="space-y-0.5 border-x border-zinc-200 dark:border-zinc-800">
              <span className="text-[10px] text-zinc-400 uppercase font-medium tracking-wider">
                {t('size')}
              </span>
              <p className="text-xs font-bold text-zinc-900 dark:text-zinc-100">{product.size}</p>
            </div>
            <div className="space-y-0.5">
              <span className="text-[10px] text-zinc-400 uppercase font-medium tracking-wider">
                {t('condition')}
              </span>
              <p className="text-xs font-bold text-amber-600 dark:text-amber-400 truncate">
                {getConditionLabel(product.condition)}
              </p>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <h3 className="text-xs font-bold text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
              {language === 'ar' ? 'تفاصيل المنتج' : language === 'en' ? 'Item Details' : 'Ürün Açıklaması'}
            </h3>
            <p className="text-xs text-zinc-700 dark:text-zinc-300 leading-relaxed whitespace-pre-line bg-zinc-50 dark:bg-zinc-900/60 p-3 rounded-xl border border-zinc-200/60 dark:border-zinc-800">
              {product.description}
            </p>
          </div>

          {/* Delivery Method Badge (Elden Teslim / Hand Delivery Only) */}
          <div className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl p-3 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2 rtl:space-x-reverse text-zinc-700 dark:text-zinc-300">
              <Users className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span className="font-bold">{t('deliveryMethod')}:</span>
            </div>
            <span className="bg-amber-500/15 text-amber-800 dark:text-amber-300 text-[11px] font-extrabold px-2.5 py-1 rounded-full border border-amber-500/30">
              {t('handDelivery')}
            </span>
          </div>

          {/* Boost / Promote Quick Action (If owned or for promotion) */}
          <div className="bg-gradient-to-r from-zinc-900 to-zinc-950 p-3 rounded-2xl border border-zinc-800 text-white flex items-center justify-between">
            <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
              <div className="p-1.5 bg-amber-500/20 rounded-xl text-amber-400">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">{t('promoteProduct')}</h4>
                <p className="text-[10px] text-zinc-400">
                  {language === 'ar' ? 'ضاعف المشاهدات والمبيعات' : language === 'en' ? 'Boost views up to 3x' : '3 günde hızlı satış yapın'}
                </p>
              </div>
            </div>
            <button
              onClick={() => openPromoteModal(product)}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-zinc-950 rounded-xl font-bold text-[11px] cursor-pointer transition-colors"
            >
              {language === 'ar' ? 'تمييز الآن' : language === 'en' ? 'Boost' : 'Öne Çıkar'}
            </button>
          </div>

          {/* Seller Section - Strict Privacy: Only Display Name, Photo, City, Rating, Listing Count */}
          <div className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300">
                {t('sellerProfile')}
              </span>
              <button
                onClick={() => setActiveSeller(product.seller)}
                className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline cursor-pointer"
              >
                {language === 'ar' ? 'عرض الملف' : language === 'en' ? 'View Profile' : 'Profili Gör'}
              </button>
            </div>

            <div className="flex items-center space-x-3 rtl:space-x-reverse">
              <div className="relative">
                <img
                  src={product.seller.avatar}
                  alt={product.seller.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-white dark:border-zinc-800 shadow-2xs"
                />
                {product.seller.isSuperSeller && (
                  <span className="absolute -bottom-1 -right-1 bg-amber-500 text-zinc-950 p-0.5 rounded-full shadow-xs">
                    <Crown className="w-3 h-3" />
                  </span>
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
                  <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">{product.seller.name}</h4>
                  {product.seller.isSuperSeller && (
                    <span className="text-[9px] font-black uppercase bg-amber-500/20 text-amber-700 dark:text-amber-400 px-1 py-0.2 rounded-xs">
                      {t('superSeller')}
                    </span>
                  )}
                  {product.seller.verified && (
                    <CheckCircle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  )}
                </div>
                <p className="text-[11px] text-zinc-500 dark:text-zinc-400">{product.seller.city}</p>
                <div className="flex items-center space-x-2 rtl:space-x-reverse mt-1 text-[11px]">
                  <span className="flex items-center text-amber-600 dark:text-amber-400 font-bold">
                    <Star className="w-3 h-3 fill-amber-400 stroke-amber-400 mr-0.5" />
                    {product.seller.rating} ({product.seller.ratingCount})
                  </span>
                  <span className="text-zinc-300 dark:text-zinc-700">•</span>
                  <span className="text-zinc-600 dark:text-zinc-400 font-medium">
                    {product.seller.listingCount} {t('listings')}
                  </span>
                </div>
              </div>
            </div>

            {/* In-App Direct Message CTA with Seller */}
            <button
              onClick={() => {
                setActiveProductId(null);
                startChatWithSeller(product);
              }}
              className="w-full py-2.5 bg-white dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 rtl:space-x-reverse transition-colors cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 text-amber-500" />
              <span>{t('sendMessage')}</span>
            </button>
          </div>

          {/* Luqta Buyer Protection Guarantee Banner */}
          <div className="bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-3.5 flex items-start space-x-3 rtl:space-x-reverse">
            <ShieldCheck className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <span className="font-bold text-zinc-900 dark:text-zinc-100 block">
                {t('buyerProtectionTitle')}
              </span>
              <p className="text-zinc-600 dark:text-zinc-400 leading-relaxed">
                {t('buyerProtectionDesc')} {t('inAppOnlyNotice')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Actions Bar with Safe Area Bottom */}
      <div
        className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md border-t border-zinc-200 dark:border-zinc-800 px-4 pt-3 shadow-lg"
        style={{
          paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 12px)',
        }}
      >
        <div className="max-w-md mx-auto grid grid-cols-2 gap-3">
          <button
            onClick={() => {
              setActiveProductId(null);
              startChatWithSeller(product);
            }}
            className="py-3 px-4 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 rtl:space-x-reverse transition-colors cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 text-amber-500" />
            <span>{t('sendMessage')}</span>
          </button>

          <button
            onClick={() => {
              addToCart(product);
              setActiveProductId(null);
            }}
            className="py-3 px-4 bg-zinc-900 hover:bg-zinc-800 dark:bg-amber-500 dark:hover:bg-amber-400 text-white dark:text-zinc-950 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 rtl:space-x-reverse transition-colors shadow-md cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>{t('addToCart')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
