import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CategoryId, ProductCondition } from '../types';
import { CATEGORIES } from '../data/mockData';
import { Camera, ShieldAlert, Sparkles, Check, AlertCircle, Users } from 'lucide-react';
import { validateContactInfo } from '../utils/filter';

const SAMPLE_IMAGES = [
  'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=800&auto=format&fit=crop&q=80',
];

export const AddProductView: React.FC = () => {
  const { addNewProduct, language, t } = useApp();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [category, setCategory] = useState<CategoryId>('women');
  const [brand, setBrand] = useState('Zara');
  const [size, setSize] = useState('M / 38');
  const [condition, setCondition] = useState<ProductCondition>('like_new');
  const [city, setCity] = useState('Cairo (New Cairo)');
  const [selectedPhoto, setSelectedPhoto] = useState(SAMPLE_IMAGES[0]);
  const [formError, setFormError] = useState<string | null>(null);

  // Real-time contact validation on description change
  const descValidation = validateContactInfo(description);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim() || !description.trim() || !price) {
      setFormError('Lütfen tüm zorunlu alanları doldurun.');
      return;
    }

    const priceNum = parseFloat(price);
    if (isNaN(priceNum) || priceNum <= 0) {
      setFormError('Lütfen geçerli bir fiyat girin.');
      return;
    }

    const res = addNewProduct({
      title: title.trim(),
      description: description.trim(),
      price: priceNum,
      originalPrice: originalPrice ? parseFloat(originalPrice) : undefined,
      category,
      brand: brand.trim(),
      size: size.trim(),
      condition,
      city,
      images: [selectedPhoto],
    });

    if (!res.success) {
      setFormError(t('warningExternalBlocked'));
    }
  };

  return (
    <div className="space-y-4 pb-28 text-zinc-900 dark:text-zinc-100">
      {/* Page Header */}
      <div className="pb-1">
        <h1 className="text-base font-extrabold text-zinc-900 dark:text-zinc-100 tracking-tight">
          {t('newListingTitle')}
        </h1>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          {language === 'ar'
            ? 'اعرض ملابسك للبيع بسهولة وأمان في مصر'
            : language === 'en'
            ? 'List your pre-loved fashion quickly and securely'
            : 'Dolabınızdaki ürünleri güvenle yeni sahipleriyle buluşturun'}
        </p>
      </div>

      {/* Mandatory Safety Notice regarding External Contacts */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-3.5 flex items-start space-x-3 rtl:space-x-reverse">
        <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs space-y-1">
          <span className="font-bold text-zinc-900 dark:text-zinc-100 block">
            {t('warningExternalBlocked')}
          </span>
          <p className="text-zinc-600 dark:text-zinc-400 leading-relaxed">
            {t('warningBlockedDesc')}
          </p>
        </div>
      </div>

      {formError && (
        <div className="bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl p-3 text-xs text-rose-800 dark:text-rose-200 flex items-center space-x-2 rtl:space-x-reverse">
          <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
          <span className="font-semibold">{formError}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Photo Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
            {language === 'ar' ? 'صور المنتج' : language === 'en' ? 'Product Photos' : 'Ürün Fotoğrafı Seç'}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {SAMPLE_IMAGES.map((imgUrl, idx) => (
              <div
                key={idx}
                onClick={() => setSelectedPhoto(imgUrl)}
                className={`relative aspect-square rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                  selectedPhoto === imgUrl
                    ? 'border-amber-500 ring-2 ring-amber-500/30'
                    : 'border-zinc-200 dark:border-zinc-700 hover:border-zinc-300 dark:hover:border-zinc-600'
                }`}
              >
                <img src={imgUrl} alt="Sample" className="w-full h-full object-cover" />
                {selectedPhoto === imgUrl && (
                  <div className="absolute top-1 right-1 rtl:right-auto rtl:left-1 bg-amber-500 text-zinc-950 rounded-full p-0.5 shadow-xs">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Title */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
            {t('titleLabel')} *
          </label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Örn: Zara Çiçek Desenli Keten Elbise"
            className="w-full bg-white dark:bg-zinc-850 text-xs text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2.5 outline-hidden focus:border-amber-500 focus:ring-2 focus:ring-amber-500/10"
          />
        </div>

        {/* Description with Real-time Contact Filter Indicator */}
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200">
              {t('descriptionLabel')} *
            </label>
            {descValidation.hasViolation && (
              <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/50 px-2 py-0.5 rounded-full border border-rose-200 dark:border-rose-800">
                Engellenen Bilgi Tespit Edildi
              </span>
            )}
          </div>
          <textarea
            required
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={
              language === 'ar'
                ? 'اكتب وصفاً دقيقاً للمنتج وحالته (يُمنع كتابة أرقام الهواتف أو واتساب)...'
                : language === 'en'
                ? 'Describe condition, fabric and fit (Sharing phone or WhatsApp is blocked)...'
                : 'Ürünün durumunu, kumaşını ve beden detaylarını yazın (Telefon, WhatsApp vb. paylaşılamaz)...'
            }
            className={`w-full bg-white dark:bg-zinc-850 text-xs text-zinc-900 dark:text-zinc-100 border rounded-xl px-3.5 py-2.5 outline-hidden transition-colors ${
              descValidation.hasViolation
                ? 'border-rose-400 bg-rose-50/20 dark:bg-rose-950/20 focus:border-rose-600 focus:ring-2 focus:ring-rose-500/10'
                : 'border-zinc-200 dark:border-zinc-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/10'
            }`}
          />
          {descValidation.hasViolation && (
            <p className="text-[11px] text-rose-600 dark:text-rose-400 font-medium">
              {t('warningExternalBlocked')} ({descValidation.matchedText})
            </p>
          )}
        </div>

        {/* Category & Brand */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
              {t('categoryLabel')}
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as CategoryId)}
              className="w-full bg-white dark:bg-zinc-850 text-xs text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2.5 outline-hidden focus:border-amber-500 cursor-pointer"
            >
              {CATEGORIES.filter((c) => c.id !== 'all').map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name[language] || c.name.tr}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
              {t('brand')}
            </label>
            <input
              type="text"
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              placeholder="Zara, Massimo Dutti..."
              className="w-full bg-white dark:bg-zinc-850 text-xs text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2.5 outline-hidden focus:border-amber-500"
            />
          </div>
        </div>

        {/* Condition & Size */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
              {t('condition')}
            </label>
            <select
              value={condition}
              onChange={(e) => setCondition(e.target.value as ProductCondition)}
              className="w-full bg-white dark:bg-zinc-850 text-xs text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2.5 outline-hidden focus:border-amber-500 cursor-pointer"
            >
              <option value="new_with_tag">Yeni & Etiketli</option>
              <option value="like_new">Yeni Gibi (Kusursuz)</option>
              <option value="good">İyi Durumda</option>
              <option value="fair">Kullanılmış</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
              {t('size')}
            </label>
            <input
              type="text"
              value={size}
              onChange={(e) => setSize(e.target.value)}
              placeholder="S, M, L, 38, 42..."
              className="w-full bg-white dark:bg-zinc-850 text-xs text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2.5 outline-hidden focus:border-amber-500"
            />
          </div>
        </div>

        {/* Price & Original Price */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
              {t('priceLabel')} *
            </label>
            <div className="relative">
              <input
                type="number"
                required
                min="1"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="450"
                className="w-full bg-white dark:bg-zinc-850 text-xs font-bold text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2.5 outline-hidden focus:border-amber-500"
              />
              <span className="absolute right-3 rtl:right-auto rtl:left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-zinc-400">
                EGP
              </span>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
              {t('originalPriceLabel')}
            </label>
            <div className="relative">
              <input
                type="number"
                min="1"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(e.target.value)}
                placeholder="1200"
                className="w-full bg-white dark:bg-zinc-850 text-xs text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3.5 py-2.5 outline-hidden focus:border-amber-500"
              />
              <span className="absolute right-3 rtl:right-auto rtl:left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-zinc-400">
                EGP
              </span>
            </div>
          </div>
        </div>

        {/* City Location */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
            {t('cityLabel')}
          </label>
          <select
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="w-full bg-white dark:bg-zinc-850 text-xs text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2.5 outline-hidden focus:border-amber-500 cursor-pointer"
          >
            <option value="Cairo (Maadi)">Cairo (Maadi)</option>
            <option value="Cairo (New Cairo)">New Cairo (Fifth Settlement)</option>
            <option value="Cairo (Zamalek)">Cairo (Zamalek)</option>
            <option value="Cairo (Nasr City)">Cairo (Nasr City)</option>
            <option value="Giza (Dokki)">Giza (Dokki)</option>
            <option value="Giza (Zayed City)">Giza (Sheikh Zayed)</option>
            <option value="Alexandria (Smouha)">Alexandria (Smouha)</option>
            <option value="Mansoura">Mansoura</option>
          </select>
        </div>

        {/* Automatic Hand Delivery Indicator */}
        <div className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-xl p-3 flex items-start space-x-2.5 rtl:space-x-reverse text-xs">
          <div className="p-1 bg-amber-500/15 text-amber-600 dark:text-amber-400 rounded-lg shrink-0 mt-0.5">
            <Users className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
              <span className="font-bold text-zinc-800 dark:text-zinc-200">{t('deliveryMethod')}:</span>
              <span className="font-extrabold text-amber-800 dark:text-amber-300 bg-amber-500/15 px-2 py-0.5 rounded-md border border-amber-500/30">
                {t('handDelivery')}
              </span>
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1 leading-relaxed">
              {t('handDeliveryDesc')}
            </p>
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className="w-full py-3.5 bg-zinc-900 hover:bg-zinc-800 dark:bg-amber-500 dark:hover:bg-amber-400 text-white dark:text-zinc-950 rounded-xl font-bold text-xs shadow-md transition-colors cursor-pointer mt-2"
        >
          {t('publishListing')}
        </button>
      </form>
    </div>
  );
};
