import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Package,
  Heart,
  Shirt,
  ShieldCheck,
  Globe,
  Lock,
  ChevronRight,
  Users,
  MessageSquare,
  AlertOctagon,
  Crown,
  Zap,
  TrendingUp,
  Sun,
  Moon,
  Laptop,
  Sparkles,
  ArrowUpRight,
} from 'lucide-react';
import { ThemeMode } from '../types';

export const MenuView: React.FC = () => {
  const {
    language,
    setLanguage,
    themeMode,
    setThemeMode,
    orders,
    products,
    favorites,
    setActiveProductId,
    setActiveTab,
    startChatWithSeller,
    isUserSuperSeller,
    setIsSuperSellerModalOpen,
    openPromoteModal,
    setIsRevenueModalOpen,
    t,
  } = useApp();

  const [activeSubView, setActiveSubView] = useState<
    'main' | 'orders' | 'wardrobe' | 'favorites' | 'safety'
  >('main');

  // Filter user's own listings
  const myListings = products.filter((p) => p.seller.id === 'current_user');
  const favProducts = products.filter((p) => favorites.includes(p.id));

  if (activeSubView === 'orders') {
    return (
      <div className="space-y-4 pb-24 animate-fade-in">
        <div className="flex items-center space-x-2 rtl:space-x-reverse pb-1">
          <button
            onClick={() => setActiveSubView('main')}
            className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 cursor-pointer"
          >
            <ChevronRight className="w-4 h-4 rotate-180 rtl:rotate-0" />
          </button>
          <h1 className="text-base font-bold text-zinc-900 dark:text-zinc-100">{t('myOrders')}</h1>
        </div>

        {orders.length === 0 ? (
          <div className="bg-white dark:bg-zinc-900 rounded-2xl p-8 border border-zinc-200 dark:border-zinc-800 text-center text-xs text-zinc-500 dark:text-zinc-400">
            {language === 'ar'
              ? 'لا توجد طلبات سابقة حتى الآن.'
              : language === 'en'
              ? 'You do not have any orders yet.'
              : 'Henüz bir siparişiniz bulunmuyor.'}
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map((ord) => (
              <div
                key={ord.id}
                className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs space-y-3"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-zinc-900 dark:text-zinc-100">{ord.id}</span>
                  <span className="bg-amber-500/15 text-amber-700 dark:text-amber-400 font-semibold px-2.5 py-0.5 rounded-full border border-amber-500/30 text-[11px]">
                    {t('handDelivery')}
                  </span>
                </div>

                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <img
                    src={ord.product.images[0]}
                    alt={ord.product.title}
                    className="w-14 h-14 rounded-xl object-cover border border-zinc-200 dark:border-zinc-800"
                  />
                  <div className="flex-1 min-w-0 text-xs">
                    <h3 className="font-bold text-zinc-900 dark:text-zinc-100 truncate">
                      {ord.product.title}
                    </h3>
                    <p className="text-zinc-500 dark:text-zinc-400 mt-0.5">
                      {ord.amount} EGP • {ord.date}
                    </p>
                    <div className="mt-1 flex items-center space-x-1.5 rtl:space-x-reverse text-[11px] text-zinc-700 dark:text-zinc-300 font-medium">
                      <Users className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                      <span>{t('handDelivery')} ({ord.meetingCity || ord.product.city})</span>
                    </div>
                  </div>
                </div>

                {/* Direct in-app meeting arrangement CTA */}
                <button
                  onClick={() => {
                    startChatWithSeller(ord.product);
                  }}
                  className="w-full py-2.5 bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-white rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 rtl:space-x-reverse transition-colors cursor-pointer shadow-xs"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
                  <span>
                    {language === 'ar'
                      ? 'تنسيق المقابلة عبر الرسائل'
                      : language === 'en'
                      ? 'Arrange Meet-up via Chat'
                      : 'Buluşma Noktası Ayarla (Mesajlar)'}
                  </span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (activeSubView === 'wardrobe') {
    return (
      <div className="space-y-4 pb-24 animate-fade-in">
        <div className="flex items-center space-x-2 rtl:space-x-reverse pb-1">
          <button
            onClick={() => setActiveSubView('main')}
            className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 cursor-pointer"
          >
            <ChevronRight className="w-4 h-4 rotate-180 rtl:rotate-0" />
          </button>
          <h1 className="text-base font-bold text-zinc-900 dark:text-zinc-100">
            {t('myWardrobe')} ({myListings.length})
          </h1>
        </div>

        {myListings.length === 0 ? (
          <div className="bg-white dark:bg-zinc-900 rounded-2xl p-8 border border-zinc-200 dark:border-zinc-800 text-center space-y-3">
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              {language === 'ar'
                ? 'لم تقم بإضافة أي منتج للبيع بعد.'
                : language === 'en'
                ? 'You have not listed any items for sale yet.'
                : 'Henüz satışta bir ürününüz bulunmuyor.'}
            </p>
            <button
              onClick={() => setActiveTab('add')}
              className="px-4 py-2 bg-zinc-950 dark:bg-amber-500 text-white dark:text-zinc-950 rounded-xl text-xs font-bold cursor-pointer transition-colors"
            >
              {t('tabAdd')}
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {myListings.map((p) => (
              <div
                key={p.id}
                className="bg-white dark:bg-zinc-900 rounded-2xl p-3 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs flex items-center space-x-3 rtl:space-x-reverse"
              >
                <img
                  src={p.images[0]}
                  alt={p.title}
                  className="w-16 h-18 rounded-xl object-cover bg-zinc-100 dark:bg-zinc-800 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
                    <span className="text-[10px] font-bold uppercase text-zinc-500 dark:text-zinc-400">
                      {p.brand}
                    </span>
                    {p.isBoosted && (
                      <span className="text-[9px] font-black bg-amber-500/15 text-amber-700 dark:text-amber-400 px-1.5 py-0.5 rounded-sm">
                        {t('boostedBadge')}
                      </span>
                    )}
                  </div>
                  <h3 className="text-xs font-bold text-zinc-900 dark:text-zinc-100 truncate mt-0.5">
                    {p.title}
                  </h3>
                  <p className="text-zinc-950 dark:text-zinc-100 font-extrabold mt-0.5 text-xs">
                    {p.price} EGP
                  </p>

                  <div className="flex items-center space-x-2 rtl:space-x-reverse mt-2">
                    <button
                      onClick={() => setActiveProductId(p.id)}
                      className="px-2.5 py-1 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 rounded-lg text-[11px] font-semibold cursor-pointer"
                    >
                      {language === 'ar' ? 'عرض' : language === 'en' ? 'View' : 'Görüntüle'}
                    </button>
                    <button
                      onClick={() => openPromoteModal(p)}
                      className="px-2.5 py-1 bg-amber-500/15 hover:bg-amber-500/25 text-amber-700 dark:text-amber-400 border border-amber-500/30 rounded-lg text-[11px] font-bold flex items-center space-x-1 rtl:space-x-reverse cursor-pointer transition-colors"
                    >
                      <Zap className="w-3 h-3 text-amber-500" />
                      <span>{t('promoteProduct')}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (activeSubView === 'favorites') {
    return (
      <div className="space-y-4 pb-24 animate-fade-in">
        <div className="flex items-center space-x-2 rtl:space-x-reverse pb-1">
          <button
            onClick={() => setActiveSubView('main')}
            className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 cursor-pointer"
          >
            <ChevronRight className="w-4 h-4 rotate-180 rtl:rotate-0" />
          </button>
          <h1 className="text-base font-bold text-zinc-900 dark:text-zinc-100">
            {t('favorites')} ({favProducts.length})
          </h1>
        </div>

        {favProducts.length === 0 ? (
          <div className="bg-white dark:bg-zinc-900 rounded-2xl p-8 border border-zinc-200 dark:border-zinc-800 text-center text-xs text-zinc-500 dark:text-zinc-400">
            {language === 'ar'
              ? 'لم تقم بحفظ أي منتجات في المفضلة بعد.'
              : language === 'en'
              ? 'No favorite items saved yet.'
              : 'Favorilerinize henüz ürün eklemediniz.'}
          </div>
        ) : (
          <div className="space-y-2.5">
            {favProducts.map((p) => (
              <div
                key={p.id}
                onClick={() => setActiveProductId(p.id)}
                className="bg-white dark:bg-zinc-900 rounded-2xl p-3 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs flex items-center space-x-3 rtl:space-x-reverse cursor-pointer hover:border-amber-400/50 transition-colors"
              >
                <img
                  src={p.images[0]}
                  alt={p.title}
                  className="w-16 h-18 rounded-xl object-cover bg-zinc-100 dark:bg-zinc-800 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-bold uppercase text-zinc-500 dark:text-zinc-400">
                    {p.brand}
                  </span>
                  <h3 className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 truncate mt-0.5">
                    {p.title}
                  </h3>
                  <p className="text-zinc-950 dark:text-zinc-100 font-extrabold mt-0.5 text-xs">
                    {p.price} EGP
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (activeSubView === 'safety') {
    return (
      <div className="space-y-4 pb-24 animate-fade-in">
        <div className="flex items-center space-x-2 rtl:space-x-reverse pb-1">
          <button
            onClick={() => setActiveSubView('main')}
            className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-200 cursor-pointer"
          >
            <ChevronRight className="w-4 h-4 rotate-180 rtl:rotate-0" />
          </button>
          <h1 className="text-base font-bold text-zinc-900 dark:text-zinc-100">{t('safetyRules')}</h1>
        </div>

        {/* Safety Rule Details */}
        <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/80 dark:border-zinc-800 space-y-4 text-xs leading-relaxed text-zinc-700 dark:text-zinc-300">
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 flex items-start space-x-2.5 rtl:space-x-reverse">
            <AlertOctagon className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-zinc-900 dark:text-zinc-100 text-xs">
                {t('warningExternalBlocked')}
              </p>
              <p className="text-[11px] text-zinc-600 dark:text-zinc-400 mt-1">
                {language === 'ar'
                  ? 'يمنع مشاركة أرقام الهواتف أو واتساب لحماية الطرفين من النصب والاحتيال.'
                  : language === 'en'
                  ? 'Sharing phone numbers or WhatsApp is prohibited to protect both parties against fraud.'
                  : 'Dolandırıcılık ve sahte dekont risklerine karşı harici iletişim paylaşımı yasaktır.'}
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <h2 className="font-bold text-zinc-900 dark:text-zinc-100 text-xs">
              LUQTA Güvenlik ve Gizlilik Standartları:
            </h2>
            <ul className="space-y-2 list-disc pl-4 rtl:pl-0 rtl:pr-4 text-zinc-600 dark:text-zinc-400">
              <li>
                <strong>Yalnızca Uygulama İçi İletişim:</strong> Alıcı ve satıcı arasındaki tüm soru-cevap, pazarlık ve teklifler LUQTA mesajlaşma panelinden yapılmalıdır.
              </li>
              <li>
                <strong>Harici Bilgi Yasağı:</strong> Telefon numarası (010, 011, 012, 015, +20, +90), WhatsApp bağlantıları, Telegram ve e-posta adresleri paylaşımı otomatik filtre ile engellenir.
              </li>
              <li>
                <strong>Profil Gizliliği:</strong> Kullanıcı profillerinde yalnızca görünen isim, şehir ve satıcı puanı yer alır. Telefon ve e-posta asla gösterilmez.
              </li>
              <li>
                <strong>Alıcı Koruması:</strong> Ödemeniz ürün elinize ulaşıp durumu onaylanana kadar havuz hesabında güvende tutulur.
              </li>
              <li>
                <strong>Yalnızca Elden Teslim:</strong> Platformumuzda kargo veya kurye teslimatı kullanılmaz. Tüm teslimatlar yüz yüze elden teslim olarak yapılır. Buluşma yeri ve zamanı yalnızca uygulama içi Mesajlar bölümünden kararlaştırılır.
              </li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  // MAIN MENU SCREEN
  return (
    <div className="space-y-4 pb-28">
      {/* User Profile Card (Strict Privacy: Only Display Name, Photo, City, Rating, Listing count) */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs space-y-3">
        <div className="flex items-center space-x-3.5 rtl:space-x-reverse">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop&crop=faces"
              alt="Kadir Aslan"
              className="w-14 h-14 rounded-full object-cover border-2 border-zinc-200 dark:border-zinc-700"
            />
            {isUserSuperSeller && (
              <span className="absolute -bottom-1 -right-1 bg-amber-500 text-zinc-950 p-1 rounded-full shadow-xs">
                <Crown className="w-3 h-3" />
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
              <h2 className="text-sm font-extrabold text-zinc-900 dark:text-zinc-100">Kadir Aslan</h2>
              {isUserSuperSeller && (
                <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-700 dark:text-amber-400 px-1.5 py-0.5 rounded-sm">
                  {t('superSeller')}
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">Cairo (New Cairo)</p>
            <div className="flex items-center space-x-2 rtl:space-x-reverse mt-1 text-[11px]">
              <span className="font-bold text-amber-600 dark:text-amber-400">★ 5.0 (12)</span>
              <span className="text-zinc-300 dark:text-zinc-700">•</span>
              <span className="text-zinc-600 dark:text-zinc-400 font-medium">3 {t('listings')}</span>
            </div>
          </div>
        </div>

        <div className="bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-100 dark:border-zinc-800 rounded-xl p-2.5 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-1.5 rtl:space-x-reverse text-zinc-700 dark:text-zinc-300">
            <ShieldCheck className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span className="font-semibold">{t('verifiedSeller')}</span>
          </div>
          <span className="text-[10px] text-zinc-800 dark:text-zinc-200 font-bold bg-zinc-200/80 dark:bg-zinc-700 px-2 py-0.5 rounded-md">
            Aktif
          </span>
        </div>
      </div>

      {/* MONETIZATION FEATURE: Super Seller Subscription Banner Card */}
      <div className="bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 text-white rounded-2xl p-4 border border-zinc-800 shadow-md relative overflow-hidden">
        <div className="relative z-10 space-y-2">
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center space-x-1.5 rtl:space-x-reverse bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2.5 py-0.5 rounded-full text-[10px] font-bold">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>{t('superSeller')} VIP</span>
            </div>
            {isUserSuperSeller && (
              <span className="bg-amber-500/20 text-amber-300 text-[10px] font-black px-2 py-0.5 rounded-full border border-amber-400/40">
                AKTİF ÜYELİK
              </span>
            )}
          </div>

          <div>
            <h3 className="text-sm font-extrabold text-white">
              {isUserSuperSeller
                ? (language === 'ar' ? 'أنت بائع مميز حالياً!' : language === 'en' ? 'You are a Super Seller!' : 'Süper Satıcı Ayrıcalıklarınız Aktif!')
                : (language === 'ar' ? 'ارتقِ بحسابك إلى بائع مميز' : language === 'en' ? 'Upgrade to Super Seller' : 'Süper Satıcı ile Satışlarını Katla')}
            </h3>
            <p className="text-[11px] text-zinc-400 leading-relaxed mt-0.5">
              {language === 'ar'
                ? 'شارة ذهبية مميزة، أولوية في البحث، ومبيعات أسرع 3 مرات عبر اشتراك Google Play.'
                : language === 'en'
                ? 'Gold crown badge, search priority and 3x faster sales with Google Play Billing.'
                : 'Özel altın rozet, arama zirvesi ve 3 kat daha hızlı satış güvencesi.'}
            </p>
          </div>

          <button
            onClick={() => setIsSuperSellerModalOpen(true)}
            className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 rounded-xl text-xs font-black flex items-center justify-center space-x-1.5 rtl:space-x-reverse transition-all shadow-sm cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>
              {isUserSuperSeller
                ? (language === 'ar' ? 'إدارة الاشتراك والمزايا' : language === 'en' ? 'Manage Subscription' : 'Abonelik Detaylarını Gör')
                : (language === 'ar' ? 'اشترك الآن (من 199 ج.م)' : language === 'en' ? 'Upgrade Now (from 199 EGP)' : 'Süper Satıcı Ol (199 EGP/ay)')}
            </span>
          </button>
        </div>
        <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />
      </div>

      {/* THEME SELECTOR CARD (Light / Dark / System) */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs space-y-2.5">
        <div className="flex items-center justify-between text-xs font-bold text-zinc-800 dark:text-zinc-200">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Moon className="w-4 h-4 text-amber-500" />
            <span>{t('theme')}</span>
          </div>
          <span className="text-[10px] text-zinc-400 uppercase font-semibold">
            {themeMode}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setThemeMode('light')}
            className={`py-2 px-2.5 text-xs font-semibold rounded-xl border flex flex-col items-center justify-center space-y-1 transition-all cursor-pointer ${
              themeMode === 'light'
                ? 'bg-zinc-900 text-white border-zinc-900 shadow-2xs'
                : 'bg-zinc-50 dark:bg-zinc-800/80 text-zinc-600 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-700'
            }`}
          >
            <Sun className="w-3.5 h-3.5" />
            <span>{t('themeLight')}</span>
          </button>
          <button
            onClick={() => setThemeMode('dark')}
            className={`py-2 px-2.5 text-xs font-semibold rounded-xl border flex flex-col items-center justify-center space-y-1 transition-all cursor-pointer ${
              themeMode === 'dark'
                ? 'bg-amber-500 text-zinc-950 font-bold border-amber-500 shadow-2xs'
                : 'bg-zinc-50 dark:bg-zinc-800/80 text-zinc-600 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-700'
            }`}
          >
            <Moon className="w-3.5 h-3.5" />
            <span>{t('themeDark')}</span>
          </button>
          <button
            onClick={() => setThemeMode('system')}
            className={`py-2 px-2.5 text-xs font-semibold rounded-xl border flex flex-col items-center justify-center space-y-1 transition-all cursor-pointer ${
              themeMode === 'system'
                ? 'bg-zinc-900 text-white border-zinc-900 shadow-2xs'
                : 'bg-zinc-50 dark:bg-zinc-800/80 text-zinc-600 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-700'
            }`}
          >
            <Laptop className="w-3.5 h-3.5" />
            <span>{t('themeSystem')}</span>
          </button>
        </div>
      </div>

      {/* LANGUAGE SELECTOR CARD */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs space-y-2.5">
        <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs font-bold text-zinc-800 dark:text-zinc-200">
          <Globe className="w-4 h-4 text-zinc-500" />
          <span>{t('language')}</span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setLanguage('tr')}
            className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
              language === 'tr'
                ? 'bg-zinc-900 text-white dark:bg-amber-500 dark:text-zinc-950 border-transparent shadow-2xs'
                : 'bg-zinc-50 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-700'
            }`}
          >
            🇹🇷 Türkçe
          </button>
          <button
            onClick={() => setLanguage('en')}
            className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
              language === 'en'
                ? 'bg-zinc-900 text-white dark:bg-amber-500 dark:text-zinc-950 border-transparent shadow-2xs'
                : 'bg-zinc-50 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-700'
            }`}
          >
            🇬🇧 English
          </button>
          <button
            onClick={() => setLanguage('ar')}
            className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
              language === 'ar'
                ? 'bg-zinc-900 text-white dark:bg-amber-500 dark:text-zinc-950 border-transparent shadow-2xs'
                : 'bg-zinc-50 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-700'
            }`}
          >
            🇪🇬 العربية
          </button>
        </div>
      </div>

      {/* MENU ACTION ITEMS */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/80 dark:border-zinc-800 shadow-2xs overflow-hidden divide-y divide-zinc-100 dark:divide-zinc-800 text-xs">
        {/* Boost Listing action item */}
        <button
          onClick={() => openPromoteModal()}
          className="w-full px-4 py-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/60 transition-colors cursor-pointer"
        >
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse text-zinc-800 dark:text-zinc-200 font-semibold">
            <Zap className="w-4 h-4 text-amber-500" />
            <span>{t('promoteProduct')}</span>
          </div>
          <div className="flex items-center space-x-1 text-amber-600 dark:text-amber-400 font-bold text-[11px]">
            <span>3G / 7G</span>
            <ChevronRight className="w-4 h-4 text-zinc-400 rtl:rotate-180" />
          </div>
        </button>

        {/* Platform Revenue & Monetization Hub */}
        <button
          onClick={() => setIsRevenueModalOpen(true)}
          className="w-full px-4 py-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/60 transition-colors cursor-pointer"
        >
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse text-zinc-800 dark:text-zinc-200 font-semibold">
            <TrendingUp className="w-4 h-4 text-amber-500" />
            <span>
              {language === 'ar'
                ? 'نموذج أرباح المنصة وتقرير المبيعات'
                : language === 'en'
                ? 'Monetization & Revenue Hub'
                : 'Platform Gelir Modeli ve Raporu'}
            </span>
          </div>
          <ArrowUpRight className="w-4 h-4 text-zinc-400" />
        </button>

        <button
          onClick={() => setActiveSubView('orders')}
          className="w-full px-4 py-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/60 transition-colors cursor-pointer"
        >
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse text-zinc-800 dark:text-zinc-200 font-semibold">
            <Package className="w-4 h-4 text-zinc-500" />
            <span>{t('myOrders')}</span>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-400 rtl:rotate-180" />
        </button>

        <button
          onClick={() => setActiveSubView('wardrobe')}
          className="w-full px-4 py-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/60 transition-colors cursor-pointer"
        >
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse text-zinc-800 dark:text-zinc-200 font-semibold">
            <Shirt className="w-4 h-4 text-zinc-500" />
            <span>{t('myWardrobe')}</span>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-400 rtl:rotate-180" />
        </button>

        <button
          onClick={() => setActiveSubView('favorites')}
          className="w-full px-4 py-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/60 transition-colors cursor-pointer"
        >
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse text-zinc-800 dark:text-zinc-200 font-semibold">
            <Heart className="w-4 h-4 text-rose-500" />
            <span>{t('favorites')}</span>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-400 rtl:rotate-180" />
        </button>

        <button
          onClick={() => setActiveSubView('safety')}
          className="w-full px-4 py-3.5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800/60 transition-colors cursor-pointer"
        >
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse text-zinc-800 dark:text-zinc-200 font-semibold">
            <Lock className="w-4 h-4 text-amber-500" />
            <span>{t('safetyRules')}</span>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-400 rtl:rotate-180" />
        </button>
      </div>

      {/* Safety Policy Notice Footer */}
      <div className="p-3.5 bg-zinc-100 dark:bg-zinc-900 rounded-2xl border border-zinc-200/80 dark:border-zinc-800 text-center space-y-1">
        <p className="text-[11px] font-bold text-zinc-800 dark:text-zinc-200">
          LUQTA - لقطة
        </p>
        <p className="text-[10px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
          {t('privacyNotice')}
        </p>
      </div>
    </div>
  );
};
