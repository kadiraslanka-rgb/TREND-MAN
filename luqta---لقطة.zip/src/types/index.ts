export type Language = 'tr' | 'en' | 'ar';

export type ThemeMode = 'light' | 'dark' | 'system';

export type CategoryId = 'all' | 'women' | 'men' | 'kids' | 'bags' | 'shoes' | 'traditional' | 'accessories';

export interface Category {
  id: CategoryId;
  name: {
    tr: string;
    en: string;
    ar: string;
  };
  iconName: string;
}

export interface Seller {
  id: string;
  name: string;
  avatar: string;
  city: string;
  rating: number;
  ratingCount: number;
  listingCount: number;
  joinedYear: number;
  verified: boolean;
  isSuperSeller?: boolean;
  responseRate: string;
  bio?: string;
}

export type ProductCondition = 'new_with_tag' | 'like_new' | 'good' | 'fair';

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number; // in EGP
  originalPrice?: number; // in EGP
  category: CategoryId;
  brand: string;
  size: string;
  condition: ProductCondition;
  images: string[];
  seller: Seller;
  city: string; // Egyptian cities (Cairo, Giza, Alexandria, Mansoura, etc.)
  likesCount: number;
  viewsCount: number;
  createdAt: string;
  isFeatured?: boolean;
  isBoosted?: boolean;
  boostExpiresAt?: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  text: string;
  timestamp: string;
  isOffer?: boolean;
  offerAmount?: number;
  offerStatus?: 'pending' | 'accepted' | 'declined';
  isSystem?: boolean;
}

export interface Conversation {
  id: string;
  productId: string;
  product: Product;
  buyerId: string;
  sellerId: string;
  seller: Seller;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  messages: ChatMessage[];
}

export interface CartItem {
  product: Product;
  addedAt: string;
}

export interface Order {
  id: string;
  product: Product;
  amount: number;
  date: string;
  status: 'pending' | 'meeting_arranged' | 'completed';
  buyerProtectionFee: number;
  deliveryMethod: 'hand_delivery';
  meetingCity?: string;
}

// ==========================================
// Google Play Billing & Monetization Models
// ==========================================

export type BillingProductType = 'SUBSCRIPTION' | 'INAPP';

export interface BillingProduct {
  productId: string;
  type: BillingProductType;
  title: {
    tr: string;
    en: string;
    ar: string;
  };
  description: {
    tr: string;
    en: string;
    ar: string;
  };
  priceEgp: number;
  formattedPrice: string;
  periodLabel?: {
    tr: string;
    en: string;
    ar: string;
  };
  badgeText?: {
    tr: string;
    en: string;
    ar: string;
  };
  benefits: {
    tr: string[];
    en: string[];
    ar: string[];
  };
}

export interface PurchaseRecord {
  orderId: string;
  productId: string;
  productTitle: string;
  type: BillingProductType;
  amountEgp: number;
  purchaseTime: string;
  acknowledged: boolean;
  targetItemId?: string;
  targetItemTitle?: string;
  expiryDate?: string;
}

export interface PlatformRevenueSummary {
  totalRevenueEgp: number;
  subscriptionRevenueEgp: number;
  boostRevenueEgp: number;
  escrowFeeRevenueEgp: number;
  activeSuperSellersCount: number;
  activeBoostedListingsCount: number;
}
