import React from 'react';
import { Product } from '../types';
import { useApp } from '../context/AppContext';
import { Heart, MapPin, Star, Sparkles, Crown } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { setActiveProductId, favorites, toggleFavorite, language, t } = useApp();
  const isFav = favorites.includes(product.id);

  const getConditionLabel = (cond: Product['condition']) => {
    switch (cond) {
      case 'new_with_tag':
        return language === 'ar' ? 'جديد بالتاغ' : language === 'en' ? 'New with tag' : 'Etiketli Sıfır';
      case 'like_new':
        return language === 'ar' ? 'بحالة الجديد' : language === 'en' ? 'Like new' : 'Yeni Gibi';
      case 'good':
        return language === 'ar' ? 'جيد جداً' : language === 'en' ? 'Good' : 'İyi Durumda';
      default:
        return language === 'ar' ? 'مستعمل' : language === 'en' ? 'Pre-owned' : 'Kullanılmış';
    }
  };

  const isBoosted = product.isBoosted || product.isFeatured;

  return (
    <div
      onClick={() => setActiveProductId(product.id)}
      className={`bg-white dark:bg-zinc-900 rounded-2xl border overflow-hidden shadow-2xs hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col group ${
        isBoosted
          ? 'border-amber-400/70 dark:border-amber-500/50 ring-1 ring-amber-400/20'
          : 'border-zinc-200/80 dark:border-zinc-800/80'
      }`}
    >
      {/* Product Image & Badges */}
      <div className="relative aspect-4/5 w-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
        <img
          src={product.images[0]}
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
          loading="lazy"
        />

        {/* Condition Badge */}
        <div className="absolute top-2 left-2 rtl:left-auto rtl:right-2">
          <span className="bg-zinc-950/80 dark:bg-zinc-900/90 backdrop-blur-xs text-white text-[10px] font-semibold px-2 py-0.5 rounded-full">
            {getConditionLabel(product.condition)}
          </span>
        </div>

        {/* Featured / Boosted Golden Tag */}
        {isBoosted && (
          <div className="absolute bottom-2 right-2 rtl:right-auto rtl:left-2">
            <span className="bg-gradient-to-r from-amber-500 to-amber-600 text-zinc-950 text-[9px] font-black px-1.5 py-0.5 rounded-md shadow-xs flex items-center space-x-0.5 rtl:space-x-reverse">
              <Sparkles className="w-2.5 h-2.5" />
              <span>{t('boostedBadge')}</span>
            </span>
          </div>
        )}

        {/* Favorite Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(product.id);
          }}
          className={`absolute top-2 right-2 rtl:right-auto rtl:left-2 w-7 h-7 rounded-full flex items-center justify-center backdrop-blur-md transition-colors cursor-pointer ${
            isFav
              ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-500 shadow-xs'
              : 'bg-white/80 dark:bg-zinc-900/80 text-zinc-600 dark:text-zinc-300 hover:text-rose-500'
          }`}
          aria-label="Favorilere ekle"
        >
          <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 stroke-rose-500' : 'stroke-current'}`} />
        </button>

        {/* Size Badge */}
        {product.size && (
          <div className="absolute bottom-2 left-2 rtl:left-auto rtl:right-2">
            <span className="bg-white/90 dark:bg-zinc-900/90 backdrop-blur-xs text-zinc-900 dark:text-zinc-100 text-[10px] font-bold px-1.5 py-0.5 rounded-md border border-zinc-200/60 dark:border-zinc-800 shadow-2xs">
              {product.size}
            </span>
          </div>
        )}
      </div>

      {/* Card Info */}
      <div className="p-3 flex-1 flex flex-col justify-between">
        <div>
          {/* Brand */}
          <div className="text-[11px] font-black uppercase tracking-wider text-zinc-900 dark:text-zinc-200 truncate">
            {product.brand}
          </div>

          {/* Title */}
          <h3 className="text-xs font-medium text-zinc-700 dark:text-zinc-300 line-clamp-2 mt-0.5 leading-snug">
            {product.title}
          </h3>
        </div>

        <div className="mt-2.5 pt-2 border-t border-zinc-100 dark:border-zinc-800/80 space-y-1.5">
          {/* Price & Discount */}
          <div className="flex items-baseline space-x-1.5 rtl:space-x-reverse">
            <span className="text-sm font-extrabold text-zinc-950 dark:text-zinc-50">
              {product.price}{' '}
              <span className="text-[11px] font-bold text-amber-600 dark:text-amber-400">
                EGP
              </span>
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-[10px] text-zinc-400 dark:text-zinc-500 line-through">
                {product.originalPrice} EGP
              </span>
            )}
          </div>

          {/* Seller & City snippet with Super Seller badge if active */}
          <div className="flex items-center justify-between text-[10px] text-zinc-500 dark:text-zinc-400">
            <div className="flex items-center space-x-1 rtl:space-x-reverse truncate max-w-[65%]">
              <MapPin className="w-3 h-3 text-zinc-400 shrink-0" />
              <span className="truncate">{product.city}</span>
            </div>

            <div className="flex items-center space-x-1 rtl:space-x-reverse shrink-0">
              {product.seller.isSuperSeller && (
                <span className="p-0.5 rounded-full bg-amber-500/20 text-amber-500" title="Süper Satıcı">
                  <Crown className="w-3 h-3" />
                </span>
              )}
              <div className="flex items-center space-x-0.5 rtl:space-x-reverse text-amber-600 dark:text-amber-400 font-semibold">
                <Star className="w-3 h-3 fill-amber-400 stroke-amber-400" />
                <span>{product.seller.rating}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
