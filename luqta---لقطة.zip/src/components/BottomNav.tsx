import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, MessageSquare, ShoppingCart, Plus, Menu } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, cart, conversations, t } = useApp();

  const totalUnread = conversations.reduce((acc, curr) => acc + (curr.unreadCount || 0), 0);
  const cartItemCount = cart.length;

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md border-t border-zinc-200/80 dark:border-zinc-800/80 shadow-lg transition-colors"
      style={{
        paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 8px)',
      }}
    >
      <div className="max-w-md mx-auto grid grid-cols-5 px-1 py-1.5 items-center">
        {/* 1. Ana Sayfa / Home */}
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer ${
            activeTab === 'home'
              ? 'text-zinc-950 dark:text-amber-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 font-medium'
          }`}
          aria-label={t('tabHome')}
        >
          <div className="relative">
            <Home className={`w-5 h-5 ${activeTab === 'home' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          </div>
          <span className="text-[10px] mt-1 leading-tight tracking-tight">
            {t('tabHome')}
          </span>
        </button>

        {/* 2. Mesajlar / Messages */}
        <button
          onClick={() => setActiveTab('messages')}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer ${
            activeTab === 'messages'
              ? 'text-zinc-950 dark:text-amber-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 font-medium'
          }`}
          aria-label={t('tabMessages')}
        >
          <div className="relative">
            <MessageSquare className={`w-5 h-5 ${activeTab === 'messages' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
            {totalUnread > 0 && (
              <span className="absolute -top-1 -right-2 bg-amber-600 text-white font-bold text-[9px] w-4 h-4 rounded-full flex items-center justify-center border-2 border-white dark:border-zinc-950 shadow-2xs">
                {totalUnread}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-1 leading-tight tracking-tight">
            {t('tabMessages')}
          </span>
        </button>

        {/* 3. Ürün Ekle / Add Product */}
        <button
          onClick={() => setActiveTab('add')}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer ${
            activeTab === 'add'
              ? 'text-zinc-950 dark:text-amber-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 font-medium'
          }`}
          aria-label={t('tabAdd')}
        >
          <div className="relative -mt-3">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center shadow-md transition-transform active:scale-95 ${
                activeTab === 'add'
                  ? 'bg-zinc-950 dark:bg-amber-500 text-white dark:text-zinc-950 ring-4 ring-zinc-300 dark:ring-amber-500/20'
                  : 'bg-zinc-900 hover:bg-zinc-800 dark:bg-amber-500 dark:hover:bg-amber-400 text-white dark:text-zinc-950'
              }`}
            >
              <Plus className="w-5 h-5 stroke-[2.8]" />
            </div>
          </div>
          <span className="text-[10px] mt-0.5 leading-tight tracking-tight font-semibold">
            {t('tabAdd')}
          </span>
        </button>

        {/* 4. Sepet / Cart */}
        <button
          onClick={() => setActiveTab('cart')}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer ${
            activeTab === 'cart'
              ? 'text-zinc-950 dark:text-amber-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 font-medium'
          }`}
          aria-label={t('tabCart')}
        >
          <div className="relative">
            <ShoppingCart className={`w-5 h-5 ${activeTab === 'cart' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-amber-600 text-white font-bold text-[9px] w-4 h-4 rounded-full flex items-center justify-center border-2 border-white dark:border-zinc-950 shadow-2xs">
                {cartItemCount}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-1 leading-tight tracking-tight">
            {t('tabCart')}
          </span>
        </button>

        {/* 5. Menü / Menu */}
        <button
          onClick={() => setActiveTab('menu')}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer ${
            activeTab === 'menu'
              ? 'text-zinc-950 dark:text-amber-400 font-bold'
              : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 font-medium'
          }`}
          aria-label={t('tabMenu')}
        >
          <div className="relative">
            <Menu className={`w-5 h-5 ${activeTab === 'menu' ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
          </div>
          <span className="text-[10px] mt-1 leading-tight tracking-tight">
            {t('tabMenu')}
          </span>
        </button>
      </div>
    </nav>
  );
};
