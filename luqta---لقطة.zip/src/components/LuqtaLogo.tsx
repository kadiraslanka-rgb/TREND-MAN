import React from 'react';

interface LuqtaLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'full' | 'icon-only' | 'horizontal';
  showTagline?: boolean;
  className?: string;
  theme?: 'dark' | 'light' | 'auto';
}

export const LuqtaLogo: React.FC<LuqtaLogoProps> = ({
  size = 'md',
  variant = 'horizontal',
  showTagline = false,
  className = '',
  theme = 'auto',
}) => {
  // Dimension mapping
  const iconSizes = {
    xs: 22,
    sm: 28,
    md: 36,
    lg: 48,
    xl: 68,
  };

  const px = iconSizes[size];

  // SVG representation of the official Luqta "L" Price-Tag Emblem with Eyelet and 4-point Gold Sparkle
  const IconMark = (
    <svg
      width={px}
      height={px}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0 transition-transform select-none"
    >
      {/* Background container if needed or transparent */}
      <defs>
        {/* Soft champagne gold gradient for star sparkle */}
        <linearGradient id="luqtaGold" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#E2C18D" />
          <stop offset="50%" stopColor="#C9A36A" />
          <stop offset="100%" stopColor="#AE854C" />
        </linearGradient>
        {/* Deep anthracite gradient for the tag body */}
        <linearGradient id="luqtaAnthracite" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#252A32" />
          <stop offset="100%" stopColor="#121417" />
        </linearGradient>
      </defs>

      {/* Styled Tag-L Ribbon Glyph */}
      <path
        d="M 32 10 
           L 66 10 
           C 74 10, 82 17, 85 24 
           L 88 32 
           C 90 38, 88 44, 82 48 
           L 78 51 
           C 73 55, 68 53, 68 47 
           L 68 32 
           C 68 26, 62 21, 56 21 
           L 36 21 
           C 27 21, 21 27, 21 36 
           L 21 66 
           C 21 78, 30 87, 42 87 
           L 78 87 
           C 84 87, 88 83, 88 77 
           L 88 77 
           C 88 73, 85 70, 81 69 
           L 54 69 
           C 43 69, 37 63, 37 52 
           L 37 36 
           C 37 28, 41 23, 48 20 
           L 32 10 Z"
        fill="currentColor"
        fillRule="evenodd"
        className="text-zinc-900 dark:text-zinc-100"
      />

      {/* Actual geometry faithfully traced from the reference identity */}
      <path
        d="M 33 12
           C 30 12, 27 14, 25 17
           L 20 25
           C 17 30, 16 35, 16 42
           L 16 68
           C 16 80, 26 90, 38 90
           L 76 90
           C 82 90, 86 86, 86 80
           L 86 78
           C 86 73, 82 70, 77 70
           L 44 70
           C 38 70, 34 66, 34 60
           L 34 36
           C 34 26, 42 18, 52 18
           L 66 18
           C 75 18, 82 24, 85 32
           C 88 40, 86 48, 80 52
           C 75 56, 69 53, 69 46
           L 69 34
           C 69 29, 65 25, 60 25
           L 46 25
           C 40 25, 36 21, 33 12 Z"
        fill="currentColor"
        className="text-zinc-900 dark:text-zinc-100"
      />

      {/* Eyelet / Hole in top right of price-tag */}
      <circle
        cx="72"
        cy="33"
        r="4.5"
        fill="white"
        className="dark:fill-zinc-950"
      />

      {/* 4-Point Gold Star / Sparkle in the inner crook of L */}
      <path
        d="M 68 62
           Q 68 70, 76 70
           Q 68 70, 68 78
           Q 68 70, 60 70
           Q 68 70, 68 62 Z"
        fill="url(#luqtaGold)"
      />
    </svg>
  );

  if (variant === 'icon-only') {
    return <div className={`inline-flex items-center justify-center ${className}`}>{IconMark}</div>;
  }

  return (
    <div className={`inline-flex items-center space-x-2.5 rtl:space-x-reverse ${className}`}>
      {IconMark}

      <div className="flex flex-col leading-none">
        <div className="flex items-baseline space-x-1.5 rtl:space-x-reverse">
          <span className="font-black tracking-tight text-zinc-950 dark:text-zinc-50 font-sans"
            style={{ fontSize: size === 'xs' ? '14px' : size === 'sm' ? '17px' : size === 'md' ? '20px' : '26px' }}>
            LUQTA
          </span>
          <span className="font-extrabold text-amber-700 dark:text-amber-400 font-arabic tracking-normal text-xs"
            style={{ fontSize: size === 'xs' ? '11px' : size === 'sm' ? '13px' : size === 'md' ? '15px' : '19px' }}>
            لقطة
          </span>
        </div>

        {showTagline && (
          <span className="text-[9px] uppercase tracking-widest text-zinc-600 dark:text-zinc-400 font-semibold mt-1">
            GREAT FINDS LIVE LONGER
          </span>
        )}
      </div>
    </div>
  );
};
