import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PLAY_BILLING_PRODUCTS, PlayBillingService } from '../services/billingService';
import { BillingProduct } from '../types';
import {
  X,
  Sparkles,
  Check,
  ShieldCheck,
  Crown,
  Zap,
  TrendingUp,
  CreditCard,
  CheckCircle2,
} from 'lucide-react';
import { LuqtaLogo } from './LuqtaLogo';

interface SuperSellerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SuperSellerModal: React.FC<SuperSellerModalProps> = ({ isOpen, onClose }) => {
  const { language, t, isUserSuperSeller, refreshMonetizationState } = useApp();

  const subProducts = PLAY_BILLING_PRODUCTS.filter((p) => p.type === 'SUBSCRIPTION');
  const [selectedPlan, setSelectedPlan] = useState<BillingProduct>(subProducts[0]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [purchaseSuccess, setPurchaseSuccess] = useState(false);

  if (!isOpen) return null;

  const handlePurchase = async () => {
    setIsProcessing(true);
    try {
      await PlayBillingService.simulatePlayPurchase(selectedPlan);
      refreshMonetizationState();
      setPurchaseSuccess(true);
      setTimeout(() => {
        setPurchaseSuccess(false);
        onClose();
      }, 2200);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div
        className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden transform transition-all text-zinc-900 dark:text-zinc-100 flex flex-col max-h-[92vh]"
        role="dialog"
      >
        {/* Header with Dark Anthracite & Warm Gold Gradient */}
        <div className="bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 text-white p-5 relative overflow-hidden shrink-0 border-b border-zinc-800">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 rtl:right-auto rtl:left-4 p-1.5 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors cursor-pointer"
            aria-label="Kapat"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center space-x-2.5 rtl:space-x-reverse mb-3">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-400/30 text-amber-300 shadow-xs">
              <Crown className="w-5 h-5 fill-amber-300/40" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold tracking-widest uppercase text-amber-300/90 block">
                LUQTA VIP
              </span>
              <h2 className="text-lg font-black tracking-tight text-white leading-tight">
                {t('superSeller')}
              </h2>
            </div>
          </div>

          <p className="text-xs text-zinc-300 leading-relaxed max-w-xs">
            {t('superSellerDesc')}
          </p>

          {/* Decorative Sparkle */}
          <div className="absolute -bottom-6 -right-6 w-28 h-28 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />
        </div>

        {/* Scrollable Content */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {purchaseSuccess ? (
            <div className="py-8 text-center space-y-3 animate-scale-in">
              <div className="w-16 h-16 bg-amber-500/20 border-2 border-amber-400 text-amber-500 dark:text-amber-400 rounded-full flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-base font-extrabold text-zinc-900 dark:text-zinc-50">
                {language === 'ar' ? 'تهانينا! أصبحت بائعاً مميزاً' : language === 'en' ? 'Congratulations! You are now a Super Seller' : 'Tebrikler! Artık Süper Satıcısınız'}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-xs mx-auto">
                {language === 'ar' ? 'تم تفعيل شارة البائع المميز الذهبية وأولوية الظهور في نتائج البحث.' : language === 'en' ? 'Your gold badge and listing priority are now active across LUQTA.' : 'Altın rozetiniz ve vitrin önceliğiniz profilinize tanımlandı.'}
              </p>
            </div>
          ) : (
            <>
              {/* Status Banner if already active */}
              {isUserSuperSeller && (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-2xl flex items-center space-x-2.5 rtl:space-x-reverse text-xs text-amber-900 dark:text-amber-200">
                  <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span className="font-bold">
                    {language === 'ar' ? 'أنت بائع مميز حالياً (الاشتراك نشط)' : language === 'en' ? 'You currently have an active Super Seller plan' : 'Süper Satıcı aboneliğiniz şu an aktif!'}
                  </span>
                </div>
              )}

              {/* Perks List */}
              <div className="bg-zinc-50 dark:bg-zinc-900/60 p-3.5 rounded-2xl border border-zinc-200/80 dark:border-zinc-800 space-y-2 text-xs">
                <span className="font-bold uppercase tracking-wider text-[10px] text-zinc-600 dark:text-zinc-400 block">
                  {language === 'ar' ? 'مزايا الاشتراك' : language === 'en' ? 'Membership Perks' : 'Üyelik Avantajları'}
                </span>
                {selectedPlan.benefits[language]?.map((benefit, idx) => (
                  <div key={idx} className="flex items-start space-x-2.5 rtl:space-x-reverse text-zinc-700 dark:text-zinc-300">
                    <div className="p-0.5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                    <span className="leading-snug">{benefit}</span>
                  </div>
                ))}
              </div>

              {/* Plans Selection */}
              <div className="space-y-2.5">
                <span className="font-bold text-xs text-zinc-800 dark:text-zinc-200 block">
                  {language === 'ar' ? 'اختر خطة الاشتراك' : language === 'en' ? 'Select Subscription Plan' : 'Abonelik Planını Seçin'}
                </span>

                <div className="space-y-2">
                  {subProducts.map((plan) => {
                    const isSelected = selectedPlan.productId === plan.productId;
                    return (
                      <div
                        key={plan.productId}
                        onClick={() => setSelectedPlan(plan)}
                        className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer relative flex items-center justify-between ${
                          isSelected
                            ? 'border-amber-500 bg-amber-50/40 dark:bg-amber-950/20 shadow-xs'
                            : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 bg-white dark:bg-zinc-800/40'
                        }`}
                      >
                        <div className="flex items-center space-x-3 rtl:space-x-reverse">
                          <div
                            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                              isSelected
                                ? 'border-amber-500 bg-amber-500 text-white'
                                : 'border-zinc-300 dark:border-zinc-600'
                            }`}
                          >
                            {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                          </div>

                          <div>
                            <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
                              <h4 className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                                {plan.title[language]}
                              </h4>
                              {plan.badgeText && (
                                <span className="bg-amber-500 text-zinc-950 text-[9px] font-black px-1.5 py-0.5 rounded-md">
                                  {plan.badgeText[language]}
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-zinc-500 dark:text-zinc-400">
                              {plan.periodLabel?.[language]}
                            </span>
                          </div>
                        </div>

                        <div className="text-right rtl:text-left">
                          <span className="text-sm font-black text-zinc-950 dark:text-zinc-50 block">
                            {plan.formattedPrice}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Google Play Billing Integration Note */}
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-[11px] text-zinc-500 dark:text-zinc-400 bg-zinc-100 dark:bg-zinc-800/50 p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700/60">
                <CreditCard className="w-4 h-4 text-zinc-500 shrink-0" />
                <span>
                  {language === 'ar'
                    ? 'الفوترة آمنة ومحمية عبر حسابك في Google Play. يمكنك إلغاء الاشتراك في أي وقت.'
                    : language === 'en'
                    ? 'Billed securely via your Google Play account. Cancel anytime in Play Store.'
                    : 'Ödeme Google Play hesabınız üzerinden güvenle tahsil edilir. İstediğiniz an iptal edebilirsiniz.'}
                </span>
              </div>
            </>
          )}
        </div>

        {/* Footer Actions */}
        {!purchaseSuccess && (
          <div className="p-4 border-t border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/90 shrink-0">
            <button
              onClick={handlePurchase}
              disabled={isProcessing}
              className="w-full py-3.5 px-4 bg-zinc-900 hover:bg-zinc-800 dark:bg-amber-500 dark:hover:bg-amber-400 text-white dark:text-zinc-950 rounded-2xl font-black text-xs transition-all shadow-md flex items-center justify-center space-x-2 rtl:space-x-reverse cursor-pointer disabled:opacity-50"
            >
              <Crown className="w-4 h-4" />
              <span>
                {isProcessing
                  ? (language === 'ar' ? 'جارٍ المعالجة عبر Google Play...' : language === 'en' ? 'Processing via Google Play...' : 'Google Play ile İşleniyor...')
                  : (language === 'ar' ? `الاشتراك الآن (${selectedPlan.formattedPrice})` : language === 'en' ? `Subscribe with Google Play (${selectedPlan.formattedPrice})` : `Google Play ile Abone Ol (${selectedPlan.formattedPrice})`)}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
