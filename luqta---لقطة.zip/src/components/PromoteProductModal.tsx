import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PLAY_BILLING_PRODUCTS, PlayBillingService } from '../services/billingService';
import { BillingProduct, Product } from '../types';
import {
  X,
  Sparkles,
  Zap,
  Check,
  CheckCircle2,
  TrendingUp,
  CreditCard,
  Flame,
} from 'lucide-react';

interface PromoteProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetProduct?: Product | null;
}

export const PromoteProductModal: React.FC<PromoteProductModalProps> = ({
  isOpen,
  onClose,
  targetProduct,
}) => {
  const { products, boostProduct, language, t } = useApp();

  const boostPlans = PLAY_BILLING_PRODUCTS.filter((p) => p.type === 'INAPP');
  const [selectedPlan, setSelectedPlan] = useState<BillingProduct>(boostPlans[0]);
  const [selectedProductId, setSelectedProductId] = useState<string>(
    targetProduct?.id || (products.length > 0 ? products[0].id : '')
  );
  const [isProcessing, setIsProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const currentItem = products.find((p) => p.id === (targetProduct?.id || selectedProductId));

  const handlePurchase = async () => {
    if (!currentItem) return;
    setIsProcessing(true);
    try {
      await PlayBillingService.simulatePlayPurchase(
        selectedPlan,
        currentItem.id,
        currentItem.title
      );
      boostProduct(currentItem.id);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 2000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div
        className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden transform transition-all text-zinc-900 dark:text-zinc-100 flex flex-col max-h-[92vh]"
        role="dialog"
      >
        {/* Header */}
        <div className="bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 text-white p-5 relative overflow-hidden shrink-0 border-b border-zinc-800">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 rtl:right-auto rtl:left-4 p-1.5 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors cursor-pointer"
            aria-label="Kapat"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center space-x-2.5 rtl:space-x-reverse mb-2">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-400/30 text-amber-300 shadow-xs">
              <Zap className="w-5 h-5 fill-amber-300/40" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold tracking-widest uppercase text-amber-300/90 block">
                LUQTA BOOST
              </span>
              <h2 className="text-lg font-black tracking-tight text-white leading-tight">
                {t('promoteProduct')}
              </h2>
            </div>
          </div>

          <p className="text-xs text-zinc-300 leading-relaxed max-w-xs">
            {language === 'ar'
              ? 'اجعل منتجك في صدارة الصفحة الرئيسية ونتائج البحث لمضاعفة المبيعات.'
              : language === 'en'
              ? 'Pin your product to the top of homepage and search feeds for max visibility.'
              : 'İlanınızı vitrinde ve arama başlarında tutarak satış şansınızı 3 katına çıkarın.'}
          </p>
        </div>

        {/* Body Content */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {success ? (
            <div className="py-8 text-center space-y-3 animate-scale-in">
              <div className="w-16 h-16 bg-amber-500/20 border-2 border-amber-400 text-amber-500 rounded-full flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-base font-extrabold text-zinc-900 dark:text-zinc-50">
                {language === 'ar' ? 'تم تمييز الإعلان بنجاح!' : language === 'en' ? 'Listing Boosted Successfully!' : 'İlanınız Başarıyla Öne Çıkarıldı!'}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-xs mx-auto">
                {language === 'ar'
                  ? 'تمت إضافة الشارة الذهبية إلى المنتج وتثبيته في صدارة المعروضات.'
                  : language === 'en'
                  ? 'Golden "Featured" badge is now active on your item card.'
                  : 'Altın "Öne Çıkan" rozeti ürününüze eklendi ve vitrin başına taşındı.'}
              </p>
            </div>
          ) : (
            <>
              {/* Product Preview Card */}
              {currentItem && (
                <div className="bg-zinc-50 dark:bg-zinc-800/40 p-3 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center space-x-3 rtl:space-x-reverse">
                  <img
                    src={currentItem.images[0]}
                    alt={currentItem.title}
                    className="w-14 h-14 rounded-xl object-cover bg-zinc-200 shrink-0"
                  />
                  <div className="flex-1 min-w-0 text-xs">
                    <div className="flex items-center space-x-1 rtl:space-x-reverse mb-0.5">
                      <span className="bg-amber-500/20 border border-amber-500/30 text-amber-800 dark:text-amber-300 text-[10px] font-black px-1.5 py-0.2 rounded flex items-center space-x-0.5">
                        <Sparkles className="w-3 h-3" />
                        <span>{t('boostedBadge')}</span>
                      </span>
                    </div>
                    <h4 className="font-bold text-zinc-900 dark:text-zinc-100 truncate">
                      {currentItem.title}
                    </h4>
                    <span className="font-extrabold text-amber-600 dark:text-amber-400">
                      {currentItem.price} EGP
                    </span>
                  </div>
                </div>
              )}

              {/* If user has multiple listings and no specific target */}
              {!targetProduct && products.length > 1 && (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
                    {language === 'ar' ? 'اختر المنتج للتمييز:' : language === 'en' ? 'Select item to boost:' : 'Öne Çıkarılacak İlan:'}
                  </label>
                  <select
                    value={selectedProductId}
                    onChange={(e) => setSelectedProductId(e.target.value)}
                    className="w-full bg-white dark:bg-zinc-800 text-xs text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2 outline-hidden"
                  >
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.title} ({p.price} EGP)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Boost Duration Options */}
              <div className="space-y-2">
                <span className="font-bold text-xs text-zinc-800 dark:text-zinc-200 block">
                  {language === 'ar' ? 'مدة التمييز (شراء لمرة واحدة)' : language === 'en' ? 'Boost Duration (One-Time Purchase)' : 'Öne Çıkarma Süresi (Tek Seferlik)'}
                </span>

                <div className="space-y-2">
                  {boostPlans.map((plan) => {
                    const isSelected = selectedPlan.productId === plan.productId;
                    return (
                      <div
                        key={plan.productId}
                        onClick={() => setSelectedPlan(plan)}
                        className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'border-amber-500 bg-amber-50/40 dark:bg-amber-950/20 shadow-xs'
                            : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 bg-white dark:bg-zinc-800/40'
                        }`}
                      >
                        <div className="flex items-center space-x-3 rtl:space-x-reverse">
                          <div
                            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                              isSelected
                                ? 'border-amber-500 bg-amber-500 text-white'
                                : 'border-zinc-300 dark:border-zinc-600'
                            }`}
                          >
                            {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                          </div>

                          <div>
                            <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
                              <h4 className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                                {plan.title[language]}
                              </h4>
                              {plan.badgeText && (
                                <span className="bg-amber-500 text-zinc-950 text-[9px] font-black px-1.5 py-0.5 rounded-md">
                                  {plan.badgeText[language]}
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-zinc-500 dark:text-zinc-400">
                              {plan.description[language]}
                            </span>
                          </div>
                        </div>

                        <span className="text-sm font-black text-zinc-950 dark:text-zinc-50 shrink-0">
                          {plan.formattedPrice}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Play Store Safe Notice */}
              <div className="flex items-center space-x-2 rtl:space-x-reverse text-[11px] text-zinc-500 dark:text-zinc-400 bg-zinc-100 dark:bg-zinc-800/50 p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700/60">
                <CreditCard className="w-4 h-4 text-zinc-500 shrink-0" />
                <span>
                  {language === 'ar'
                    ? 'شراء لمرة واحدة عبر Google Play In-App Billing بدون تجديد تلقائي.'
                    : language === 'en'
                    ? 'One-time Google Play In-App Purchase with no auto-renewal.'
                    : 'Google Play üzerinden tek seferlik satın alım; otomatik yenilenmez.'}
                </span>
              </div>
            </>
          )}
        </div>

        {/* Footer Actions */}
        {!success && (
          <div className="p-4 border-t border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/90 shrink-0">
            <button
              onClick={handlePurchase}
              disabled={isProcessing}
              className="w-full py-3.5 px-4 bg-zinc-900 hover:bg-zinc-800 dark:bg-amber-500 dark:hover:bg-amber-400 text-white dark:text-zinc-950 rounded-2xl font-black text-xs transition-all shadow-md flex items-center justify-center space-x-2 rtl:space-x-reverse cursor-pointer disabled:opacity-50"
            >
              <Zap className="w-4 h-4" />
              <span>
                {isProcessing
                  ? (language === 'ar' ? 'جارٍ الشراء عبر Google Play...' : language === 'en' ? 'Purchasing via Google Play...' : 'Google Play ile Alınıyor...')
                  : (language === 'ar' ? `تمييز الإعلان الآن (${selectedPlan.formattedPrice})` : language === 'en' ? `Boost Now with Google Play (${selectedPlan.formattedPrice})` : `Google Play ile Öne Çıkar (${selectedPlan.formattedPrice})`)}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
