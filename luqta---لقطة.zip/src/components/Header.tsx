import React from 'react';
import { useApp } from '../context/AppContext';
import { Search, Globe, ShieldCheck, Sun, Moon, Sparkles, Crown } from 'lucide-react';
import { Language, ThemeMode } from '../types';
import { LuqtaLogo } from './LuqtaLogo';

export const Header: React.FC = () => {
  const {
    language,
    setLanguage,
    themeMode,
    setThemeMode,
    searchQuery,
    setSearchQuery,
    t,
    activeTab,
    setActiveTab,
    isUserSuperSeller,
    setIsSuperSellerModalOpen,
  } = useApp();

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
  };

  const toggleTheme = () => {
    if (themeMode === 'dark') setThemeMode('light');
    else if (themeMode === 'light') setThemeMode('system');
    else setThemeMode('dark');
  };

  return (
    <header
      className="sticky top-0 z-40 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md border-b border-zinc-200/80 dark:border-zinc-800/80 shadow-xs transition-colors"
      style={{
        paddingTop: 'max(env(safe-area-inset-top, 0px), 12px)',
      }}
    >
      <div className="max-w-md mx-auto px-4 pb-3">
        {/* Top brand line & Language selector */}
        <div className="flex items-center justify-between py-1.5">
          {/* Brand Logo with Official LUQTA Visual Identity */}
          <div
            onClick={() => setActiveTab('home')}
            className="flex items-center space-x-2 rtl:space-x-reverse cursor-pointer select-none group"
          >
            <LuqtaLogo size="sm" variant="horizontal" showTagline={true} />
          </div>

          {/* Controls: Theme Toggle & Language Selector & VIP Badge */}
          <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
            {/* Super Seller VIP shortcut badge */}
            <button
              onClick={() => setIsSuperSellerModalOpen(true)}
              className={`flex items-center space-x-1 rtl:space-x-reverse text-[10px] px-2 py-1 rounded-full border font-bold transition-all cursor-pointer ${
                isUserSuperSeller
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-600 dark:text-amber-400'
                  : 'bg-zinc-100 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:border-amber-400'
              }`}
              title={t('superSeller')}
            >
              <Crown className="w-3.5 h-3.5 text-amber-500" />
              <span className="hidden sm:inline">VIP</span>
            </button>

            {/* Quick Dark Mode Toggle */}
            <button
              onClick={toggleTheme}
              className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-900 text-zinc-600 dark:text-zinc-300 hover:text-zinc-950 dark:hover:text-white border border-zinc-200/80 dark:border-zinc-800 transition-colors cursor-pointer"
              title={`Tema: ${themeMode}`}
              aria-label="Tema Değiştir"
            >
              {themeMode === 'dark' ? (
                <Moon className="w-3.5 h-3.5 text-amber-400" />
              ) : themeMode === 'light' ? (
                <Sun className="w-3.5 h-3.5 text-amber-600" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 text-zinc-500" />
              )}
            </button>

            {/* Language Switcher */}
            <div className="flex items-center bg-zinc-100 dark:bg-zinc-900 rounded-lg p-0.5 border border-zinc-200/80 dark:border-zinc-800">
              <button
                onClick={() => handleLanguageChange('tr')}
                className={`px-1.5 py-0.5 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                  language === 'tr'
                    ? 'bg-white dark:bg-zinc-800 text-zinc-950 dark:text-zinc-50 shadow-2xs'
                    : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-300'
                }`}
                title="Türkçe"
              >
                TR
              </button>
              <button
                onClick={() => handleLanguageChange('en')}
                className={`px-1.5 py-0.5 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                  language === 'en'
                    ? 'bg-white dark:bg-zinc-800 text-zinc-950 dark:text-zinc-50 shadow-2xs'
                    : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-300'
                }`}
                title="English"
              >
                EN
              </button>
              <button
                onClick={() => handleLanguageChange('ar')}
                className={`px-1.5 py-0.5 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                  language === 'ar'
                    ? 'bg-white dark:bg-zinc-800 text-zinc-950 dark:text-zinc-50 shadow-2xs'
                    : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-300'
                }`}
                title="العربية"
              >
                عربي
              </button>
            </div>
          </div>
        </div>

        {/* Global Search Bar (shown on home tab) */}
        {activeTab === 'home' && (
          <div className="relative mt-2">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('searchPlaceholder')}
              className="w-full bg-zinc-100/90 dark:bg-zinc-900 hover:bg-zinc-100 focus:bg-white dark:focus:bg-zinc-900 text-zinc-900 dark:text-zinc-100 text-xs rounded-xl pl-9 pr-4 rtl:pl-4 rtl:pr-9 py-2 border border-transparent dark:border-zinc-800 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/10 transition-all outline-hidden placeholder:text-zinc-400 dark:placeholder:text-zinc-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 rtl:right-auto rtl:left-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
