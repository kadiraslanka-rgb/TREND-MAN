import React from 'react';
import { useApp } from '../context/AppContext';
import { PlayBillingService } from '../services/billingService';
import {
  X,
  TrendingUp,
  DollarSign,
  Crown,
  Zap,
  ShieldCheck,
  Package,
  Layers,
  ArrowUpRight,
} from 'lucide-react';

interface PlatformRevenueModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PlatformRevenueModal: React.FC<PlatformRevenueModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { orders, products, language, t } = useApp();

  if (!isOpen) return null;

  const purchases = PlayBillingService.getPurchases();

  // Monetization analytics calculations
  const subRevenue = purchases
    .filter((p) => p.type === 'SUBSCRIPTION')
    .reduce((sum, p) => sum + p.amountEgp, 0);

  const boostRevenue = purchases
    .filter((p) => p.type === 'INAPP')
    .reduce((sum, p) => sum + p.amountEgp, 0);

  const escrowFeeRevenue = orders.reduce((sum, o) => sum + o.buyerProtectionFee, 0);

  const totalPlatformRevenue = subRevenue + boostRevenue + escrowFeeRevenue;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div
        className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden transform transition-all text-zinc-900 dark:text-zinc-100 flex flex-col max-h-[92vh]"
        role="dialog"
      >
        {/* Header */}
        <div className="bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 text-white p-5 relative overflow-hidden shrink-0 border-b border-zinc-800">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 rtl:right-auto rtl:left-4 p-1.5 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors cursor-pointer"
            aria-label="Kapat"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center space-x-2.5 rtl:space-x-reverse mb-2">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-400/30 text-amber-300 shadow-xs">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold tracking-widest uppercase text-amber-300/90 block">
                BUSINESS & REVENUE
              </span>
              <h2 className="text-lg font-black tracking-tight text-white leading-tight">
                {t('platformEarnings')}
              </h2>
            </div>
          </div>

          <p className="text-xs text-zinc-300 leading-relaxed max-w-xs">
            {language === 'ar'
              ? 'نموذج أرباح تطبيق لقطة عبر الاشتراكات والترويج وحماية المشتري.'
              : language === 'en'
              ? 'LUQTA marketplace earnings model: Subscriptions, Boosts & Escrow fees.'
              : 'LUQTA pazar yeri gelir modeli: Abonelikler, öne çıkarmalar ve alıcı koruma ücretleri.'}
          </p>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
          {/* Big Total Card */}
          <div className="bg-gradient-to-r from-zinc-900 to-zinc-800 text-white p-4 rounded-2xl border border-zinc-700/60 space-y-1 shadow-sm">
            <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400">
              {language === 'ar' ? 'إجمالي دخل المنصة المحقق' : language === 'en' ? 'Total Platform Earnings' : 'Toplam Pazar Yeri Geliri'}
            </span>
            <div className="flex items-baseline space-x-2 rtl:space-x-reverse">
              <span className="text-3xl font-black tracking-tight text-white">
                {totalPlatformRevenue.toLocaleString()}
              </span>
              <span className="text-sm font-extrabold text-amber-400">EGP</span>
            </div>
            <p className="text-[11px] text-zinc-400 pt-1">
              Google Play In-App Billing & Escrow Protected Fees
            </p>
          </div>

          {/* Breakdown 3 Streams */}
          <div className="space-y-2">
            <span className="font-bold text-[11px] uppercase tracking-wider text-zinc-600 dark:text-zinc-400 block">
              {language === 'ar' ? 'تفصيل قنوات الدخل' : language === 'en' ? 'Revenue Streams Breakdown' : 'Gelir Kanalları Dağılımı'}
            </span>

            {/* Stream 1: Super Seller */}
            <div className="bg-zinc-50 dark:bg-zinc-800/40 p-3.5 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
                  <Crown className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-zinc-900 dark:text-zinc-100">
                    {t('superSeller')}
                  </h4>
                  <span className="text-[10px] text-zinc-500">
                    Google Play Subscriptions (199 / 479 EGP)
                  </span>
                </div>
              </div>
              <span className="font-black text-sm text-zinc-900 dark:text-zinc-100">
                {subRevenue} EGP
              </span>
            </div>

            {/* Stream 2: Boosts */}
            <div className="bg-zinc-50 dark:bg-zinc-800/40 p-3.5 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <div className="p-2 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-zinc-900 dark:text-zinc-100">
                    {t('promoteProduct')}
                  </h4>
                  <span className="text-[10px] text-zinc-500">
                    One-Time Listing Boosts (49 / 89 EGP)
                  </span>
                </div>
              </div>
              <span className="font-black text-sm text-zinc-900 dark:text-zinc-100">
                {boostRevenue} EGP
              </span>
            </div>

            {/* Stream 3: Escrow / Buyer protection */}
            <div className="bg-zinc-50 dark:bg-zinc-800/40 p-3.5 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-zinc-900 dark:text-zinc-100">
                    {t('buyerProtectionTitle')}
                  </h4>
                  <span className="text-[10px] text-zinc-500">
                    4% Escrow & Verification Fee
                  </span>
                </div>
              </div>
              <span className="font-black text-sm text-zinc-900 dark:text-zinc-100">
                {escrowFeeRevenue} EGP
              </span>
            </div>
          </div>

          {/* Transactions Log */}
          <div className="space-y-2 pt-1">
            <span className="font-bold text-[11px] uppercase tracking-wider text-zinc-600 dark:text-zinc-400 block">
              {language === 'ar' ? 'سجل المعاملات الأخيرة' : language === 'en' ? 'Recent Play Billing Orders' : 'Son Google Play Siparişleri'}
            </span>

            {purchases.length === 0 ? (
              <div className="p-4 bg-zinc-50 dark:bg-zinc-800/30 rounded-xl text-center text-zinc-400">
                Henüz Play Store satın alımı yapılmadı.
              </div>
            ) : (
              <div className="space-y-1.5">
                {purchases.map((p) => (
                  <div
                    key={p.orderId}
                    className="p-2.5 bg-zinc-50 dark:bg-zinc-800/30 rounded-xl border border-zinc-200/70 dark:border-zinc-800/80 flex items-center justify-between text-[11px]"
                  >
                    <div>
                      <p className="font-bold text-zinc-800 dark:text-zinc-200">
                        {p.productTitle}
                      </p>
                      <p className="text-[10px] font-mono text-zinc-400">
                        {p.orderId} • {new Date(p.purchaseTime).toLocaleDateString()}
                      </p>
                    </div>
                    <span className="font-black text-amber-600 dark:text-amber-400">
                      +{p.amountEgp} EGP
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/90 shrink-0">
          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-white rounded-xl font-bold text-xs transition-colors cursor-pointer"
          >
            {language === 'ar' ? 'إغلاق' : language === 'en' ? 'Close' : 'Kapat'}
          </button>
        </div>
      </div>
    </div>
  );
};
