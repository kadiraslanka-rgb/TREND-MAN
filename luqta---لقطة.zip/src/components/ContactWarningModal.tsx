import React from 'react';
import { useApp } from '../context/AppContext';
import { CONTACT_WARNINGS, CONTACT_WARNING_DETAILS } from '../utils/filter';
import { ShieldAlert, X, Lock, CheckCircle2, AlertOctagon } from 'lucide-react';

export const ContactWarningModal: React.FC = () => {
  const { contactWarning, closeContactWarning, language } = useApp();

  if (!contactWarning.isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div 
        className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden transform transition-all text-zinc-900 dark:text-zinc-100"
        role="dialog"
        aria-modal="true"
      >
        {/* Header with safety alert branding */}
        <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 px-5 py-4 text-white flex items-center justify-between border-b border-zinc-800">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
            <div className="p-1.5 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <span className="font-bold text-sm tracking-wide">
              {language === 'ar' ? 'تنبيه أمان التواصل' : language === 'en' ? 'Communication Safety Alert' : 'Güvenli İletişim Uyarısı'}
            </span>
          </div>
          <button
            onClick={closeContactWarning}
            className="p-1.5 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
            aria-label="Kapat"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-5 space-y-4">
          {/* Main Mandatory Warning Message */}
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-3.5 flex items-start space-x-3 rtl:space-x-reverse">
            <AlertOctagon className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
            <div>
              <p className="font-bold text-zinc-900 dark:text-zinc-100 text-sm leading-snug">
                {CONTACT_WARNINGS[language]}
              </p>
              <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-1 leading-relaxed">
                {CONTACT_WARNING_DETAILS[language]}
              </p>
            </div>
          </div>

          {/* Detected string indicator if available */}
          {contactWarning.matchedText && (
            <div className="bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700 rounded-xl p-2.5 flex items-center justify-between text-xs">
              <span className="text-zinc-500 dark:text-zinc-400 font-medium">
                {language === 'ar' ? 'البيانات المكتشفة:' : language === 'en' ? 'Detected detail:' : 'Tespit edilen:'}
              </span>
              <span className="font-mono bg-rose-500/15 text-rose-700 dark:text-rose-400 px-2 py-0.5 rounded font-semibold">
                {contactWarning.matchedText}
              </span>
            </div>
          )}

          {/* Security policy bullets */}
          <div className="space-y-2 border-t border-zinc-100 dark:border-zinc-800 pt-3 text-xs text-zinc-600 dark:text-zinc-400">
            <div className="flex items-center space-x-2 rtl:space-x-reverse text-zinc-700 dark:text-zinc-300">
              <Lock className="w-4 h-4 text-amber-500 shrink-0" />
              <span>
                {language === 'ar'
                  ? 'حماية كاملة من الاحتيال عبر نظام الدفع والضمان المعتمد.'
                  : language === 'en'
                  ? 'Complete protection from fraud via escrow and buyer protection.'
                  : 'Dolandırıcılık ve sahte ödemelere karşı Alıcı Koruması devrededir.'}
              </span>
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse text-zinc-700 dark:text-zinc-300">
              <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
              <span>
                {language === 'ar'
                  ? 'تواصل بأمان واطلب صوراً أو قدّم عروض أسعار من داخل الشات.'
                  : language === 'en'
                  ? 'Chat safely, request more details, and negotiate offers in-app.'
                  : 'Fiyat teklifleri ve soru-cevap için dahili mesajlaşmayı kullanın.'}
              </span>
            </div>
          </div>

          {/* Multilingual preview */}
          <div className="bg-zinc-50 dark:bg-zinc-800/40 rounded-xl p-2.5 text-[11px] text-zinc-500 dark:text-zinc-400 space-y-1">
            <div className="font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
              {language === 'ar' ? 'الرسالة بجميع اللغات:' : language === 'en' ? 'Warning in all languages:' : 'Uyarı dilleri:'}
            </div>
            <p className="border-l-2 border-amber-500 pl-2 rtl:border-l-0 rtl:border-r-2 rtl:pr-2">
              <strong className="text-zinc-800 dark:text-zinc-200">TR:</strong> {CONTACT_WARNINGS.tr}
            </p>
            <p className="border-l-2 border-zinc-400 pl-2 rtl:border-l-0 rtl:border-r-2 rtl:pr-2">
              <strong className="text-zinc-800 dark:text-zinc-200">EN:</strong> {CONTACT_WARNINGS.en}
            </p>
            <p className="border-l-2 border-amber-600 pl-2 rtl:border-l-0 rtl:border-r-2 rtl:pr-2">
              <strong className="text-zinc-800 dark:text-zinc-200">AR:</strong> {CONTACT_WARNINGS.ar}
            </p>
          </div>

          {/* Action button */}
          <button
            onClick={closeContactWarning}
            className="w-full py-3 px-4 bg-zinc-900 hover:bg-zinc-800 dark:bg-amber-500 dark:hover:bg-amber-400 text-white dark:text-zinc-950 rounded-2xl font-bold text-xs transition-colors shadow-sm cursor-pointer"
          >
            {language === 'ar' ? 'حسناً، فهمت' : language === 'en' ? 'Understood' : 'Anladım'}
          </button>
        </div>
      </div>
    </div>
  );
};
